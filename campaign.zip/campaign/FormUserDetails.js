import React, { Fragment, useState, useEffect } from 'react';
import { Breadcrumb, Descriptions, Button } from 'antd';
import { useParams } from "react-router-dom";
const FormUserDetails = () => {
const params = useParams();
const [isLoading, setIsLoading] = useState(false);
const [isError, setIsError] = useState(false);
const [user, setUser] = useState({ userId: '', userName: '', gender: '', country: '', email: '', address: ' ', productInterest: '', age: '', isExistingCustomer: '', mobileNumber: '' });
useEffect(() => {
    //const menuId = params.menuId;
    console.log(" userId is "+params.userId)
    setIsLoading(true)
    getUserDetails(params.userId)
    // MenuService.getMenuList().then(
    //     (response) => {            
    //         console.log(response.data)
    //         setMenuList(response.data)
    //         getMenuData(params.menuId)
    //         //setIsLoading(false)
    //     },(error) => {
    //         console.log(error)
    //         setIsError(false)
    //         setIsLoading(false)
    //         //alert(error.response.data);
    //     });
    
}, []);
const getFormUserDetails = {
        userId: 1,
        userName: 'Krishna',
        gender: 'Male',
        country: 'Malaysia',
        email: 'muralikrishna@cimb.com',
        address: '83, Jalan Seri Setia 1'+ <br /> +'Bukit Damansara'+ <br /> +'54790 Kuala Lumpur'+ <br /> +'Malaysia'+ <br />,
        productInterest: 'Senior Basic Current Account',
        age: 24,
        isExistingCustomer: 'Yes',
        mobileNumber: '94324234432'
    };
const getUserDetails = (userId) => {
    setIsLoading(true)
    setUser(getFormUserDetails)
    setIsLoading(false)
    // MenuService.getMenuByMenuId(menuId).then(
    //     (response) => {            
    //         console.log(response.data)
    //         setSeletedMenu(response.data);
    //         //reset(response.data);
    //         reset({
    //             parentId: response.data.parentId,
    //             menuName: response.data.menuName,
    //             menuLink: response.data.menuLink,
    //             menuOrder: response.data.menuOrder,
    //         });
    //         setIsLoading(false);
    //     },(error) => {
    //       console.log(error);
    //       setIsError(false)
    //       setIsLoading(false)
    //         //alert(error.response.data);
    //     });
}
    return (
        <Fragment>
            <>
        {
         isLoading ? <div>Loading... </div> : 
         isError ? <div>Error Occured... </div> :
        <div>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
                <Breadcrumb.Item>Malaysia</Breadcrumb.Item>
                <Breadcrumb.Item>LUCY</Breadcrumb.Item>
            </Breadcrumb>
            <p><br/></p>
            <h1>{user.userName}</h1>
            <Descriptions bordered>
                <Descriptions.Item label="Name" span={4}>{user.userName}</Descriptions.Item>
                <Descriptions.Item label="Gender">{user.gender}</Descriptions.Item>
                <Descriptions.Item label="Age" span={2}>{user.age}</Descriptions.Item>
                <Descriptions.Item label="Country of Origin">{user.country}</Descriptions.Item>
                <Descriptions.Item label="Existing Customer" span={2}>{user.isExistingCustomer}</Descriptions.Item>
                <Descriptions.Item label="Email">{user.email}</Descriptions.Item>
                <Descriptions.Item label="Mobile Number" span={3}>+{user.mobileNumber}</Descriptions.Item>                
                <Descriptions.Item label="Address" span={3}>{user.address}</Descriptions.Item>
                <Descriptions.Item label="Product Interest" span={3}>{user.productInterest}</Descriptions.Item>
            </Descriptions>
            <br/>
            <Button type="danger">&laquo; Back</Button>
        </div>
       } 
      </>
        </Fragment>
    );
}

export default FormUserDetails;
