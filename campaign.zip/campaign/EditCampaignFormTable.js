import React, { Fragment, useState, useEffect } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputField, inputPasswordField, SelectField, SwitchField, inputNumberField, SelectMenuField } from "../../../containers/Inputs";
import { Button,InputNumber,Breadcrumb,Table } from "antd";
import { useParams, Link } from "react-router-dom";
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
import MenuService  from "../../../services/usermanagement/menu-service";
import ContainerHeader from '../../ContainerHeader/index';

const EditLucyFormTable = () => {
const params = useParams();

const [isLoading, setIsLoading] = useState(false);
const [isError, setIsError] = useState(false);
const [formUsersList, setFormUsersList] = useState([]);
const [pagination, setPagination] = useState({});
const getFormUserData = [    
  {
      userId: 1,
      userName: 'Krishna',
      phone: '94324234432',
      email: 'test@gmail.com',
      date: ''
  },
  {
    userId: 2,
    userName: 'Sharul',
    phone: '01912374782',
    email: 'test2@gmail.com',
    date: ''
  },  
  {
  userId: 3,
  userName: 'Zaki',
  phone: '01626478123',
  email: 'test3@gmail.com',
  date: ''
 }];

 useEffect(() => {
  setIsLoading(true)
/**   MenuService.getMenuList().then(
  (response) => {            
      console.log(response.data)
      setMenuList(response.data);
      setIsLoading(false)
  },(error) => {
    console.log(error)
    setIsError(true)
    setIsLoading(false)
  });**/
  setFormUsersList(getFormUserData)
  setIsLoading(false)
}, []);
const columns = [
    {
      title: "Name",
      dataIndex: "userName",
      key: 'userName',
      sorter: (a, b) => (a.userName > b.userName ? 1 : -1),
      render: (text: string) => <a href="/campaign-form-edit">{text}</a>
    },
    {
        title: "Phone",
        dataIndex: "phone",
        key: 'phone',
        sorter: (a, b) => (a.phone > b.phone ? 1 : -1),
        render: (text: string) => <a href="/campaign-form-edit">{text}</a>
    },
    {
        title: "Email",
        dataIndex: "email",
        key: 'email',
        sorter: (a, b) => (a.email > b.email ? 1 : -1),
        render: (text: string) => <a href="/campaign-form-edit">{text}</a>
    },
    {
        title: "Date",
        dataIndex: "date",
        key: 'date',
        sorter: (a, b) => (a.date > b.date ? 1 : -1),
        render: (text: date) => <a href="/campaign-form-edit">{text}</a>
    },

    {
      title: "Action",
      width: "20%",
      render: (text, record) => (
            <div>
            <Link to={`/campaign-form-user-details/${record.userId}`}>           
             <EditOutlined />
               </Link>
              
            </div>
          ),
    }
  ];



    return (
         <Fragment>
            <>
        {
          isLoading ? <div>Loading... </div> : 
          isError ? <div>Error Occured... </div> :
         <div><Breadcrumb>
             <Breadcrumb.Item>Home</Breadcrumb.Item>
             <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
             <Breadcrumb.Item><a href="/campaign-forms-list-table">Malaysia</a></Breadcrumb.Item>
         </Breadcrumb>
         <p><br/></p>
         <h1>Lucy</h1>
         <ContainerHeader />
         
       <Table
         columns={columns}
         dataSource={formUsersList}
         loading={isLoading}
         //onChange={handleTableChange}
         pagination={pagination}
         rowKey="userId"
       /></div>
 
       
        }    
     </>
      </Fragment>
    );
};

export default EditCampaignFormTable;
