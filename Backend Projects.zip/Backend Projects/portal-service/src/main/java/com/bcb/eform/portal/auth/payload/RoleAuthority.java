/**
 * 
 */
package com.bcb.eform.portal.auth.payload;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;
import com.bcb.eform.portal.model.User;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Component
public class RoleAuthority {
	
	  public Map<String,String> retrieveUserRoles(){
		  Map<String,String> userRoles = new HashMap<String,String>();
		 	 userRoles.put("0","ROLE_ADMIN");
			 userRoles.put("1","ROLE_CLIENT");
			 userRoles.put("default","ROLE_CLIENT"); 
		return userRoles;
		  
	  }
	  public List<String> retrieveUserRolesList(User user){
		  
		  //Map<String,String> userRoles = retrieveUserRoles();
		  List<String> userRolesList = new ArrayList<String>();
		  //String userRole = userRoles.get(user.getRole().toString());
		  //String userRole = "";
		  userRolesList.add("ROLE_CLIENT");
		  
		return userRolesList;
		  
	  }

}
