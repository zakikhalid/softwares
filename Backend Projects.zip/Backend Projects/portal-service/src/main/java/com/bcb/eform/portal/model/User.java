package com.bcb.eform.portal.model;

import java.time.LocalDateTime;
import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Entity
@Table(name = "user")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private long userId;
	
	@Column(name = "lan_id")
	private String lanId;
	
	@Column(name = "user_first_name")
	private String userFirstName;
	
	@Column(name = "user_last_name")
	private String userLastName;
	
	@Column(name = "user_email")
	private String userEmail;
	
	@Column(name = "user_mobile_number")
	private String userMobileNumber;
	
	@Column(name = "department_unit")
	private String departmentUnit;
	
	@Column(name = "staff_id")
	private String staffId;
	
	@Column(name = "country")
	private String country;
	
	@Column(name = "domain")
	private String domain;
	
	@Column(name = "api_role")
	private String apiRole;
	
	@Column(name = "user_status")
	private String userStatus;
	
	@Lob
	@Column(name = "user_avatar")
	private byte[] userAvatar; 
	
	@NotBlank
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date_time")
	private LocalDateTime createdDateTime;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_date_time")
	private LocalDateTime modifiedDateTime;

}
