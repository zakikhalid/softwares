/**
 * 
 */
package com.bcb.eform.portal.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bcb.eform.portal.model.UserScreenAccess;


/**
 * @author Muralikrishna Tammisetty
 *
 */
@Repository
public interface UserScreenAccessRepository extends JpaRepository<UserScreenAccess, Long> {

	public Optional<UserScreenAccess> findByUserId(String userId);
	public Optional<UserScreenAccess> findByScreenAccessId(long screenAccessId);

}
