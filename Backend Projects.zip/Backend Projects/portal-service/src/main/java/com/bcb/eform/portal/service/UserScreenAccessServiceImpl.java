/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;


import com.bcb.eform.portal.model.UserScreenAccess;

/**
 * @author Muralikrishna Tammisetty
 *
 */
public interface UserScreenAccessServiceImpl {
	
	public List<UserScreenAccess> getAllUserScreenAccess();
	public void saveUserScreenAccess(UserScreenAccess userScreenAccess);
	public UserScreenAccess getUserScreenAccessId(long userScreenAccessId);
	public void deleteUserScreenAccessById(long userScreenAccessId);
	
	public Optional<UserScreenAccess> findByUserId(String userId);
	public Optional<UserScreenAccess> findByScreenAccessId(long screenAccessId);

}
