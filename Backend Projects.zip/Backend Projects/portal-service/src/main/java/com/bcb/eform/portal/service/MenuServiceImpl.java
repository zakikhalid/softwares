/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.bcb.eform.portal.model.Menu;



/**
 * @author Muralikrishna Tammisetty
 *
 */
public interface MenuServiceImpl {
	
	public List<Menu> getAllMenus();
	public void saveMenu(Menu menu);
	public Menu findByMenuWithMenuId(long menuId);
	public void deleteMenuById(long menuId);
	public Optional<Menu> findByMenuName(String menuName);
	public Optional<Menu> findByMenuId(long menuId);
	
	//public List<Menu> getAllMenusByUserId(String userId);
	public List<Menu> getAllMenusByStaffId(String staffId);

	public Page<Menu> findByMenuName(String menuName, Pageable pageable);

	public Page<Menu> findByMenuLink(String menuLink, Pageable pageable);
	  
	public List<Menu> findByMenuName(String menuName, Sort sort);

}
