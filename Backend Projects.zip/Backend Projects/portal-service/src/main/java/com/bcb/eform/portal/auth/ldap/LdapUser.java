/**
 * 
 */
package com.bcb.eform.portal.auth.ldap;

/**
 * @author Muralikrishna Tammisetty
 *
 */
public class LdapUser {
	
	private String fullName; //displayname
	private String firstName; //givenname

	private String commonName; //cn //

	private String emailId; //userPrincipalName
	private String employeeId; //employeeid
	private String lastName; //sn
	private String distinguishedName;
	private String countryCode;
	private String userId; //samaccountname
	//private String Full Name //name
	private String organizationalUnit; //ou
	private String postalCode; //postalCode
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getCommonName() {
		return commonName;
	}
	public void setCommonName(String commonName) {
		this.commonName = commonName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getDistinguishedName() {
		return distinguishedName;
	}
	public void setDistinguishedName(String distinguishedName) {
		this.distinguishedName = distinguishedName;
	}
	public String getCountryCode() {
		return countryCode;
	}
	public void setCountryCode(String countryCode) {
		this.countryCode = countryCode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getOrganizationalUnit() {
		return organizationalUnit;
	}
	public void setOrganizationalUnit(String organizationalUnit) {
		this.organizationalUnit = organizationalUnit;
	}
	public String getPostalCode() {
		return postalCode;
	}
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	public LdapUser(String fullName, String firstName, String commonName, String emailId, String employeeId,
			String lastName, String distinguishedName, String countryCode, String userId, String organizationalUnit,
			String postalCode) {
		super();
		this.fullName = fullName;
		this.firstName = firstName;
		this.commonName = commonName;
		this.emailId = emailId;
		this.employeeId = employeeId;
		this.lastName = lastName;
		this.distinguishedName = distinguishedName;
		this.countryCode = countryCode;
		this.userId = userId;
		this.organizationalUnit = organizationalUnit;
		this.postalCode = postalCode;
	}
	public LdapUser() {
		super();
	}
	
	
	
	
	
	

}
