/**
 * 
 */
package com.bcb.eform.portal.auth.ldap;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.List;

import javax.naming.AuthenticationException;
import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.BasicAttribute;
import javax.naming.directory.BasicAttributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.directory.ModificationItem;
import javax.naming.directory.SearchControls;
import javax.naming.directory.SearchResult;

import org.springframework.stereotype.Component;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Component
public class LdapAuth {

	//public static DirContext directoryContextConnection;

	/* LDAP create connection during object creation */
	public DirContext newConnection(String ldapServerIPAdress, String ldapServerPort, String loginUserId, String loginUserPassword, String ldapServerAuthentication, String ldapServerUserDomainName) {
		// String ldapAdServer = "ldap://"+ "10.104.120.81" +":"+"389";
		// String principalName = "mycaps02" + "@" + "cimbmydev";
		DirContext directoryContextConnection = null;

		Hashtable<String, Object> environment = new Hashtable<String, Object>();
		environment.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
		environment.put(Context.PROVIDER_URL, "ldap://" + ldapServerIPAdress + ":" + ldapServerPort);
		environment.put(Context.SECURITY_PRINCIPAL, loginUserId + "@" + ldapServerUserDomainName);
		environment.put(Context.SECURITY_CREDENTIALS, loginUserPassword);
		environment.put(Context.SECURITY_AUTHENTICATION, ldapServerAuthentication);

		try {
		    directoryContextConnection = new InitialDirContext(environment);
			System.out.println("Hello World!" + directoryContextConnection);
		} catch (AuthenticationException ex) {
			System.out.println(ex.getMessage());
		} catch (NamingException e) {
			System.out.println(" NamingException " + e.getMessage());
		}
		environment = null;
		return directoryContextConnection;
	}

	/* LDAP addLdapUser */
	public List<LdapUser> retrieveAllLdapServerUsers(DirContext ldapServerSearchDirectoryContextConnection, String ldapServerSerachBaseUserContext) throws NamingException {
		String searchFilter = "(objectClass=person)";
		// String searchFilter = "(sAMAccountName=mycaps*)";
		String[] reqAtt = { "cn", "sn" };
		SearchControls controls = new SearchControls();
		controls.setSearchScope(SearchControls.SUBTREE_SCOPE);
		controls.setReturningAttributes(reqAtt);
		// controls.getCountLimit(1000);

		NamingEnumeration<SearchResult> users = ldapServerSearchDirectoryContextConnection.search(ldapServerSerachBaseUserContext, searchFilter, controls);
		List<LdapUser> ldapUsersList = new ArrayList<LdapUser>();
		SearchResult result = null;

		while (users.hasMore()) {
			result = (SearchResult) users.next();
			Attributes searchUserAttribute = result.getAttributes();
			LdapUser ldapUser = new LdapUser();
			if (searchUserAttribute != null) {
				ldapUser = retrieveLdapUserWithSearchUserAttribute(searchUserAttribute, ldapUser);
			}
			ldapUsersList.add(ldapUser);
		}
		// System.out.println("ldapUsersList Size "+ldapUsersList.size()+" ldapUsersList
		// "+ldapUsersList);
		return ldapUsersList;

	}

	/* LDAP addLdapUser */
	public void addLdapUser(String lastName, String firstName, DirContext ldapServerSearchDirectoryContextConnection, String addLdapUserContext) {
		Attributes attributes = new BasicAttributes();
		Attribute attribute = new BasicAttribute("objectClass");
		attribute.add("person");

		attributes.put(attribute);
		// user details
		attributes.put("sn", lastName);
		try {
			// ldapServerSearchDirectoryContextConnection.createSubcontext("cn="+firstName+",OU=CIMBMYDEV,DC=cimbmydev,DC=cimbdomaindev,DC=com",
			// attributes);
			ldapServerSearchDirectoryContextConnection.createSubcontext("cn=" + firstName + addLdapUserContext,
					attributes);
			System.out.println("success");
		} catch (NamingException ex) {
			System.out.println(ex.getMessage());
		}

	}

	/* LDAP addUserToGroup */
	// public void addUserToGroup(String username, String groupName)
	public void addUserToGroup(String firstName, String addLdapGroupUserContext, String addLdapUserContext, DirContext ldapServerSearchDirectoryContextConnection) {
		ModificationItem[] mods = new ModificationItem[1];
		Attribute attribute = new BasicAttribute("uniqueMember", "cn=" + firstName + addLdapUserContext);
		mods[0] = new ModificationItem(DirContext.ADD_ATTRIBUTE, attribute);
		try {
			ldapServerSearchDirectoryContextConnection.modifyAttributes("cn=" + firstName + addLdapGroupUserContext,
					mods);
			System.out.println("success");
		} catch (NamingException ex) {
			System.out.println(ex.getMessage());
		}

	}

	/* LDAP deleteUser */
	public void deleteUser(String firstName, String addLdapUserContext, DirContext ldapServerSearchDirectoryContextConnection) {
		try {
			ldapServerSearchDirectoryContextConnection.destroySubcontext("cn=" + firstName + addLdapUserContext);
			System.out.println("success");
		} catch (NamingException ex) {
			System.out.println(ex.getMessage());
		}
	}

	/* LDAP deleteUserFromGroup */
	public void deleteUserFromGroup(String firstName, String addLdapGroupUserContext, String addLdapUserContext, DirContext ldapServerSearchDirectoryContextConnection) {
		ModificationItem[] mods = new ModificationItem[1];
		Attribute attribute = new BasicAttribute("uniqueMember", "cn=" + firstName + addLdapUserContext);
		mods[0] = new ModificationItem(DirContext.REMOVE_ATTRIBUTE, attribute);
		try {
			ldapServerSearchDirectoryContextConnection.modifyAttributes("cn=" + addLdapGroupUserContext, mods);
			System.out.println("success");
		} catch (NamingException ex) {
			System.out.println(ex.getMessage());
		}

	}

	/* LDAP retrieveLdapServerLoginUser */
	public LdapUser retrieveLdapServerLoginUser(DirContext ldapServerSearchDirectoryContextConnection, String ldapServerSerachBaseUserContext, String ldapServerSerachFilter, String ldapServersearchAttribute)
			throws NamingException {

		SearchControls ldapSearchControls = new SearchControls();
		ldapSearchControls.setSearchScope(SearchControls.SUBTREE_SCOPE);

		NamingEnumeration<SearchResult> searchResultUsers = ldapServerSearchDirectoryContextConnection.search(ldapServerSerachBaseUserContext, ldapServerSerachFilter, ldapSearchControls);
		SearchResult searchResultUser = null;
		LdapUser ldapUser = new LdapUser();

		while (searchResultUsers.hasMoreElements()) {
			searchResultUser = (SearchResult) searchResultUsers.next();
			Attributes searchUserAttribute = searchResultUser.getAttributes();
			// System.out.println(" searchUserAttribute "+searchUserAttribute);
			// System.out.println(searchUserAttribute.get("employeeID"));
			if (searchUserAttribute != null) {
				ldapUser = retrieveLdapUserWithSearchUserAttribute(searchUserAttribute, ldapUser);
				// searchUserAttributeValue =
				// (searchUserAttribute.get("employeeID").toString());
			}
		}
		ldapSearchControls = null;
		searchResultUsers = null;
		searchResultUser = null;
		return ldapUser;

	}

	/* LDAP use this to authenticate any existing user */
	public boolean isLoginUserAuthenticated(String ldapServerIPAdress, String ldapServerPort, String loginUserId, String loginUserPassword, String ldapServerUserDomainName) {
		try {
			Hashtable<String, Object> env = new Hashtable<String, Object>();
			env.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.jndi.ldap.LdapCtxFactory");
			env.put(Context.PROVIDER_URL, "ldap://" + ldapServerIPAdress + ":" + ldapServerPort);
			env.put(Context.SECURITY_PRINCIPAL, loginUserId + "@" + ldapServerUserDomainName);
			env.put(Context.SECURITY_CREDENTIALS, loginUserPassword);

			DirContext con = new InitialDirContext(env);
			System.out.println("success");
			env = null;
			con.close();
			return true;
		} catch (Exception e) {
			System.out.println("failed: " + e.getMessage());
			return false;
		}
	}

	/* LDAP use this to update user password */
	public void updateUserPassword(DirContext directoryContextConnection, String firstName, String password, String addLdapUserContext) {
		try {
			String dnBase = addLdapUserContext;
			ModificationItem[] mods = new ModificationItem[1];
			mods[0] = new ModificationItem(DirContext.REPLACE_ATTRIBUTE, new BasicAttribute("userPassword", password));
			// if you want,then you can delete the old password and after that you can replace with new password
			directoryContextConnection.modifyAttributes("cn=" + firstName + dnBase, mods);// try to form DN dynamically
			System.out.println("success");
		} catch (Exception e) {
			System.out.println("failed: " + e.getMessage());
		}
	}

	public LdapUser retrieveLdapUserWithSearchUserAttribute(Attributes searchUserAttribute, LdapUser ldapUser) {
		Object displayName = searchUserAttribute.get("displayName");
		Object givenName = searchUserAttribute.get("givenName");
		Object cn = searchUserAttribute.get("cn");
		Object userPrincipalName = searchUserAttribute.get("userPrincipalName");
		Object employeeID = searchUserAttribute.get("employeeID");
		Object sn = searchUserAttribute.get("sn");
		Object distinguishedName = searchUserAttribute.get("distinguishedName");
		Object countryCode = searchUserAttribute.get("countryCode");
		Object sAMAccountName = searchUserAttribute.get("sAMAccountName");
		Object ou = searchUserAttribute.get("ou");
		Object postalCode = searchUserAttribute.get("postalCode");
		if ((displayName != null) && (!"".equalsIgnoreCase(displayName.toString()))) {
			ldapUser.setFullName(displayName.toString());
		}
		if ((givenName != null) && (!"".equalsIgnoreCase(givenName.toString()))) {
			ldapUser.setFirstName(givenName.toString());
		}
		if ((cn != null) && (!"".equalsIgnoreCase(cn.toString()))) {
			ldapUser.setCommonName(cn.toString());
		}
		if ((userPrincipalName != null) && (!"".equalsIgnoreCase(userPrincipalName.toString()))) {
			ldapUser.setEmailId(userPrincipalName.toString());
		}
		if ((employeeID != null) && (!"".equalsIgnoreCase(employeeID.toString()))) {
			ldapUser.setEmployeeId(employeeID.toString());
		}
		if ((sn != null) && (!"".equalsIgnoreCase(sn.toString()))) {
			ldapUser.setLastName(sn.toString());
		}
		if ((distinguishedName != null) && (!"".equalsIgnoreCase(distinguishedName.toString()))) {
			ldapUser.setDistinguishedName(distinguishedName.toString());
		}
		if ((countryCode != null) && (!"".equalsIgnoreCase(countryCode.toString()))) {
			ldapUser.setCountryCode(countryCode.toString());
		}
		if ((sAMAccountName != null) && (!"".equalsIgnoreCase(sAMAccountName.toString()))) {
			ldapUser.setUserId(sAMAccountName.toString());
		}
		if ((ou != null) && (!"".equalsIgnoreCase(ou.toString()))) {
			ldapUser.setOrganizationalUnit(ou.toString());
		}
		if ((postalCode != null) && (!"".equalsIgnoreCase(postalCode.toString()))) {
			ldapUser.setPostalCode(postalCode.toString());
		}
		displayName = null;
		givenName = null;
		cn = null;
		userPrincipalName = null;
		employeeID = null;
		sn = null;
		distinguishedName = null;
		countryCode = null;
		sAMAccountName = null;
		ou = null;
		postalCode = null;
		return ldapUser;
	}
	//525 - user not found
	//52e - invalid credentials
	//530 - not permitted to logon at this time
	//532 - password expired
	//533 - account disabled
	//701 - account expired
	//773 - user must reset password
	//775 - account locked out
    public String GetErrorDesription(String errorMsg) {
   	 //System.out.println("errorMsg>>>>>>"+errorMsg);
		String desplayErrorMessage = "";
		
		if (errorMsg.contains("52e")) {
			desplayErrorMessage = "CWEB-PORTAL : Login Failed.	";
		} else if (errorMsg.contains("532")) {
			desplayErrorMessage = "CWEB-PORTAL : Password expired. Please change the password.";
		} else if (errorMsg.contains("533")) {
			desplayErrorMessage = " CWEB-PORTAL : Account disabled.";
		} else if (errorMsg.contains("775")) {
			desplayErrorMessage = "CWEB-PORTAL : Account locked. Please retry again later.";
		}else if (errorMsg.contains("525")) {
			desplayErrorMessage = "CWEB-PORTAL : Login Failed.";
		}else if (errorMsg.contains("773")) {
			desplayErrorMessage = "CWEB-PORTAL : Password expired. Please change the password.";
		}else{
			desplayErrorMessage = "CWEB-PORTAL: Logon authentication failed.";
		}
			return desplayErrorMessage;
	}

}
