/**
 * 
 */
package com.bcb.eform.portal.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MenuDTO {
	
	private long menuId;//menuId
	private long parentId;//ParentId
	private String menuName;
	private String menuLink;
	private long menuOrder;
	private String createdBy;
	private LocalDateTime createdDateTime;
	private String modifiedBy;
	private LocalDateTime modifiedDateTime; 
	private boolean isError;
	private boolean isUpdated;
	private boolean isDeleted;
	private String message;

}
