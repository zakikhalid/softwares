/**
 * 
 */
package com.bcb.eform.portal.dto;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import java.util.stream.Collectors;

import org.springframework.stereotype.Component;


/**
 * @author Muralikrishna Tammisetty
 *
 */
@Component
public class MenuConstruction {
	private List<MenuDataDTO> parentMenuList = new ArrayList<MenuDataDTO>();
	private List<MenuDataDTO> childMenuList = new ArrayList<MenuDataDTO>();
	private List<MenuDataDTO> subChildMenuList = new ArrayList<MenuDataDTO>();

	public void createMenuSubMenuLists(List<MenuDataDTO> menuList) {
		for (MenuDataDTO menu : menuList) {
			if (menu.getParentId() > 0) {
				childMenuList.add(menu);

			} else {
				parentMenuList.add(menu);
			}
		}

		for (MenuDataDTO childMenu : childMenuList) {

			for (MenuDataDTO subchildMenu : childMenuList) {

				if (childMenu.getMenuId() == subchildMenu.getParentId()) {
					subChildMenuList.add(subchildMenu);
				}

			}

		}
		parentMenuList = sortedList(getDistinctMenu(parentMenuList));
		childMenuList = sortedList(getDistinctMenu(childMenuList));
		subChildMenuList = sortedList(getDistinctMenu(subChildMenuList));
	}

	public List<MenuDataDTO> getDistinctMenu(List<MenuDataDTO> menuList) {
		return menuList.stream()
				// .sorted(Comparator.comparingInt(Menu::getOrder))
				.distinct().collect(Collectors.toList());
	}

	public List<MenuDataDTO> sortedList(List<MenuDataDTO> unsortedMenusList) {
		List<MenuDataDTO> sortedMenusList = unsortedMenusList.stream()
				.sorted(Comparator.comparing(MenuDataDTO::getMenuOrder)).collect(Collectors.toList());
		return sortedMenusList;
	}

	public boolean isSubChildAvailable(long menuId) {
		boolean isSubChildAvailable = false;
		for (MenuDataDTO subChildMenu : subChildMenuList) {
			if (menuId == subChildMenu.getParentId()) {
				isSubChildAvailable = true;
				break;
			}
		}
		return isSubChildAvailable;

	}

	public String getUserMenu(List<MenuDataDTO> menuList) {
		String dynamicMenuString = "";
		createMenuSubMenuLists(menuList);

		for (MenuDataDTO parentMenu : parentMenuList) {
			dynamicMenuString += "<SubMenu key='" + parentMenu.getMenuId() + "' title={<span><span>"+ parentMenu.getMenuName() + "</span></span>}>";
			// System.out.println(" Parent Menu is " + parentMenu.getTitle());
			for (MenuDataDTO childMenu : childMenuList) {
				if (childMenu.getParentId() == parentMenu.getMenuId()) {
					if (isSubChildAvailable(childMenu.getMenuId())) {// Find childs there or not
						dynamicMenuString += "<SubMenu key='" + childMenu.getMenuId() + "' title='"+ childMenu.getMenuName() + "'>";
						// System.out.println(" Child Menu is " + childMenu.getTitle());
						for (MenuDataDTO subChildMenu : subChildMenuList) {

							if (subChildMenu.getParentId() == childMenu.getMenuId()) {
								// System.out.println(" Sub Child Menu is " + subChildMenu.getTitle());
								dynamicMenuString += "<Menu.Item key='" + subChildMenu.getMenuId() + "'>"+ subChildMenu.getMenuName() + "</Menu.Item>";
							}

						}
						dynamicMenuString += "</SubMenu>";
					} else {
						// System.out.println(" No Sub Child Menu is " + childMenu.getTitle());
						dynamicMenuString += "<Menu.Item key='" + childMenu.getMenuId() + "'>" + childMenu.getMenuName()+ "</Menu.Item>";
					}
				} //
			}
			dynamicMenuString += "</SubMenu>";
		}

		return dynamicMenuString;

	}
	public List<MenuDataDTO> parentMenuList(){
		return parentMenuList;		
	}
	public List<MenuDataDTO> childMenuList(){
		return childMenuList;		
	}
	public List<MenuDataDTO> subChildMenuList(){
		return subChildMenuList;		
	}
	public UserMenuDataDTO getUserMenuDataDTO(List<MenuDataDTO> menuDataDTOList) {
		createMenuSubMenuLists(menuDataDTOList);
		UserMenuDataDTO userMenuDataDTO = new UserMenuDataDTO(parentMenuList(),childMenuList(),subChildMenuList());
		return userMenuDataDTO;
	}
}
