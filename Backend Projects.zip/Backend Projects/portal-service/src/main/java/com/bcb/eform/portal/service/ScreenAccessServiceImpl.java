/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.bcb.eform.portal.model.ScreenAccess;



/**
 * @author Muralikrishna Tammisetty
 *
 */
public interface ScreenAccessServiceImpl {

	public List<ScreenAccess> getAllScreenAccess();
	public void saveScreenAccess(ScreenAccess screenAccess);
	public ScreenAccess getScreenAccessId(long screenAccessId);
	public void deleteScreenAccessById(long screenAccessId);
	public Optional<ScreenAccess> findByScreenAccessName(String screenAccessName);
	public Optional<ScreenAccess> findByScreenAccessId(long ScreenAccessId);
	
	public Page<ScreenAccess> findByScreenAccessName(String screenAccessName, Pageable pageable);

	public Page<ScreenAccess> findByScreenAccessDescription(String screenAccessDescription, Pageable pageable);
	  
	public List<ScreenAccess> findByScreenAccessName(String screenAccessName, Sort sort);
}
