import axios from "axios";
import authHeader from "../auth-header";
import ApiUtil from "../../util/Api";

const API_URL = ApiUtil.getRealUrl() + "api/productEform/";

const getListProductEform = async (page, size, sort, formType, formName, country) => {
    return await axios.get(API_URL + "getListProductEform", {
        // headers: authHeader(),
        params: {
            page: page,
            size: size,
            sort: sort,
            formName: formName,
            formType: formType,
            country: country
        }
    })
        .then((response) => {
            return response;
        });
};

const getProductEformById = async (id) => {
    return await axios.get(API_URL + id).then(
        (response) => {
            return response;
        });
}

const loadLabelsByEformId = async (page, size, sort, id) => {
    return await axios.get(API_URL + id + "/loadLabels", {
        params: {
            page: page,
            size: size,
            sort: sort
        }
    }).then(
        (response) => {
            return response;
        });
}

const updateStatus = async (id, status) => {
    return await axios.post(API_URL + "updateStatus", {
        id: id,
        status: status
    }).then(
        (response) => {
            return response;
        });
}

export default {
    getListProductEform,
    getProductEformById,
    loadLabelsByEformId,
    updateStatus
}