import axios from "axios";
import authHeader from "../auth-header";
import ApiUtil from "../../util/Api";

const API_URL = ApiUtil.getRealUrl() + "api/country/";

const getListCountry = async (page, size, sort) => {
    return await axios.get(API_URL + "list", {
        //headers: authHeader(),
        params: {
            page: page,
            size: size,
            sort: sort
        }
    }).then((response) => {
        return response;
    });
};

const insertCountry = async (values) => {
    return await axios.post(API_URL + "saveOrUpdate", values).then(
        (response) => {
            return response;
        });
}

const getCountryById = async (id) => {
    return await axios.get(API_URL + id).then(
        (response) => {
            return response;
        });
}

const deleteCountry = async (id) => {
    return await axios.delete(API_URL + "delete/" + id)
        .then((response) => {
            return response;
        });
}

export default {
    getListCountry,
    getCountryById,
    insertCountry,
    deleteCountry
}