import axios from "axios";
import authHeader from "../auth-header";
import ApiUtil from "../../util/Api";

const API_URL = ApiUtil.getRealUrl() + "api/apiWhiteList/";

const getListApiWhiteList = async (page, size, sort) => {
    return await axios.get(API_URL + "list", {
        // headers: authHeader(),
        params: {
            page: page,
            size: size,
            sort: sort
        }
    })
        .then((response) => {
            return response;
        });
};

const insertApiWhiteList = async (values) => {
    return await axios.post(API_URL + "saveOrUpdate", values).then(
        (response) => {
            return response;
        });
}

const getApiWhiteListById = async (id) => {
    return await axios.get(API_URL + id).then(
        (response) => {
            return response;
        });
}

const deleteApiWhiteList = async (id) => {
    return await axios.delete(API_URL + "delete/" + id)
        .then((response) => {
            return response;
        });
}

export default {
    getListApiWhiteList,
    getApiWhiteListById,
    insertApiWhiteList,
    deleteApiWhiteList
}