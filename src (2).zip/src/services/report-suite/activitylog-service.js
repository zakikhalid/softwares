import axios from "axios";
import authHeader from "../auth-header";

const API_URL = "http://localhost:8087/api/portal/activitylog/";

const listActivityLog = async (page, size, sort, userId) => {
    return await axios.get(API_URL + "list", {
        //headers: authHeader(),
        params: {
            page: page,
            size: size,
            sort: sort,
            userId: userId
        }
    }).then((response) => {
        return response;
    });
};

const insertActivityLog = (values) => {

    return axios.post(API_URL + "save", values).then(
        (response)=> {
            return response;
        });
}
export default {
    listActivityLog,
    insertActivityLog,
}