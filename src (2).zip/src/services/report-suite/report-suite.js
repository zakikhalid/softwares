import React from 'react'
import axios from "axios";
import authHeader from "../auth-header";
import ApiUtil from "../../util/Api";

const REPORT_SUITE_API_URL = ApiUtil.getRealUrl() + "api/reportsuite/";

const productEformNames = async (userId,country,formType) => {
    return await axios.get(REPORT_SUITE_API_URL+"productEformNames?userId="+userId+"&country="+country+"&formType="+formType, { headers: authHeader() });
};
const searchProductEformNames = async (userId,country,formType,productEform) => {
    return await axios.put(REPORT_SUITE_API_URL+"productEformNames?userId="+userId+"&country="+country+"&formType="+formType, productEform, { headers: authHeader() });
};
const productEformFieldDetailsList = async (productEformId,country,formType) => {
    return await axios.get(REPORT_SUITE_API_URL+"productEformFieldDetailsList?productEformId="+productEformId+"&country="+country+"&formType="+formType, { headers: authHeader() });
};
const productEformFieldDetails = async (productEformFieldDetailsId,country,formType) => {
    return await axios.get(REPORT_SUITE_API_URL+"productEformFieldDetails?productEformFieldDetailsId="+productEformFieldDetailsId+"&country="+country+"&formType="+formType, { headers: authHeader() });
};
const productEformDetailsExportCSV = async (productEformId,country,formType) => {
    return await axios.get(REPORT_SUITE_API_URL+"productEformDetailsDownloadCSV?productEformId="+productEformId+"&country="+country+"&formType="+formType, { headers: authHeader() });
};
export default {
    productEformNames,
    searchProductEformNames,
    productEformFieldDetailsList,
    productEformFieldDetails,
    productEformDetailsExportCSV,
};

