import React from 'react'

function ScreenAccessService() {
    return (
        <div>
            
        </div>
    )
}

export default ScreenAccessService
