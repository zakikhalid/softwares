import React from 'react'
import axios from "axios";
import authHeader from "../auth-header";
import ApiUtil from "../../util/Api";

const MENU_API_URL = ApiUtil.getRealUrl() + "api/menu/";


const addmenu = (menu) => {
    console.log('addmenu   '+menu)
    return axios.
    post(MENU_API_URL+"createMenu", menu, { headers: authHeader() })
        .then((response) => {
            console.log(" Response is "+response.data)
            return response;
        });
};
const updatemenu = (menuId,menu) => {
    console.log('updatemenu   '+menu)
    return axios.
    put(MENU_API_URL+"menuId/"+menuId, menu, { headers: authHeader() })
        .then((response) => {
            console.log(" Response is "+response.data)
            return response;
        });
};

const getMenuByMenuId = async (menuId) => {
    return await axios.get(MENU_API_URL+"menuId/"+menuId, { headers: authHeader() });
};
const getMenuList =  async () => {
      return await axios.get(MENU_API_URL, { headers: authHeader() });
};
const deleteMenuByMenuId = async (menuId) => {
    return await axios.delete(MENU_API_URL+menuId, { headers: authHeader() });
};

export default {
    addmenu,
    updatemenu,
    deleteMenuByMenuId,
    getMenuByMenuId,
    getMenuList,
};
