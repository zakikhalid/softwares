import axios from "axios";
import authHeader from "../auth-header";

const API_URL = "http://localhost:8087/api/portal/productgroup/";


const listProductGroup = async (page, size, sort, productGroupName, status) => {
    return await axios.get(API_URL + "list", {
       // headers: authHeader(),
        params: {
            page: page,
            size: size,
            sort: sort,
            productGroupName:productGroupName,
            status:status
        }
    }).then((response) => {
        return response;
    });
};

const updateUserGroup = (values) => {
    //console.log('updategroup   '+groupName)
    return axios.post(API_URL + "saveOrUpdate",values).then((response) => {
        //console.log(" Response is "+response.data)
        return response;
    }
    );
};

const getUserGroupById = async (id) => {
    return await axios.get(API_URL + id).then(
        (response) => {
            return response;
        });
}
export default {
    listProductGroup,
    updateUserGroup,
    getUserGroupById
}