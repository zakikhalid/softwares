import React, { useState, useEffect } from "react";
import { Breadcrumb, Descriptions, Button } from 'antd';
import { useLocation, Link } from "react-router-dom";
import ApiAuthService from "../../../services/applicationadmin/apiauth-service";
import TimeUtil from "../../../util/Time";

const ApiAuthView = () => {

    const { state } = useLocation();
    const [apiAuth, setApiAuth] = useState([]);
    

    useEffect(() => {
        getData();
    }, []);


    const getData = () => {
        let id = state.id;
        ApiAuthService.getApiAuthById(id).then(
            res => {
                if (res != null) {
                    setApiAuth(res.data);
                }
            }
        )
    }

    return (
        <div>
            <Breadcrumb>                
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>API Access Auth</Breadcrumb.Item>
                <Breadcrumb.Item>View</Breadcrumb.Item>
            </Breadcrumb>
            <p><br/></p>
            <Descriptions bordered>
                <Descriptions.Item label="Name">{apiAuth.name}</Descriptions.Item>                
                <Descriptions.Item label="Status" span={2}>{apiAuth.status}</Descriptions.Item>    
                <Descriptions.Item label="System ID">{apiAuth.systemId}</Descriptions.Item>
                <Descriptions.Item label="Signature" span={2}>{apiAuth.signature}</Descriptions.Item>          
                <Descriptions.Item label="Date Created">{apiAuth.createdDateTime ? TimeUtil.formatDate(apiAuth.createdDateTime) : 'n/a'} </Descriptions.Item>
                <Descriptions.Item label="Created By" span={2}>{apiAuth.createdBy ? apiAuth.createdBy : 'n/a'}</Descriptions.Item>
                <Descriptions.Item label="Date Modified">{apiAuth.modifiedDateTime ? TimeUtil.formatDate(apiAuth.modifiedDateTime) : 'n/a'}</Descriptions.Item>
                <Descriptions.Item label="Modified By" span={2}>{apiAuth.modifiedBy ? apiAuth.modifiedBy : 'n/a'}</Descriptions.Item>
            </Descriptions>
            <br/>
            <Link to={{ pathname: '/apiauth-list/' }}>
                <Button type="danger">Back</Button><br />
            </Link>
        </div>
    )

}

export default ApiAuthView;