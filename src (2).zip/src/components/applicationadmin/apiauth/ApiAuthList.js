import React, { useState, useEffect } from "react";
import { Breadcrumb, Button, Table, Space, Card, Form, Input, Select, Popconfirm, message } from 'antd';
import ApiAuthService from "../../../services/applicationadmin/apiauth-service";
import { Link, useHistory } from "react-router-dom";
import TimeUtil from "../../../util/Time";

const ApiAuthList = () => {

    const [pagination, setPagination] = useState({});
    const [pageNumber, setPageNumber] = useState(0);
    const [datasource, setDatasource] = useState([]);

    let page = 0;
    let size = 20;

    useEffect(() => {
        getData(page, size, '');
    }, []);

    const getData = (page, size, sort) => {
        ApiAuthService.getListApiAuth(page, size, sort).then(
            res => {
                console.log(res);
                setPagination({
                    onChange: (page, size) => {
                        getData(page - 1, size);
                        setPageNumber(page);
                    },
                    showTotal: (total, range) => `Total: ${total}`,
                    total: res.data.totalElements,
                    pageSize: size
                });
                if (res != null) {
                    setDatasource(
                        res.data.content.map(row => ({
                            key: row.apiId,
                            id: row.apiId,
                            name: row.name,
                            systemId: row.systemId,
                            signature: row.signature,
                            updatedBy: row.modifiedBy,
                            dateUpdated: TimeUtil.formatDate(row.modifiedDateTime),
                            status: row.status
                        }))
                    )
                }
            }
        );
    }

    const deleteData = (id) => {
        ApiAuthService.deleteApiAuth(id).then(
            response => {
                if (response.data === true) {
                    message.success("Delete ApiAuth successfully!", 5);
                    getData(pageNumber - 1, size, '');
                }
            }
        ).catch(e => {
            message.error("Error:" + e.response.data.httpStatus + "! " + e.response.data.message, 5);
        })
    }

    const columns = [
        {
            title: 'Name',
            dataIndex: 'name',
            // specify the condition of filtering result
            // here is that finding the name started with `value`  
            sorter: (a, b) => a.name.length - b.name.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: 'System ID',
            dataIndex: 'systemId',
        },
        {
            title: 'Signature',
            dataIndex: 'signature',
        },
        {
            title: 'Status',
            dataIndex: 'status',
        },
        {
            title: 'Date Updated',
            dataIndex: 'dateUpdated',
        },
        {
            title: 'Updated By',
            dataIndex: 'updatedBy',
        },
        {
            title: 'Action',
            dataIndex: 'action',
            render: (text, record) => (
                <Space size="middle">
                    <Link to={{ pathname: '/apiauth-view/' + record.id, state: { id: record.id } }}>View</Link>
                    <Link to={{ pathname: '/apiauth-update/' + record.id, state: { id: record.id } }}>Update</Link>
                    <Popconfirm placement="topLeft" title="Are you sure?" onConfirm={() => deleteData(record.id)} okText="Yes" cancelText="No">
                        <a href="#">Delete</a>
                    </Popconfirm>
                </Space>
            ),
        },
    ];

    function onChange(pagination, filters, sorter, extra) {
        console.log('params', pagination, filters, sorter, extra);
    }



    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>API Access Auth</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>API Access Auth</h1>
            <p align="right"><Button type="danger" href="/apiauth-add">Add Api Access</Button><br /></p>


            <Table columns={columns} dataSource={datasource} onChange={onChange} pagination={pagination} />
            <Button type="danger" href="/apiauth-add">Add Api Access</Button>


        </>
    );
}

export default ApiAuthList;