import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Radio, message, Breadcrumb } from 'antd';
import { useLocation, useHistory, Link } from 'react-router-dom';
import ApiAuthService from "../../../services/applicationadmin/apiauth-service";

const ApiAuthUpdate = () => {

    const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 5 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 10 },
        },
    };

    const tailFormItemLayout = {
        wrapperCol: {
            xs: {
                span: 24,
                offset: 0,
            },
            sm: {
                span: 3,
                offset: 10,
            },
        },
    };

    const { state } = useLocation();
    const [form] = Form.useForm();
    const history = useHistory();
    const [apiAuth, setApiAuth] = useState([]);
    const [current, setCurrent] = useState("");

    useEffect(() => {
        getData();
    }, []);

    const getData = () => {
        let id = state.id;
        ApiAuthService.getApiAuthById(id).then(
            res => {
                if (res != null) {
                    setApiAuth(res.data);
                    setCurrent(res.data.systemId);
                    form.setFieldsValue({
                        apiId: res.data.apiId,
                        name: res.data.name,
                        systemId: res.data.systemId,
                        signature: res.data.signature,
                        status: res.data.status
                    });
                }
            }
        )
    }

    const onFinish = (values) => {
        if (user != null) {
            apiAuth.modifiedBy = user.lanId;
        }
        apiAuth.name = values.name;
        apiAuth.systemId = values.systemId;
        apiAuth.signature = values.signature;
        apiAuth.status = values.status;
        let apiAuthReq = {
            apiAuth: apiAuth,
            currentSystemId: current
        }
        handleSubmit(apiAuthReq);
    };


    const { Search } = Input;

    const onGenerated = () => {
        var d = new Date().getTime();//Timestamp
        var d2 = (performance && performance.now && (performance.now() * 1000)) || 0;//Time in microseconds since page-load or 0 if unsupported
        let signature = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16;//random number between 0 and 16
            if (d > 0) {//Use timestamp until depleted
                r = (d + r) % 16 | 0;
                d = Math.floor(d / 16);
            } else {//Use microseconds since page-load if supported
                r = (d2 + r) % 16 | 0;
                d2 = Math.floor(d2 / 16);
            }
            return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
        });
        form.setFieldsValue({
            signature: signature,
        });
    };

    const user = window.JSON.parse(localStorage.getItem("user"));

    const handleSubmit = (values) => {
        if (user != null) {
            values.apiAuth.createdBy = user.lanId;
        }
        ApiAuthService.insertApiAuth(values).then(
            (response) => {
                if (response) {
                    message.success("Add API Access Auth successfully !", 5);
                    history.push('/apiauth-list');
                }
            }
        ).catch(e => {
            if (e.response.data.message === "duplicated-data") {
                message.error("Error:" + e.response.data.httpStatus + "! API Access Auth is existed : " + e.response.data.message, 5);
            } else {
                message.error("Error:" + e.response.data.message + "! ", 5);
            }
        });
    }

    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>API Access Auth</Breadcrumb.Item>
                <Breadcrumb.Item>Update</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Update</h1>
            <p><br /></p>

            <Form
                {...formItemLayout}
                form={form}
                layout="horizontal"
                initialValues={{
                    remember: true,
                }}
                onFinish={onFinish}
                size='large'>
                <Form.Item
                    name="apiId">
                    <Input type="hidden" />
                </Form.Item>
                <Form.Item
                    label="Name"
                    name="name"
                    rules={[{ required: true, message: 'Please input the name!' }]} >
                    <Input placeholder="Name" />
                </Form.Item>
                <Form.Item
                    label="System ID"
                    name="systemId"
                    rules={[{ required: true, message: 'Please input the system ID!' }]} >
                    <Input placeholder="System ID" />
                </Form.Item>
                <Form.Item
                    label="Signature"
                    name="signature"
                    rules={[{ required: true, message: 'Please input signature!' }]}>
                    <Search
                        placeholder="Signature"
                        enterButton="Generate!"
                        allowClear
                        size="large"
                        onSearch={onGenerated} />
                </Form.Item>
                <Form.Item label="Status"
                    name="status"
                    rules={[{ required: true, message: 'Please input status!' }]}>
                    <Radio.Group>
                        <Radio value={'Active'}>Active</Radio>
                        <Radio value={'Inactive'}>Inactive</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item {...tailFormItemLayout}>
                    <Button type="danger" htmlType="submit">
                        Update Api
                    </Button>
                </Form.Item>
            </Form>
        </>
    );
};

export default ApiAuthUpdate;