import React, { useState, useEffect } from "react";
import { Breadcrumb, Descriptions, Button } from 'antd';
import { useLocation, Link } from "react-router-dom";
import CountryService from "../../../services/applicationadmin/country-service";
import TimeUtil from "../../../util/Time";

const CountryView = () => {

    const { state } = useLocation();
    const [country, setCountry] = useState([]);

    useEffect(() => {
        getData();
    }, []);


    const getData = () => {
        let id = state.id;
        CountryService.getCountryById(id).then(
            res => {
                if (res != null) {
                    setCountry(res.data);
                }
            }
        )
    }


    return (
        <div>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>Country Code</Breadcrumb.Item>
                <Breadcrumb.Item>View</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <Descriptions bordered>
                <Descriptions.Item label="Country">{country.countryName}</Descriptions.Item>
                <Descriptions.Item label="Code">{country.code}</Descriptions.Item>
                <Descriptions.Item label="Status" span={4}>{country.status}</Descriptions.Item>
                <Descriptions.Item label="Date Created">{country.createdDateTime ? TimeUtil.formatDate(country.createdDateTime) : 'n/a'} </Descriptions.Item>
                <Descriptions.Item label="Created By" span={2}>{country.createdBy ? country.createdBy : 'n/a'}</Descriptions.Item>
                <Descriptions.Item label="Date Modified">{country.modifiedDateTime ? TimeUtil.formatDate(country.modifiedDateTime) : 'n/a'} </Descriptions.Item>
                <Descriptions.Item label="Modified By" span={2}>{country.modifiedBy ? country.modifiedBy : 'n/a'}</Descriptions.Item>
            </Descriptions>
            <br />
            <Link to={{ pathname: '/country-list/' }}>
                <Button type="danger">Back</Button><br />
            </Link>
        </div>
    )

}

export default CountryView;