import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Radio, message, Breadcrumb } from 'antd';
import CountryService from "../../../services/applicationadmin/country-service";
import { useLocation, useHistory, Link } from 'react-router-dom';


const CountryUpdate = () => {

    const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 5 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 10 },
        },
    };

    const tailFormItemLayout = {
        wrapperCol: {
            xs: {
                span: 24,
                offset: 0,
            },
            sm: {
                span: 3,
                offset: 10,
            },
        },
    };

    const { state } = useLocation();
    const [form] = Form.useForm();
    const history = useHistory();
    const [country, setCountry] = useState([]);
    const [current, setCurrent] = useState("");

    const user = window.JSON.parse(localStorage.getItem("user"));

    useEffect(() => {
        getData();
    },[]);

    const getData = () => {
        let id = state.id;
        CountryService.getCountryById(id).then(
            res => {
                if (res != null) {
                    setCountry(res.data);
                    setCurrent(res.data.code);
                    form.setFieldsValue({
                        countryId: res.data.countryId,
                        countryName: res.data.countryName,
                        code: res.data.code,
                        status: res.data.status
                    });
                }
            }
        )
    }

    const onFinish = (values) => {
        if (user != null) {
            country.modifiedBy = user.lanId;
        }
        country.countryName = values.countryName;
        country.code = values.code;
        country.status = values.status;
        let countryReq = {
            country: country,
            currentCode: current
        }
        handleSubmit(countryReq);
    };

    const handleSubmit = (countryReq) => {
        CountryService.insertCountry(countryReq).then(
            (response) => {
                if (response) {
                    message.success("Update country successfully !", 5);
                    history.push('/country-list');
                }
            }
        ).catch(e => {
            if (e.response.data.message === "duplicated-data") {
                message.error("Error:" + e.response.data.httpStatus + "! Code is existed : " + e.response.data.message, 5);
            } else {
                message.error("Error:" + e.response.data.message + "! ", 5);
            }
        });
    }

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };


    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
                <Breadcrumb.Item>Country Code</Breadcrumb.Item>
                <Breadcrumb.Item>Update</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Add Country</h1>
            <p><br /></p>

            <Form
                {...formItemLayout}
                layout="horizontal"
                size='large'
                initialValues={{
                    remember: true,
                }}
                form={form}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}>
                <Form.Item
                    name="countryId">
                    <Input type="hidden" />
                </Form.Item>
                <Form.Item
                    label="Country Name"
                    name="countryName"
                    rules={[{ required: true, message: 'Please input country name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item
                    label="Country Code"
                    name="code"
                    rules={[{ required: true, message: 'Please input country code!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Status"
                    name="status"
                    rules={[{ required: true, message: 'Please input status!' }]}>
                    <Radio.Group>
                        <Radio value={'Active'}>Active</Radio>
                        <Radio value={'Inactive'}>Inactive</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item {...tailFormItemLayout}>
                    <Button type="danger" htmlType="submit">
                        Update Country
                    </Button>
                </Form.Item>
            </Form>
        </>
    );
};

export default CountryUpdate;