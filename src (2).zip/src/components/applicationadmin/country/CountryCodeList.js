import React, { useState, useEffect } from "react";
import { Breadcrumb, Button, Table, Space, Card, Form, Input, Select, Popconfirm, message } from 'antd';
import CountryService from "../../../services/applicationadmin/country-service";
import { Link, useHistory } from "react-router-dom";
import TimeUtil from "../../../util/Time";

const CountryCode = () => {

    const [pagination, setPagination] = useState({});
    const [pageNumber, setPageNumber] = useState(0);
    const [datasource, setDatasource] = useState([]);

    let page = 0;
    let size = 20;

    useEffect(() => {
        getData(page, size, '');
    }, []);

    const getData = (page, size, sort) => {
        CountryService.getListCountry(page, size, sort).then(
            res => {
                if (res != null) {
                    setPagination({
                        onChange: (page, size) => {
                            getData(page - 1, size);
                            setPageNumber(page);
                        },
                        showTotal: (total, range) => `Total: ${total}`,
                        total: res.data.totalElements,
                        pageSize: size
                    });
                    setDatasource(
                        res.data.content.map(row => ({
                            key: row.countryId,
                            id: row.countryId,
                            country: row.countryName,
                            code: row.code.toUpperCase(),
                            updatedBy: row.modifiedBy,
                            dateUpdated: TimeUtil.formatDate(row.modifiedDateTime),
                            status: row.status ? row.status : 'NO FIELDS',
                            createdBy: row.createdBy,
                        }))
                    )
                }
            }
        );
    }

    const deleteData = (id) => {
        CountryService.deleteCountry(id).then(
            response => {
                if (response.data === true) {
                    message.success("Delete Country successfully!", 5);
                    getData(pageNumber - 1, size, '');
                }
            }
        ).catch(e => {
            message.error("Error:" + e.response.data.httpStatus + "! " + e.response.data.message, 5);
        })
    }

    const columns = [
        {
            title: 'Country',
            dataIndex: 'country',
            sorter: (a, b) => a.country.length - b.country.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: 'Code',
            dataIndex: 'code',
        },
        {
            title: 'Status',
            dataIndex: 'status',
        },
        {
            title: 'Date Updated',
            dataIndex: 'dateUpdated',
        },
        {
            title: 'Update By',
            dataIndex: 'updatedBy',
        },
        {
            title: 'Action',
            key: 'action',
            render: (text, record) => (
                <Space size="middle">
                    <Link to={{ pathname: '/country-view/' + record.id, state: { id: record.id } }}>View</Link>
                    <Link to={{ pathname: '/country-update/' + record.id, state: { id: record.id } }}>Update</Link>
                    <Popconfirm placement="topLeft" title="Are you sure?" onConfirm={() => deleteData(record.id)} okText="Yes" cancelText="No">
                        <a href="#">Delete</a>
                    </Popconfirm>
                </Space>
            ),
        }
    ];

    function onChange(pagination, filters, sorter, extra) {
        console.log('params', pagination, filters, sorter, extra);
    }



    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>Country Code</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Country Code</h1>
            <p align="right"><Button type="danger" href="/country-add">Add Country</Button><br /></p>


            <Table columns={columns} dataSource={datasource} onChange={onChange} pagination={pagination} />
            <Button type="danger" href="/country-add">Add Country</Button>


        </>
    );
}

export default CountryCode;