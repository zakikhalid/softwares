import React, { useState } from 'react';
import { Form, Input, Button, Radio, message, Breadcrumb } from 'antd';
import { useHistory, Link } from 'react-router-dom';
import CountryService from "../../../services/applicationadmin/country-service";

const CountryCodeAdd = () => {

    const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 5 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 10 },
        },
    };

    const tailFormItemLayout = {
        wrapperCol: {
            xs: {
                span: 24,
                offset: 0,
            },
            sm: {
                span: 3,
                offset: 10,
            },
        },
    };

    const history = useHistory();

    const onFinish = (values) => {
        if(user != null) {
            values.createdBy = user.lanId;
        }
        values.createdBy = user.lanId;
        let countryReq = {
            country: values,
            currentCode: ''
        }
        handleSubmit(countryReq);
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    const user = window.JSON.parse(localStorage.getItem("user"));

    const handleSubmit = (values) => {
        CountryService.insertCountry(values).then(
            (response) => {
                if (response) {
                    message.success("Add country successfully !", 5);
                    history.push('/country-list');
                }
            }
        ).catch(e => {
            if(e.response.data.message === "duplicated-data") {
                message.error("Error:" + e.response.data.httpStatus +"! Code is existed : " + e.response.data.message, 5);
            } else {
                message.error("Error:" + e.response.data.message +"! ", 5);
            }
        });
    }

    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
                <Breadcrumb.Item>Country Code</Breadcrumb.Item>
                <Breadcrumb.Item>Ađd</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Add Country</h1>
            <p><br /></p>

            <Form
                {...formItemLayout}
                layout="horizontal"
                size='large'
                initialValues={{
                    remember: true,
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}>
                <Form.Item
                    label="Country Name"
                    name="countryName"
                    rules={[{ required: true, message: 'Please input country name!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item
                    label="Country Code"
                    name="code"
                    rules={[{ required: true, message: 'Please input country code!' }]}>
                    <Input />
                </Form.Item>
                <Form.Item label="Status"
                    name="status"
                    rules={[{ required: true, message: 'Please input status!' }]}>
                    <Radio.Group>
                        <Radio value={'Active'}>Active</Radio>
                        <Radio value={'Inactive'}>Inactive</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item {...tailFormItemLayout}>
                    <Button type="danger" htmlType="submit">
                        Add Country
                    </Button>
                </Form.Item>
            </Form>
        </>
    );
};

export default CountryCodeAdd;