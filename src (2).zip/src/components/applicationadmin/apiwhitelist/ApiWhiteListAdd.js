import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Radio, message, Breadcrumb, Select } from 'antd';
import { useHistory, Link } from 'react-router-dom';
import ApiAuthService from "../../../services/applicationadmin/apiauth-service";
import ApiWhitellistService from "../../../services/applicationadmin/apiwhitelist-service";

const ApiWhiteListAdd = () => {

    const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 5 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 10 },
        },
    };

    const tailFormItemLayout = {
        wrapperCol: {
            xs: {
                span: 24,
                offset: 0,
            },
            sm: {
                span: 3,
                offset: 10,
            },
        },
    };

    const history = useHistory();
    const [apiAuths, setApiAuths] = useState([]);

    useEffect(() => {
        loadAllApiAuth();
    }, []);

    const loadAllApiAuth = () => {
        ApiAuthService.getListApiAuth(null, null, '').then(
            res => {
                if (res != null) {
                    setApiAuths(
                        res.data.content.map(row => ({
                            key: row.apiId,
                            id: row.apiId,
                            systemId: row.systemId
                        }))
                    );
                }
            }
        )
    }

    const onFinish = (values) => {
        if (user != null) {
            values.createdBy = user.lanId;
        }
        let apiWhiteListReq = {
            apiWhiteList: values,
            currentIpAddress: ''
        }
        handleSubmit(apiWhiteListReq);
    };

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };

    const user = window.JSON.parse(localStorage.getItem("user"));

    const handleSubmit = (values) => {
        ApiWhitellistService.insertApiWhiteList(values).then(
            (response) => {
                if (response != null) {
                    console.log(response);
                    message.success("Add API Whitelist successfully !", 5);
                    history.push('/apiwhitelist-list');
                }
            }
        ).catch(e => {
            if (e.response.data.message === "duplicated-data") {
                message.error("Error:" + e.response.data.httpStatus + "! IP Address is existed : " + e.response.data.message, 5);
            } else {
                message.error("Error:" + e.response.data.message + "! ", 5);
            }
        });
    }

    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
                <Breadcrumb.Item>API Whitelist</Breadcrumb.Item>
                <Breadcrumb.Item>Ađd</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Update API Whitelist</h1>
            <p><br /></p>

            <Form
                {...formItemLayout}
                layout="horizontal"
                initialValues={{
                    remember: true,
                }}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                size='large' >
                <Form.Item
                    label="IP Address"
                    name="ipAddress"
                    rules={[{ required: true, message: 'Please input IP Address' },
                    {
                        pattern: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
                        message: 'Please input right format for IP Address',
                    }]}>
                    <Input placeholder="IP Address" />
                </Form.Item>
                <Form.Item
                    label="System ID"
                    name="apiAuthId"
                    rules={[{ required: true, message: 'Please input System ID!' }]}>
                    <Select placeholder="System ID">
                        {
                            apiAuths.map(
                                (item) => (
                                    <Select.Option key={item.id} value={item.id}>
                                        {item.systemId}
                                    </Select.Option>
                                )
                            )
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="Status"
                    name="status"
                    rules={[{ required: true, message: 'Please input status!' }]}>
                    <Radio.Group>
                        <Radio value={'Active'}>Active</Radio>
                        <Radio value={'Inactive'}>Inactive</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item {...tailFormItemLayout}>
                    <Button type="danger" htmlType="submit">
                        Add API Whitelist
                </Button>
                </Form.Item>
            </Form>
        </>
    );
};

export default ApiWhiteListAdd;