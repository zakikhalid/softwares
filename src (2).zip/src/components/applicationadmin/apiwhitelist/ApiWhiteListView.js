import React, { useState, useEffect } from "react";
import { Breadcrumb, Descriptions, Button } from 'antd';
import { useLocation, Link } from "react-router-dom";
import CountryService from "../../../services/applicationadmin/country-service";
import ApiWhitellistService from "../../../services/applicationadmin/apiwhitelist-service";
import TimeUtil from "../../../util/Time";

const ApiWhiteListView = () => {

    const { state } = useLocation();
    const [apiWhiteList, setApiWhiteList] = useState([]);


    useEffect(() => {
        getData();
    }, []);


    const getData = () => {
        let id = state.id;
        ApiWhitellistService.getApiWhiteListById(id).then(
            res => {
                if (res != null) {
                    setApiWhiteList(res.data);
                }
            }
        )
    }


    return (
        <div>
            <Breadcrumb>                
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>API Whitelist</Breadcrumb.Item>
                <Breadcrumb.Item>View</Breadcrumb.Item>
            </Breadcrumb>
            <p><br/></p>
            <Descriptions bordered>
                <Descriptions.Item label="IP Address" span={4}>{apiWhiteList.ipAddress}</Descriptions.Item>
                <Descriptions.Item label="System ID">{apiWhiteList.systemId}</Descriptions.Item>
                <Descriptions.Item label="Status" span={2}>{apiWhiteList.status}</Descriptions.Item>          
                <Descriptions.Item label="Date Created">{apiWhiteList.createdDateTime ? TimeUtil.formatDate(apiWhiteList.createdDateTime) : 'n/a'} </Descriptions.Item>
                <Descriptions.Item label="Created By" span={2}>{apiWhiteList.createdBy ? apiWhiteList.createdBy : 'n/a'}</Descriptions.Item>
                <Descriptions.Item label="Date Modified">{apiWhiteList.modifiedDateTime ? TimeUtil.formatDate(apiWhiteList.modifiedDateTime) : 'n/a'} </Descriptions.Item>
                <Descriptions.Item label="Modified By" span={2}>{apiWhiteList.modifiedBy ? apiWhiteList.modifiedBy : 'n/a'}</Descriptions.Item>
            </Descriptions>
            <br/>
            <Link to={{ pathname: '/apiwhitelist-list/' }}>
                <Button type="danger">Back</Button><br />
            </Link>
        </div>
    )

}

export default ApiWhiteListView;