import React, { useState, useEffect } from 'react';
import { Form, Input, Button, Radio, message, Breadcrumb, Select } from 'antd';
import ApiAuthService from "../../../services/applicationadmin/apiauth-service";
import ApiWhitellistService from "../../../services/applicationadmin/apiwhitelist-service";
import { useLocation, useHistory, Link } from 'react-router-dom';


const ApiWhiteListUpdate = () => {

    const formItemLayout = {
        labelCol: {
            xs: { span: 24 },
            sm: { span: 5 },
        },
        wrapperCol: {
            xs: { span: 24 },
            sm: { span: 10 },
        },
    };

    const tailFormItemLayout = {
        wrapperCol: {
            xs: {
                span: 24,
                offset: 0,
            },
            sm: {
                span: 3,
                offset: 10,
            },
        },
    };

    const { state } = useLocation();
    const [form] = Form.useForm();
    const history = useHistory();
    const [apiWhiteList, setApiWhiteList] = useState([]);
    const [apiAuths, setApiAuths] = useState([]);
    const [current, setCurrent] = useState("");

    const user = window.JSON.parse(localStorage.getItem("user"));

    useEffect(() => {
        loadAllApiAuth();
        getData();
    }, []);

    const loadAllApiAuth = () => {
        ApiAuthService.getListApiAuth(null, null, '').then(
            res => {
                if (res != null) {
                    setApiAuths(
                        res.data.content.map(row => ({
                            key: row.apiId,
                            id: row.apiId,
                            systemId: row.systemId
                        }))
                    );
                }
            }
        )
    }

    const getData = () => {
        let id = state.id;
        ApiWhitellistService.getApiWhiteListById(id).then(
            res => {
                if (res != null) {
                    setApiWhiteList(res.data);
                    setCurrent(res.data.ipAddress);
                    form.setFieldsValue({
                        apiWhiteListId: res.data.apiWhiteListId,
                        apiAuthId: res.data.apiAuthId,
                        ipAddress: res.data.ipAddress,
                        status: res.data.status
                    });
                }
            }
        )
    }

    const onFinish = (values) => {
        if (user != null) {
            apiWhiteList.modifiedBy = user.lanId;
        }
        apiWhiteList.apiAuthId = values.apiAuthId;
        apiWhiteList.ipAddress = values.ipAddress;
        apiWhiteList.status = values.status;
        let ApiWhiteListReq = {
            apiWhiteList: apiWhiteList,
            currentIpAddress: current
        }
        handleSubmit(ApiWhiteListReq);
    };

    const handleSubmit = (ApiWhiteListReq) => {
        ApiWhitellistService.insertApiWhiteList(ApiWhiteListReq).then(
            (response) => {
                if (response) {
                    message.success("Update API Whitelist successfully !", 5);
                    history.push('/apiwhitelist-list');
                }
            }
        ).catch(e => {
            if (e.response.data.message === "duplicated-data") {
                message.error("Error:" + e.response.data.httpStatus + "! Ip Address is existed : " + e.response.data.message, 5);
            } else {
                message.error("Error:" + e.response.data.message + "! ", 5);
            }
        });
    }

    const onFinishFailed = (errorInfo) => {
        console.log('Failed:', errorInfo);
    };


    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
                <Breadcrumb.Item>API Whitelist</Breadcrumb.Item>
                <Breadcrumb.Item>Ađd</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Update API Whitelist</h1>
            <p><br /></p>

            <Form
                {...formItemLayout}
                layout="horizontal"
                initialValues={{
                    remember: true,
                }}
                form={form}
                onFinish={onFinish}
                onFinishFailed={onFinishFailed}
                size='large' >
                <Form.Item
                    name="apiWhiteListId">
                    <Input type="hidden" />
                </Form.Item>
                <Form.Item
                    label="IP Address"
                    name="ipAddress"
                    rules={[{ required: true, message: 'Please input IP Address' },
                    {
                        pattern: /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
                        message: 'Please input right format for IP Address',
                    }]}>
                    <Input placeholder="IP Address" />
                </Form.Item>
                <Form.Item
                    label="System ID"
                    name="apiAuthId"
                    rules={[{ required: true, message: 'Please input System ID!' }]}>
                    <Select placeholder="System ID">
                        {
                            apiAuths.map(
                                (item) => (
                                    <Select.Option key={item.id} value={item.id}>
                                        {item.systemId}
                                    </Select.Option>
                                )
                            )
                        }
                    </Select>
                </Form.Item>
                <Form.Item label="Status"
                    name="status"
                    rules={[{ required: true, message: 'Please input status!' }]}>
                    <Radio.Group>
                        <Radio value={'Active'}>Active</Radio>
                        <Radio value={'Inactive'}>Inactive</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item {...tailFormItemLayout}>
                    <Button type="danger" htmlType="submit">
                        Update API Whitelist
                </Button>
                </Form.Item>
            </Form>
        </>
    );
};

export default ApiWhiteListUpdate;