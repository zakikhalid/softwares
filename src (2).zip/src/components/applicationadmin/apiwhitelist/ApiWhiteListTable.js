import React, { useState, useEffect } from "react";
import { Breadcrumb, Button, Table, Space, Card, Form, Input, Select, Popconfirm, message } from 'antd';
import ApiWhiteListService from "../../../services/applicationadmin/apiwhitelist-service";
import { Link, useHistory } from "react-router-dom";
import TimeUtil from "../../../util/Time";

const ApiWhiteListTable = () => {

    const [pagination, setPagination] = useState({});
    const [pageNumber, setPageNumber] = useState(0);
    const [datasource, setDatasource] = useState([]);

    let page = 0;
    let size = 20;

    useEffect(() => {
        getData(page, size, '');
    }, []);

    const getData = (page, size, sort) => {
        ApiWhiteListService.getListApiWhiteList(page, size, sort).then(
            res => {
                if (res != null) {
                    setPagination({
                        onChange: (page, size) => {
                            getData(page - 1, size);
                            setPageNumber(page);
                        },
                        showTotal: (total, range) => `Total: ${total}`,
                        total: res.data.totalElements,
                        pageSize: size
                    });
                    setDatasource(
                        res.data.content.map(row => ({
                            key: row.apiWhiteListId,
                            id: row.apiWhiteListId,
                            ipAddress: row.ipAddress,
                            systemId: row.systemId,
                            updatedBy: row.modifiedBy,
                            dateUpdated: TimeUtil.formatDate(row.modifiedDateTime),
                            status: row.status ? row.status : 'NO FIELDS',
                            createdBy: row.createdBy,
                        }))
                    )
                }
            }
        );
    }

    const deleteData = (id) => {
        ApiWhiteListService.deleteApiWhiteList(id).then(
            response => {
                if (response.data === true) {
                    message.success("Delete Api Whitelist successfully!", 5);
                    getData(pageNumber - 1, size, '');
                }
            }
        ).catch(e => {
            message.error("Error:" + e.response.data.httpStatus + "! " + e.response.data.message, 5);
        })
    }


    const columns = [
        {
            title: 'IP Address',
            dataIndex: 'ipAddress',
            // specify the condition of filtering result
            // here is that finding the name started with `value` 
            sorter: (a, b) => a.name.length - b.name.length,
            sortDirections: ['descend', 'ascend'],
        },
        {
            title: 'System ID',
            dataIndex: 'systemId',
        },
        {
            title: 'Status',
            dataIndex: 'status',
        },
        {
            title: 'Date Updated',
            dataIndex: 'dateUpdated',
        },
        {
            title: 'Update By',
            dataIndex: 'updatedBy',
        },
        {
            title: 'Action',
            dataIndex: 'action',
            render: (text, record) => (
                <Space size="middle">
                    <Link to={{ pathname: '/apiwhitelist-view/' + record.id, state: { id: record.id } }}>View</Link>
                    <Link to={{ pathname: '/apiwhitelist-update/' + record.id, state: { id: record.id } }}>Update</Link>
                    <Popconfirm placement="topLeft" title="Are you sure?" onConfirm={() => deleteData(record.id)} okText="Yes" cancelText="No">
                        <a href="#">Delete</a>
                    </Popconfirm>
                </Space>
            ),
        },
    ];

    function onChange(pagination, filters, sorter, extra) {
        console.log('params', pagination, filters, sorter, extra);
    }



    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Application Admin</Breadcrumb.Item>
                <Breadcrumb.Item>API Whitelist</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>API Whitelist</h1>
            <p align="right"><Button type="danger" href="/apiwhitelist-add">Add API Whitelist</Button><br /></p>


            <Table columns={columns} dataSource={datasource} onChange={onChange} pagination={pagination} />
            <br/>
            <Button type="danger" href="/apiwhitelist-add">Add API Whitelist</Button>

        </>
    );
}

export default ApiWhiteListTable;