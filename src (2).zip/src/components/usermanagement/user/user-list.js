import React from "react";
import { Breadcrumb, Button } from 'antd';
import Table from '../TablePage/index';

function userMaintenance() {
    return (
        <div>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>
            <a href="">IT Security</a>
            </Breadcrumb.Item>
            <Breadcrumb.Item>
            <a href="">User Maintenance</a>
            </Breadcrumb.Item>
            <Breadcrumb.Item>List</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>User Maintenance</h1>
        <p align="right"><Button type="danger" href="/userMaintenanceAdd">Add New</Button><br/></p>
        <Table/>
        </div>
    );
}

export default userMaintenance;