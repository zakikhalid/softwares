import React, { Fragment, useState, useContext, useEffect } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputField, inputPasswordField, SelectField, SwitchField, inputNumberField, SelectMenuField } from "../../../containers/Inputs";
import {Button,InputNumber,Breadcrumb} from "antd";
import { QuestionCircleOutlined } from '@ant-design/icons';
import "../../../styles/eform/eform-general.less";
import MenuService  from "../../.././services/usermanagement/menu-service";
const AddMenuForm = () => {
    const defaultValues = {
        parentId: 1,
        menuName:"",
        menuLink:"",
        menuOrder: 1
    }
    const [isLoading, setIsLoading] = useState(false);
    const [isError, setIsError] = useState(false);
    //const [isSuccess, setIsSuccess] = useState(false);
    //const [message, setMessage] = useState('');
    const [menuList, setMenuList] = useState([{menuId:'', menuName:""}]);
    const { handleSubmit, control, errors, reset } = useForm({defaultValues});
    
    useEffect(() => {
        setIsLoading(true)
        MenuService.getMenuList().then(
            (response) => {            
                console.log(response.data)
                setMenuList(response.data)
                setIsLoading(false)
            },(error) => {
                console.log(error)
                setIsError(false)
                setIsLoading(false)
                //alert(error.response.data);
            });
    }, []);
    const onSubmit = (data) => {
        console.log("AddMenuForm ",data);
        MenuService.addmenu(data).then(
            (response) => {            
                console.log(response.data)
                //setIsSuccess(true)
                //setMessage("Menu Created Successfully!..");
                //setIsSuccess(false)
            },(error) => {
              console.log(error)
              //setIsError(false)
              //setIsLoading(false)
                //alert(error.response.data);
            });
        setTimeout(() => reset({
            parentId:1,
			menuName:'',
			menuLink:'',
			menuOrder: 1,
		}), 1000);
    }
    return (
        <Fragment>
            <>
            {
        //  isSuccess ? <div>{message} </div> :
         isLoading ? <div>Loading... </div> : 
         isError ? <div>Error Occured... </div> :
        <div>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>User Management</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menu-list">Menu Maintenance</a></Breadcrumb.Item>
            <Breadcrumb.Item>Add New Menu</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance - Add Menu</h1>
        <p><br/></p>        				
            <form onSubmit={handleSubmit(onSubmit)}>
            
                <div className='input-group'>
                    <label className='label'>Parent Menu </label>
                    <Controller as={SelectMenuField(menuList[0].menuName,menuList)} name='parentId' control={control} rules={{required:true}}/>
                    {errors.parentId && (<span className='error'>Parent Menu is required</span>)}                
                </div>
                <div className='input-group'>
                    <label className='label'>Menu Title   </label>
                    <Controller as={inputField("Menu Name")} name='menuName' control={control} defaultValue={''} rules={{ required: true }} />
                    {errors.menuName && (<span className='error'>Menu Title is required</span>)}
                </div>
                <div className='input-group'>
                    <label className='label'>Menu Link  </label>
                    <Controller as={inputField("Menu Link")} name='menuLink' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.menuLink && (<span className='error'>Menu Link is required</span>)}
                </div>
               <div className='input-group'>
                    <label className='label'>Order Number  </label>
                    <Controller as={inputNumberField("Menu Order")} name='menuOrder' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.menuOrder && (<span className='error'>Menu Order is required</span>)}
                </div>

                <Button type='danger'  htmlType='submit'>Add Menu</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button type='danger'  htmlType='button' onClick={() => {
                    reset({
                        parentId:1,
			            menuName:'',
			            menuLink:'',
			            menuOrder: 1,
                    });
                }}>Reset</Button>                

            </form>
            </div>  
    }
    </>
      </Fragment>
    );
};

export default AddMenuForm;
