import React, { Fragment, useState, useEffect } from 'react';
import { Breadcrumb, Descriptions } from "antd";
import { useParams } from "react-router-dom";
import MenuService  from "../../.././services/usermanagement/menu-service";


const MenuDetails = () => {
    const params = useParams();
    const [isLoading, setIsLoading] = useState(false);
    const [isError, setIsError] = useState(false);
    const [parentMenu, setParentMenu] = useState({menuId:'', menuName:""});
//    const [menuList, setMenuList] = useState([{menuId:'', menuName:""}]);
    const [selectedMenu, setSeletedMenu] = useState({menuId:'', parentId:'', menuName:'', menuLink:'',menuOrder:''});
    useEffect(() => {
        //const menuId = params.menuId;
        console.log(" menuId is "+params.menuId)
        setIsLoading(true)
        MenuService.getMenuList().then(
            (response) => {            
                console.log(response.data)
                //setMenuList(response.data)
                getMenuData(params.menuId,response.data)
                //setIsLoading(false)
            },(error) => {
                console.log(error)
                setIsError(true)
                setIsLoading(false)
                //alert(error.response.data);
            });
        
    }, []);
        const getMenuData = (menuId,menuListData) => {
            setIsLoading(true)
            MenuService.getMenuByMenuId(menuId).then(
                (response) => {            
                    console.log(response.data)
                    setSeletedMenu(response.data);
                    const selectedParentMenu = menuListData.find(menu => menu.menuId === parseInt(response.data.parentId));
                    console.log('selectedParentMenu '+selectedParentMenu.menuName)
                    setParentMenu(selectedParentMenu)
                    setIsLoading(false);
                },(error) => {
                  console.log(error);
                  setIsError(true)
                  setIsLoading(false)
                    //alert(error.response.data);
                });
        }
    return (
       <Fragment>
            <>
            {/* <div>Hello{selectedMenu.menuName}</div> */}
        {
         isLoading ? <div>Loading... </div> : 
         isError ? <div>Error Occured... </div> :
        <div>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>User Management</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menu-list">Menu Maintenance</a></Breadcrumb.Item>
            <Breadcrumb.Item>Menu Details</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance - Menu Details</h1>
        <p><br/></p>
            <Descriptions bordered>
                <Descriptions.Item label="Parent Menu" span={4}>{parentMenu.menuName}</Descriptions.Item>
                <Descriptions.Item label="Menu Title" span={3}>{selectedMenu.menuName}</Descriptions.Item>
                <Descriptions.Item label="Menu Link" span={3}>{selectedMenu.menuLink}</Descriptions.Item>
                <Descriptions.Item label="Order Number" span={3}>{selectedMenu.menuOrder}</Descriptions.Item>
            </Descriptions>
        </div>  
    } 
    </>
      </Fragment> 
    );
}

export default MenuDetails;
