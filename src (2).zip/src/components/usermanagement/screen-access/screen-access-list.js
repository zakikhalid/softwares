import React from "react";
import { Breadcrumb, Button } from 'antd';
import Table from '../TablePage/index';

const columns = [
  {
    title: 'Country',
    dataIndex: 'country',
    // specify the condition of filtering result
    // here is that finding the name started with `value`
    render: (text: string) => <a href="/countryCodeEdit">{text}</a>,    
    sorter: (a, b) => a.country.length - b.country.length,
    sortDirections: ['ascen'],
  },
  {
    title: 'Code',
    dataIndex: 'code',
  },
];

const data = [
  {
    key: '1',
    country: 'Malaysia',
    code: 'MY',
  },
  {
    key: '2',
    country: 'Singapore',
    code: 'SG',
  },
  {
    key: '3',
    country: 'Thailand',
    code: 'TH',
  },
  {
    key: '4',
    country: 'Vietnam',
    code: 'VN',
  },
  {
    key: '5',
    country: 'Philippine',
    code: 'PH',
  },
];

  function onChange(pagination, filters, sorter, extra) {
    console.log('params', pagination, filters, sorter, extra);
  }

function rolesMaintenance() {
    return (
      <div>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>IT Security</Breadcrumb.Item>
            <Breadcrumb.Item><a href="">Roles Maintenance</a></Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Roles Maintenance</h1>
        <p align="right"><Button type="danger" href="/rolesMaintenanceAdd">Add New</Button><br/></p>

        <Table columns={columns} dataSource={data} onChange={onChange} />
        <Button type="danger" href="/rolesMaintenanceAdd">Add New</Button>
        
      </div>
    );
}

export default rolesMaintenance;