import React, { Fragment, useEffect, useState } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputLoginField } from "../../../containers/Inputs";
import { Button, Breadcrumb, Card, Table, Form, Input, Select } from "antd";
import { useParams, Link } from "react-router-dom";
import ContainerHeader from '../../ContainerHeader/index';
import UserGroupService from '../../../services/Permission/usergroup-service';
import TimeUtil from "../../../util/Time";

const UserGroupListTable = () => {
    const { Meta } = Card;
    const [pagination, setPagination] = useState({});
    const [pageNumber, setPageNumber] = useState(0);
    const [datasource, setDatasource] = useState([]);
    const defaultValues = {
        searchGroupName: '',
        status: ''
    };
    let page = 0;
    let size = 20;

    const { handleSubmit, control, errors, reset } = useForm({ defaultValues })
    const onSubmit = (data) => {
        //console.log("UserGroupListTable",data);
    }

    useEffect(() => {
        getData(page, size, '', '', '');
    }, []);

    const getData = (page, size, sort, productGroupName, status) => {
        console.log(getData)
        UserGroupService.listProductGroup(page, size, sort, productGroupName, status).then(
            res => {
                if (res != null) {
                    setPagination({
                        onChange: (page, size) => {
                            getData(page - 1, size, sort, productGroupName, status);
                            setPageNumber(page);
                        },
                        showTotal: (total, range) => `Total: ${total}`,
                        total: res.data.totalElements,
                        pageSize: size
                    });
                    setDatasource(
                        res.data.content.map(row => ({
                            key: row.productGroupId,
                            id: row.productGroupId,
                            productGroupName: row.productGroupName,
                            createdBy: row.createdBy,
                            createdDateTime: row.createdDateTime,
                            updatedBy: row.modifiedBy ? row.modifiedBy : 'N/A',
                            dateUpdated: TimeUtil.formatDate(row.modifiedDateTime),
                            status: row.status ? row.status : 'NO FIELDS',


                        }))
                    )
                }
            }
        );
    }

    // const onReset = () => {
    //     console.log(reset)
    //     reset({
    //         productGroupName:'',
    //         status:''
    //     });
    //     getData(page, size, '', '', '')
    // }

    const onReset = () => {
        getData(page, size, '', '', '')
    }

    const onFinish = (values) => {
        console.log(values.productGroupName);
        if (typeof values.productGroupName === "undefined") {
            values.productGroupName = ""
        }
        if (typeof values.status === "undefined") {
            values.status = ""
        }
        getData(page, size, '', values.productGroupName, values.status);
    };

    const columns = [
        {
            title: "Name",
            dataIndex: "productGroupName",
            sorter: (a, b) => (a.groupName > b.groupName ? 1 : -1)
        },
        {
            title: "Date Created",
            dataIndex: "createdDateTime"
        },
        {
            title: "Updated by",
            dataIndex: "updatedBy"
        },
        {
            title: "Status",
            dataIndex: "status"
        },
        {
            title: "Action",
            render: (text, record) => (
                <div>
                    <Link to={{ pathname: '/user-group-update/' + record.id, state: { id: record.id } }}>Update</Link>
                </div>
            ),
        }
    ]

    return (
        <Fragment>
            <>
                {
                    <div>
                        <Breadcrumb>
                            <Breadcrumb.Item>Home</Breadcrumb.Item>
                            <Breadcrumb.Item>Permission</Breadcrumb.Item>
                            <Breadcrumb.Item><a href="/user-group-list">User Group</a></Breadcrumb.Item>
                        </Breadcrumb>
                        <p><br /></p>
                        <h1>User Group</h1>
                        <ContainerHeader />
                        <Card title="Search">
                            <Form name="horizontal_login" layout="inline" size="small" onFinish={onFinish} onReset={onReset}>
                                <Form.Item name="productGroupName"><Input placeholder="User Group Name" /></Form.Item>
                                <Form.Item name="status">
                                    <Select placeholder="Status" style={{ width: 200 }}>
                                        <Select.Option value="Active">Active</Select.Option>
                                        <Select.Option value="Inactive">Inactive</Select.Option>
                                    </Select>
                                </Form.Item>
                                <Form.Item>
                                    <Button htmlType="submit">Search</Button>
                                    <Button htmlType="reset"> 
                                        Reset </Button>
                                </Form.Item>
                            </Form>
                        </Card>
                        <Table
                            columns={columns}
                            dataSource={datasource}
                            // loading={}
                            pagination={pagination}
                        />
                    </div>
                }
            </>
        </Fragment>
    );
};

export default UserGroupListTable;