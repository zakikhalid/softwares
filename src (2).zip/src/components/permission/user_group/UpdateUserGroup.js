import React, { useState, useEffect, Fragment } from 'react';
import { useLocation, useHistory, Link } from 'react-router-dom';
import UserGroupService from '../../../services/Permission/usergroup-service';
import ContainerHeader from '../../ContainerHeader/index';
import { inputField } from "../../../containers/Inputs"
import { Breadcrumb, Descriptions, Form, Input, Radio, Button, message } from "antd"
import { useForm, Controller } from "react-hook-form";
import activitylogService from '../../../services/report-suite/activitylog-service';

const UpdateUserGroup = () => {
    const { state } = useLocation();
    const [usergroup, setUserGoup] = useState([]);
    const [userGroupForm] = Form.useForm(); //1
    const [current, setCurrent] = useState("");
    const history = useHistory();
    const [activitylog] = useState({});

    const user = window.JSON.parse(localStorage.getItem("user"));

    //const {userGroupId, setUserGroupId} = useState(0);

    useEffect(() => {
        getData();
    }, []);

    const getData = () => {
        let id = state.id;
        UserGroupService.getUserGroupById(id).then(
            res => {
                if (res != null) {
                    console.log(res.data);
                    setUserGoup(res.data);
                    setCurrent(res.data.status)
                    console.log(res.data.status);
                    userGroupForm.setFieldsValue({ //2
                        productGroupId: res.data.productGroupId,
                        productGroupName: res.data.productGroupName,
                        status: res.data.status
                    });
                }
            }
        )
    }

    const onFinish = (values) => {
        console.log(values);
        if (user != null) {
            usergroup.modifiedBy = user.lanId;
            activitylog.userId = user.lanId;
        }
        // usergroup.id = values.id
        usergroup.status = values.status;

        //activitylog
        activitylog.action ="Update";
        activitylog.screen = "Update User Group Screen";
        activitylog.status = "Success";
        handleSubmit(usergroup, activitylog);
    };

    const handleSubmit = (usergroup) => {
        console.log(usergroup)
        activitylogService.insertActivityLog(activitylog);
        UserGroupService.updateUserGroup(usergroup).then(
            (response) => {
                if (response) {
                    message.success("Update User Group successfully !", 5);
                    history.push('/user-group-list');
                }
            }
        )
    }

    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Permission</Breadcrumb.Item>
                <Breadcrumb.Item>User Group</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Edit</h1>
            <Form
                style={{marginLeft:"10%"}}
                layout="horizontal"
                size='large'
                initialValues={{
                    remember: true,
                }}
                form={userGroupForm}
                onFinish={onFinish}>
                <Form.Item
                    name="productGroupId">
                    <Input type="hidden" />
                </Form.Item>
                <Form.Item
                    label="User Group Name"
                    name="productGroupName"
                    rules={[{ required: true, message: 'Please input country name!' }]}>
                    <Input disabled style={{ width:"60%" }} />
                </Form.Item>
                <Form.Item label="Status"
                    name="status"
                    style={{marginLeft:"7.5%"}}
                    //rules={[{ required: true, message: 'Please input status!' }]}
                    >
                    <Radio.Group>
                        <Radio value={'Active'}>Active</Radio>
                        <Radio value={'Inactive'}>Inactive</Radio>
                    </Radio.Group>
                </Form.Item>
                <Form.Item>
                    <Button type="danger" htmlType="submit" >
                        Update
                    </Button>
                </Form.Item>
            </Form>
        </>
    );
}

export default UpdateUserGroup