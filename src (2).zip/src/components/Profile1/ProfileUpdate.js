import React from 'react'

const ProfileUpdate = () => {
    return (
        <h1>haii</h1>
    )
}

export default ProfileUpdate