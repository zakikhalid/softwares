import React from 'react'
import { Fragment } from 'react'
import ContainerHeader from '../ContainerHeader'
import Widget from "components/Widget";
import { Card, Tabs, Col, Row, Button } from "antd";
import Auxiliary from "util/Auxiliary";


const ProfileList = () => {
    const user = JSON.parse(localStorage.getItem('user'));
    const TabPane = Tabs.TabPane;
    const aboutList = [
        {
          title: 'Department',
          icon: 'company',
          userInfo: [user.departmentUnit]
        },
        {
          title: 'Country',
          icon: '',
          userInfo: [user.country]
        },
        {
          title: 'Role',
          icon: 'role',
          userInfo: [user.roleUserGroupId]
        },
        {
          title: 'Contact No',
          icon: 'phone',
          userInfo: [user.userMobileNumber]
        },
        {
          title: 'Email',
          icon: 'email',
          userInfo: [user.userEmail]
        }
    ]

    const userGroupList = [
        {
          title: 'User Group',
          icon: 'link',
          // desc: [<span className="gx-link" key={2}>www.cimb.com</span>]
        },
    ];


    return (
        <Fragment>
            <>
                {
                    <div>
                        <ContainerHeader />
                        <Row gutter={16}>
                            <Col className="gutter-row" span={16}>
                                <Widget title={user.userFirstName+" Profile"} styleName="gx-card-tabs gx-card-profile">
                                    <Tabs className='gx-tabs-right' defaultActiveKey="1">
                                        <TabPane tab="Overview" key="1">
                                            <div className="gx-mb-2">
                                                <Row>
                                                    {aboutList.map((data, index) =>
                                                        <Col key={index} xl={8} lg={12} md={12} sm={12} xs={24}>
                                                            {/* <AboutItem data={about}/> */}
                                                            <Auxiliary>
                                                                <div className="gx-media gx-flex-nowrap gx-mt-3 gx-mt-lg-4 gx-mb-2">
                                                                    <div className="gx-mr-3">
                                                                        <i className={`icon icon-${data.icon} gx-fs-xlxl gx-text-orange`}/>
                                                                    </div>
                                                                    <div className="gx-media-body">
                                                                        <h6 className="gx-mb-1 gx-text-grey">{data.title}</h6>
                                                                        {/* {userList === '' ? null : userList} */}
                                                                        {data.userInfo === '' ? null : <p className="gx-mb-0">{data.userInfo}</p>}
                                                                    </div>
                                                                </div>
                                                            </Auxiliary>
                                                        </Col>
                                                    )}
                                                </Row>
                                            </div>
                                        </TabPane>
                                    </Tabs>
                                </Widget>
                            </Col>
                            <Col className="gutter-row" span={8}>
                                <Widget title="User Group" styleName="gx-card-profile-sm">
                                    {userGroupList.map((data, index) =>
                                    <div key={index} className="gx-media gx-align-items-center gx-flex-nowrap gx-pro-contact-list">
                                        <div className="gx-mr-3">
                                            <i className={`icon icon-${data.icon} gx-fs-xxl gx-text-grey`}/>
                                        </div>
                                        <div className="gx-media-body">
                                            <span className="gx-mb-0 gx-text-grey gx-fs-sm">{data.title}</span>
                                            {/* <p className="gx-mb-0">{data.desc}</p> */}
                                        </div>
                                    </div>
                                    )}
                                </Widget>
                            </Col>
                        </Row>
                        <Button type="danger" href="/profile-update">Update My Profile</Button>
                    </div>
                }
            </>
        </Fragment>
    )
}

export default ProfileList