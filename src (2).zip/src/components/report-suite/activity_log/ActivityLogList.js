import React, { useState, useEffect } from "react";
import { Table, Breadcrumb, Form, Input, Button, Card, DatePicker, Select, Space } from 'antd';
import activitylogService from "../../../services/report-suite/activitylog-service";
import TimeUtil from "../../../util/Time";
import { FileExcelOutlined } from '@ant-design/icons';
import moment from 'moment';
const { RangePicker } = DatePicker;


function onChange(pagination, filters, sorter, extra) {
    console.log('params', pagination, filters, sorter, extra);
}

const ActivityLogList = () => {

    const [pagination, setPagination] = useState({});
    const [pageNumber, setPageNumber] = useState(0);
    const [datasource, setDatasource] = useState([]);

    let page = 0;
    let size = 20;

    useEffect(() => {
        getData(page, size, '', '', '');
    }, []);

    const getData = (page, size, sort, userId) => {
        activitylogService.listActivityLog(page, size, sort, userId).then(
            res => {
                if (res != null) {
                    setPagination({
                        onChange: (page, size) => {
                            getData(page - 1, size, sort, userId);
                            setPageNumber(page);
                        },
                        showTotal: (total, range) => `Total: ${total}`,
                        total: res.data.totalElements,
                        pageSize: size
                    });
                    setDatasource(
                        res.data.content.map(row => ({
                            key: row.recordId,
                            recID: row.recordId,
                            userID: row.userId,
                            date: TimeUtil.formatDate(row.createdDateTime),
                            fromIP: row.ip,
                            Screen: row.screen,
                            accessKey: row.accessKey,
                            status: row.status ? row.status : "N/A",
                            action: row.action,
                        }))
                    )
                }
            }
        );
    }

    const columns = [
        {
            title: 'Rec ID',
            dataIndex: 'recID'
        },
        {
            title: 'User ID',
            dataIndex: 'userID'
        },
        {
            title: 'Date',
            dataIndex: 'date'
        },
        {
            title: 'From IP',
            dataIndex: 'fromIP'
        },
        {
            title: 'Screen',
            dataIndex: 'Screen'
        },
        {
            title: 'Action',
            dataIndex: 'action'
        },
        {
            title: 'Access Key',
            dataIndex: 'accessKey'
        },
        {
            title: 'Status',
            dataIndex: 'status'
        }
    ];
    const [form] = Form.useForm();

    const onFinish = (values) => {
        console.log(values.userID)
        let fromDate = moment(values.date[0]);
        let toDate = moment(values.date[1]);
        console.log("sini", fromDate)
        console.log("sana", toDate)
        if (typeof values.userID === "undefined") {
            values.UserID = ""
        }
        if (typeof values.date === "undefined") {
            values.date = ""
        }
        getData(page, size, '', values.userID, values.date);
    };

    const onReset = (values) => {
        getData(page, size, '', '', '');
        console.log('Reset:', values);
    };

    const activityLogExportCSV = () => {
        // activitylogService.listActivityLog(page, size, sort, userId,).then(
        //     (response) => {
        //         console.log(response.data)
        //     }, (error) => {
        //         console.log(error)
        //     }
        // );
    }

    return (
        <div>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
                <Breadcrumb.Item>Malaysia</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <h1>Activity Log</h1>

            <Card title="Search">
                <Form form={form} name="horizontal_login" layout="inline" onFinish={onFinish} onReset={onReset} size="small">

                    {/* <Controller
                        render={(props) => (
                            <RangePicker
                                {...props}
                                format="DD-MM-YYYY"
                                //value={[props.value && moment(props.value[0]), props.value && moment(props.value[1])]}
                                onChange={(e) => {
                                    props.onChange(e);
                                    console.log("onChange" + e);
                                }}
                            />
                        )}
                        control={control}
                        name="startEndDate" defaultValue=''
                        rules={{ required: true }}
                        defaultValue=""
                    /> */}


                    <Form.Item name="date" >
                        <RangePicker
                            //format="DD-MM-YYYY"
                            //value={[value && moment(value[0]),value && moment(value[1])]}
                            onChange={(e) => {
                                //onChange(e);
                                console.log("onChange " + e);
                            }}
                        />
                    </Form.Item>
                    <Form.Item name="userID">
                        <Input placeholder="LAN ID" />
                    </Form.Item>
                    <Form.Item>
                        <Button htmlType="submit">Search</Button>
                        <Button htmlType="reset">Reset</Button>
                        <Button htmlType='button' onClick={activityLogExportCSV}><FileExcelOutlined />Export To Excel</Button>
                    </Form.Item>
                </Form>
            </Card>

            <Table
                columns={columns}
                dataSource={datasource}
                onChange={onChange}
                pagination={pagination} />

        </div>
    );
}
export default ActivityLogList;