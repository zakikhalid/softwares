import React, { Fragment, useState, useEffect } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputLoginField } from "../../../containers/Inputs";
import { Button, InputNumber, Breadcrumb, Table, Card, Form, DatePicker, Input } from "antd";
import { useParams, Link } from "react-router-dom";
import { EditOutlined, DeleteOutlined,FileExcelOutlined } from '@ant-design/icons';
import MenuService  from "../../.././services/usermanagement/menu-service";
import ContainerHeader from '../../ContainerHeader/index';
import "../../../styles/eform/eform-general.less";

const EditLucyFormTable = () => {
const params = useParams();
const { RangePicker } = DatePicker;
const { Meta } = Card;
const defaultValues = {
       startEndDate:'',
       Keyword:''
}

const { handleSubmit, control, errors, reset, setValue } = useForm({defaultValues});
const [isLoading, setIsLoading] = useState(false);
const [isError, setIsError] = useState(false);
const [formUsersList, setFormUsersList] = useState([]);
const [pagination, setPagination] = useState({});
const getFormUserData = [    
  {
      userId: 1,
      userName: 'Krishna',
      phone: 90432434432,
      email: 'test@gmail.com',
      date: ''
  },
  {
    userId: 2,
    userName: 'Sharul',
    phone: 90432434432,
    email: 'test2@gmail.com',
    date: ''
  },  
  {
  userId: 3,
  userName: 'Zaki',
  phone: 90432434432,
  email: 'test3@gmail.com',
  date: ''
 }];

 useEffect(() => {
  setIsLoading(true)
/**   MenuService.getMenuList().then(
  (response) => {            
      console.log(response.data)
      setMenuList(response.data);
      setIsLoading(false)
  },(error) => {
    console.log(error)
    setIsError(true)
    setIsLoading(false)
  });**/
  setFormUsersList(getFormUserData)
  setIsLoading(false)
}, []);
const columns = [
    {
      title: "Name",
      dataIndex: "userName",
        key: 'userName',
         sorter: (a, b) => (a.userName > b.userName ? 1 : -1),
      render: (text: string) => <a href="/lucy-form-edit">{text}</a>
    },
    {
        title: "Phone",
        dataIndex: "phone",
          key: 'phone',
           sorter: (a, b) => (a.phone > b.phone ? 1 : -1),
        render: (text: number) => <a href="/lucy-form-edit">{text}</a>
    },
    {
        title: "Email",
        dataIndex: "email",
          key: 'email',
           sorter: (a, b) => (a.email > b.email ? 1 : -1),
        render: (text: string) => <a href="/lucy-form-edit">{text}</a>
    },
    {
        title: "Date",
        dataIndex: "date",
          key: 'date',
           sorter: (a, b) => (a.date > b.date ? 1 : -1),
        render: (text: date) => <a href="/lucy-form-edit">{text}</a>
    },

    {
      title: "Action",
      width: "20%",
      render: (text, record) => (
            <div>
            <Link to={`/lucy-form-user-details/${record.userId}`}>           
             <EditOutlined />
               </Link>
              
            </div>
          ),
    }
  ];


  const [form] = Form.useForm();
  const onFinish = (values) => {
    console.log('Finish:', values);
  };
  const onSubmit = (data) => {
    console.log("EditLucyFormTable ",data);
    
}
    return (
         <Fragment>
            <>
        {
          isLoading ? <div>Loading... </div> : 
          isError ? <div>Error Occured... </div> :
         <div><Breadcrumb>
             <Breadcrumb.Item>Home</Breadcrumb.Item>
             <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
             <Breadcrumb.Item><a href="/lucy-forms-list-table">Malaysia</a></Breadcrumb.Item>
         </Breadcrumb>
         <p><br/></p>
         <h1>Lucy</h1>
         <ContainerHeader />
         <Card>
            <Meta title="Search" description="Filter date and name"
            />
            <form onSubmit={handleSubmit(onSubmit)} >
                <div className='input-flex-group'>
        <Controller
            render={(props) => (
              <RangePicker
                {...props}
                format="DD-MM-YYYY"
                onChange={(e) => {
                  props.onChange(e);
                  console.log("onChange"+e);
                }}
              />
            )}
            control={control}
            name="startEndDate" defaultValue=''
            rules={{ required: true }}
            defaultValue=""
          />{errors.startEndDate && (<span className='error'>Start and End Date is required</span>)}

                </div>
                <div className='input-flex-group'>
                <Controller as={inputLoginField("Keyword")} name='keyword' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.keyword && (<span className='error'>Menu Link is required</span>)}
                </div>
                <div className='input-flex-group'>
                <Button   htmlType='submit'>Search</Button>
                <Button   htmlType='button' onClick={() => {
                    reset({
                      startEndDate:'',
                      Keyword:''
                  });
              }}>Reset</Button>   
                <Button   htmlType='submit'><FileExcelOutlined />Export to Excel</Button>
                </div>
            </form>
          </Card>

       <Table
         columns={columns}
         dataSource={formUsersList}
         loading={isLoading}
         //onChange={handleTableChange}
         pagination={pagination}
         rowKey="userId"
       /></div>
 
       
        }    
     </>
      </Fragment>
    );
};

export default EditLucyFormTable;
