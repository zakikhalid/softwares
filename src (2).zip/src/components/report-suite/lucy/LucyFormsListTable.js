import React, { useState, useEffect  } from 'react';
import { Table, Switch, Space, Breadcrumb, Button, Popconfirm, Divider } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
//import ContainerHeader from 'ContainerHeader/index';
import ContainerHeader from '../../ContainerHeader/index';
import { Link } from 'react-router-dom';

const LucyFormsListTable = () => {
    const [isLoading, setIsLoading] = useState(false);
    const [isError, setIsError] = useState(false);
    const [formNamesList, setFormNamesList] = useState([]);
    const [pagination, setPagination] = useState({});
    const getFormData = [    
        {
            formId: 1,
            formName: 'Petronas Saving Account'
        },
        {
          formId: 2,
          formName: 'ECO Saving Account'

        }
      ];
    
    useEffect(() => {
        setIsLoading(true)
    /**   MenuService.getMenuList().then(
        (response) => {            
            console.log(response.data)
            setMenuList(response.data);
            setIsLoading(false)
        },(error) => {
          console.log(error)
          setIsError(true)
          setIsLoading(false)
        });**/
        setFormNamesList(getFormData)
        setIsLoading(false)
      }, []);
  
    const columns = [
        {
          title: "Name",
          dataIndex: "formName",
            key: 'formName',
             sorter: (a, b) => (a.formName > b.formName ? 1 : -1),
          render: (text: string) => <a href="/lucy-form-edit">{text}</a>
        },
   
        {
          title: "Action",
          width: "20%",
          render: (text, record) => (
                <div>
                <Link to={`/lucy-form-edit/${record.formId}`}>           
                 <EditOutlined />
                   </Link>
                  
                </div>
              ),
        }
      ];
    return (
        <>
        {
          isLoading ? <div>Loading... </div> : 
          isError ? <div>Error Occured... </div> :
         <div><Breadcrumb>
             <Breadcrumb.Item>Home</Breadcrumb.Item>
             <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
             <Breadcrumb.Item><a href="/lucy-forms-list-table">Malaysia</a></Breadcrumb.Item>
         </Breadcrumb>
         <p><br/></p>
         <h1>Lucy</h1>
         <ContainerHeader />
         
       <Table
         columns={columns}
         dataSource={formNamesList}
         loading={isLoading}
         //onChange={handleTableChange}
         pagination={pagination}
         rowKey="formId"
       /></div>
 
       
        }    
     </>
    );
}

export default LucyFormsListTable;
