import React, { Fragment, useState, useEffect } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputKeywordField, SelectFormField } from "../../../containers/Inputs";
import { Button, InputNumber, Breadcrumb, Table, Card, Form, DatePicker, Input } from "antd";
import { useParams, Link } from "react-router-dom";
import { EditOutlined, DeleteOutlined,FileExcelOutlined } from '@ant-design/icons';
import ReportSuiteService  from "../../../services/report-suite/report-suite";
import ContainerHeader from '../../ContainerHeader/index';
import "../../../styles/eform/eform-general.less";

const LucyFormFieldsDetailsList = () => {
const params = useParams();
const { RangePicker } = DatePicker;
const { Meta } = Card;
const defaultValues = {
       startEndDate:'',
       Keyword:'',
       formFieldId:'0'
}

const { handleSubmit, control, errors, reset, setValue } = useForm({defaultValues});
const [isLoading, setIsLoading] = useState(false);
const [isError, setIsError] = useState(false);
//const [formUsersList, setFormUsersList] = useState([]);
const [formColumnsList, setFormColumnsList] = useState([]);
const [formDataList, setFormDataList] = useState([]);
const [pagination, setPagination] = useState({});
//const [formFieldList, setFormFieldList] = useState([{formFieldId:'0', formFieldIdName:""}]);
const [formFieldLabel, setFormFieldLabel] = useState([{formFieldName:'', formFieldLabelName:''}]);

const actionColumn = [   {
  title: "Action",
  width: "20%",
  render: (text, record) => (
        <div>
        <Link to={`/lucy-form-fields-details/${record.formFieldDetailsId}`}>           
         <EditOutlined />
           </Link>
          
        </div>
      ),
}]


 useEffect(() => {
   console.log("params.productEformId "+params.productEformId)
  setIsLoading(true)
  ReportSuiteService.productEformFieldDetailsList(params.productEformId,"my","lucy").then(
  (response) => {            
      console.log(response.data)
      setFormColumnsList(response.data.formFieldColumns);
      //setFormColumnsList(...formColumnsList, actionColumn);
      //setFormColumnsList([...formColumnsList, actionColumn])
      //setFormColumnsList(prevFormColumnsList => [...prevFormColumnsList,actionColumn])
      setFormColumnsList(formColumnsList => [...formColumnsList, ...actionColumn])
      setFormDataList(response.data.formFieldData);
      setFormFieldLabel(response.data.formFieldLabel);
      
      setIsLoading(false)
  },(error) => {
    console.log(error)
    setIsError(true)
    setIsLoading(false)
  });
  //setFormUsersList(getFormUserData)
   //setFormColumnsList({...formColumnsList, actionColumn});
   //setFormColumnsList(prevFormColumnsList => ({...prevFormColumnsList, actionColumn}))
  setIsLoading(false)
}, []);

const productEformDetailsExportCSV = () => {
  ReportSuiteService.productEformDetailsExportCSV(params.productEformId,"my","lucy").then(
    (response) => {            
        console.log(response.data)
    },(error) => {
      console.log(error)
    });
}

  // const [form] = Form.useForm();
  // const onFinish = (values) => {
  //   console.log('Finish:', values);
  // };
  const onSubmit = (data) => {
    console.log("EditLucyFormTable ",data);
    
}
    return (
         <Fragment>
            <>
        {
          isLoading ? <div>Loading... </div> : 
          isError ? <div>Error Occured... </div> :
         <div><Breadcrumb>
             <Breadcrumb.Item>Home</Breadcrumb.Item>
             <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
             <Breadcrumb.Item><a href="/lucy-forms-list-table">Malaysia</a></Breadcrumb.Item>
         </Breadcrumb>
         <p><br/></p>
         <h1>Lucy</h1>
         <ContainerHeader />
         <Card>
            <Meta title="Search" description="Filter date and name"
            />
            <form onSubmit={handleSubmit(onSubmit)} >
                <div className='input-flex-group'>
        <Controller
            render={(props) => (
              <RangePicker
                {...props}
                format="DD-MM-YYYY"
                //value={[props.value && moment(props.value[0]), props.value && moment(props.value[1])]}
                onChange={(e) => {
                  props.onChange(e);
                  console.log("onChange"+e);
                }}
              />
            )}
            control={control}
            name="startEndDate" defaultValue=''
            rules={{ required: true }}
            defaultValue=""
          />{errors.startEndDate && (<span className='error'>Start and End Date is required</span>)}

                </div>
                <div className='input-flex-group'>
              <Controller as={SelectFormField(formFieldLabel[0].formFieldLabelName,formFieldLabel)} name='formFieldName' control={control} rules={{required:false}}/>
                    {errors.formFieldName && (<span className='error'>Form Field Label is required</span>)}
              </div>
                <div className='input-flex-group'>
                <Controller as={inputKeywordField("keyword")} name='keyword' control={control} defaultValue='' rules={{ required: false }} />
                    {errors.keyword && (<span className='error'>Menu Link is required</span>)}
                </div>
                <div className='input-flex-group'>
                <Button   htmlType='submit'>Search</Button>
                <Button   htmlType='button' onClick={() => {
                    reset({
                      startEndDate:'',
                      formFieldIdId:'0',
                      keyword:''
                      
                  });
              }}>Reset</Button>   
                <Button   htmlType='button' onClick={productEformDetailsExportCSV}><FileExcelOutlined />Export to CSV</Button>
                </div>
            </form>
          </Card>

       <Table
         columns={formColumnsList}
         dataSource={formDataList}
         //columns={columns}
         //dataSource={formUsersList}
         loading={isLoading}
         //onChange={handleTableChange}
         pagination={pagination}
         rowKey="userId"
       /></div>
 
       
        }    
     </>
      </Fragment>
    );
};

export default LucyFormFieldsDetailsList;
