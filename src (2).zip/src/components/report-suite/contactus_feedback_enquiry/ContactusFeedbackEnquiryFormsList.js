import React, { useState, useEffect  } from 'react';
import { Table, Switch, Space, Breadcrumb, Button, Popconfirm, Divider, Card } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
//import ContainerHeader from 'ContainerHeader/index';
import ContainerHeader from '../../ContainerHeader/index';
import { Link } from 'react-router-dom';

import { useForm, Controller } from "react-hook-form";
import { inputLoginField, SelectProductUserGroupField } from "../../../containers/Inputs";
import ReportSuiteService  from "../../../services/report-suite/report-suite";
const ContactusFeedbackEnquiryFormsList = () => {
  const { Meta } = Card;
  const defaultValues = {
    formName:'',
    productGroupId:'0'
}
const { handleSubmit, control, errors, reset, setValue } = useForm({defaultValues});
    const [isLoading, setIsLoading] = useState(false);
    const [isError, setIsError] = useState(false);
    const [formsList, setFormsList] = useState([]);
    const [userGroupList, setUserGroupList] = useState([{productGroupId:'0', productGroupName:""}]);
    const [pagination, setPagination] = useState({});
    
    useEffect(() => {
        setIsLoading(true)
    ReportSuiteService.productEformNames(1,"my","contactus_feedback_enquiry").then(
        (response) => {            
            console.log(response.data)
            setUserGroupList(response.data.productGroup);
            setFormsList(response.data.productEform);
            setIsLoading(false)
        },(error) => {
          console.log(error)
          setIsError(true)
          setIsLoading(false)
        });
        setIsLoading(false)
      }, []);
  
    const columns = [
        {
          title: "Form Name",
          dataIndex: "productEformName",
          sorter: (a, b) => a.productEformName.length - b.productEformName.length,
          //sorter: (a, b) => (a.formName > b.formName ? 1 : -1),
          // render: (text: string) => <a href="/lucy-form-edit">{text}</a>
          sortDirections: ['descend', 'ascend'],
        },
        {
          title: "User Group",
          dataIndex: "productGroupName",
          sorter: (a, b) => a.productGroupName.length - b.productGroupName.length,
          //sorter: (a, b) => (a.formName > b.formName ? 1 : -1),
          // render: (text: string) => <a href="/lucy-form-edit">{text}</a>
          sortDirections: ['descend', 'ascend'],
        },
   
        {
          title: "Action",
          width: "20%",
          render: (text, record) => (
                <div>
                <Link to={`/contactus-feedback-enquiry-form-fields-details-list/${record.productEformId}`}>           
                 <EditOutlined />
                   </Link>
                  
                </div>
              ),
        }
      ];
      const onSubmit = (data) => {
        console.log("search LucyFormsList ",data);
        setIsLoading(true)
        ReportSuiteService.searchProductEformNames(1,"my","contactus_feedback_enquiry", data).then(
          (response) => {            
              console.log(response.data)
              setUserGroupList(response.data.productGroup);
              setFormsList(response.data.productEform);
              setIsLoading(false)
          },(error) => {
              console.log(error)
              setIsError(true)
              setIsLoading(false)
          });
              setTimeout(() => reset({
                formName:data.formName,
                productGroupId: data.productGroupId
          }), 500);    
      }
    return (
        <>
        {
          isLoading ? <div>Loading... </div> : 
          isError ? <div>Error Occured... </div> :
         <div><Breadcrumb>
             <Breadcrumb.Item>Home</Breadcrumb.Item>
             <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
             <Breadcrumb.Item><a href="/lucy-form-names">Malaysia</a></Breadcrumb.Item>
         </Breadcrumb>
         <p><br/></p>
         <h1>Lucy</h1>
         <ContainerHeader />
         <Card>
            <Meta title="Search" 
            />
            <form onSubmit={handleSubmit(onSubmit)} >
              <div className='input-flex-group'>
                <Controller as={inputLoginField("Form Name")} name='formName' control={control} defaultValue='' rules={{ required: false }} />
                    {errors.formName && (<span className='error'>Form Name is required</span>)}
              </div>
              <div className='input-flex-group'>
              <Controller as={SelectProductUserGroupField(userGroupList[0].productGroupName,userGroupList)} name='productGroupId' control={control} rules={{required:false}}/>
                    {errors.productGroupId && (<span className='error'>User Group is required</span>)}
              </div>
                <div className='input-flex-group'>
                <Button   htmlType='submit'>Search</Button>
                <Button   htmlType='button' onClick={() => {
                    reset({
                      formName:'',
                      productGroupId:'0'
                  });
              }}>Reset</Button>   
                </div>
            </form>
          </Card>
         
       <Table
         columns={columns}
         dataSource={formsList}
         loading={isLoading}
         //onChange={handleTableChange}
         pagination={pagination}
         rowKey="productEformId"
       /></div>
 
       
        }    
     </>
    );
}

export default ContactusFeedbackEnquiryFormsList;
