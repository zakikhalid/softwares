import React, { Fragment, useState, useEffect } from 'react';
import { Breadcrumb, Descriptions, Button } from 'antd';
import { useParams } from "react-router-dom";
import ReportSuiteService  from "../../../services/report-suite/report-suite";
const ContactusFeedbackEnquiryFormFieldsDetails = () => {

const params = useParams();
const [isLoading, setIsLoading] = useState(false);
const [isError, setIsError] = useState(false);
const [user, setUser] = useState({ userId: '', userName: '', gender: '', country: '', email: '', address: ' ', productInterest: '', age: '', isExistingCustomer: '', mobileNumber: '' });
const [productEformFieldDetails, setProductEformFieldDetails] = useState({productEformDetailsId:'',productEformId:'',productEformName:'',productEformFormType:'',country:'',status:'',customField1Label:'',customField2Label:'',customField3Label:'',customField4Label:'',customField5Label:'',customField6Label:'',customField7Label:'',customField8Label:'',customField9Label:'',customField10Label:'',    
                                                                        customField1:'',customField2:'',customField3:'',customField4:'',customField5:'',customField6:'',customField7:'',customField8:'',customField9:'',customField10:'',customField11Label:'',customField12Label:'',customField13Label:'',customField14Label:'',customField15Label:'',customField16Label:'',customField17Label:'',customField18Label:'',customField19Label:'',customField20Label:'',    
                                                                        customField11:'',customField12:'',customField13:'',customField14:'',customField15:'',customField16:'',customField17:'',customField18:'',customField19:'',customField20:'', 
                                                                        customField21Label:'',customField22Label:'',customField23Label:'',customField24Label:'',customField25Label:'',customField26Label:'',customField27Label:'',customField28Label:'',customField29Label:'', customField30Label:'',
                                                                        customField21:'',customField22:'',customField23:'',customField24:'',customField25:'',customField26:'',customField27:'',customField28:'',customField29:'',customField30:'',   
                                                                        customField31Label:'',customField32Label:'',customField33Label:'',customField34Label:'',customField35Label:'',customField36Label:'',customField37Label:'',customField38Label:'',customField39Label:'',customField40Label:'',
                                                                        customField31:'',customField32:'',customField33:'',customField34:'',customField35:'',customField36:'',customField37:'',customField38:'',customField39:'',customField40:'',  
                                                                        customField41Label:'',customField42Label:'',customField43Label:'',customField44Label:'',customField45Label:'',customField46Label:'',customField47Label:'',customField48Label:'',customField49Label:'',customField50Label:'',
                                                                        customField41:'',customField42:'',customField43:'',customField44:'',customField45:'',customField46:'',customField47:'',customField48:'',customField49:'',customField50:'',
                                                                        customField51Label:'',customField52Label:'',customField53Label:'',customField54Label:'',customField55Label:'',customField56Label:'',customField57Label:'',customField58Label:'',customField59Label:'',customField60Label:'',
                                                                        customField51:'',customField52:'',customField53:'',customField54:'',customField55:'',customField56:'',customField57:'',customField58:'',customField59:'',customField60:'',
                                                                        customField61Label:'',customField62Label:'',customField63Label:'',customField64Label:'',customField65Label:'',customField66Label:'',customField67Label:'',customField68Label:'',customField69Label:'',customField70Label:'',
                                                                        customField61:'',customField62:'',customField63:'',customField64:'',customField65:'',customField66:'',customField67:'',customField68:'',customField69:'',customField70:'',
                                                                        customField71Label:'',customField72Label:'',customField73Label:'',customField74Label:'',customField75Label:'',customField76Label:'',customField77Label:'',customField78Label:'',customField79Label:'',customField80Label:'',
                                                                        customField71:'',customField72:'',customField73:'',customField74:'',customField75:'',customField76:'',customField77:'',customField78:'',customField79:'',customField80:'',
                                                                        customField81Label:'',customField82Label:'',customField83Label:'',customField84Label:'',customField85Label:'',customField86Label:'',customField87Label:'',customField88Label:'',customField89Label:'',customField90Label:'',
                                                                        customField81:'',customField82:'',customField83:'',customField84:'',customField85:'',customField86:'',customField87:'',customField88:'',customField89:'',customField90:'',
                                                                        customField91Label:'',customField92Label:'',customField93Label:'',customField94Label:'',customField95Label:'',customField96Label:'',customField97Label:'',customField98Label:'',customField99Label:'',customField100Label:'',
                                                                        customField91:'',customField92:'',customField93:'',customField94:'',customField95:'',customField96:'',customField97:'',customField98:'',customField99:'',customField100:''});
useEffect(() => {
    console.log(" productEformFieldDetailsId is "+params.productEformFieldDetailsId)
    setIsLoading(true)
    ReportSuiteService.productEformFieldDetails(params.productEformFieldDetailsId,"my","contactus_feedback_enquiry").then(
        (response) => {            
            console.log(response.data)
            setProductEformFieldDetails(response.data)
            setIsLoading(false)
        },(error) => {
            console.log(error)
            setIsError(false)
            setIsLoading(false)
        });
    
}, []);

    return (
        <Fragment>
            <>
        {
         isLoading ? <div>Loading... </div> : 
         isError ? <div>Error Occured... </div> :
        <div>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Report Suite</Breadcrumb.Item>
                <Breadcrumb.Item>Malaysia</Breadcrumb.Item>
                <Breadcrumb.Item>LUCY</Breadcrumb.Item>
            </Breadcrumb>
            <p><br/></p>
            {/* <h1>{user.userName}</h1>{productEformFieldDetails.customField1Label} */}
            <Descriptions bordered size="small">
            {productEformFieldDetails.customField1Label ? <Descriptions.Item label={`${productEformFieldDetails.customField1Label}`} span={4}>{productEformFieldDetails.customField1}</Descriptions.Item>: ''}
{productEformFieldDetails.customField2Label ? <Descriptions.Item label={`${productEformFieldDetails.customField2Label}`} span={4}>{productEformFieldDetails.customField2}</Descriptions.Item>: ''}
{productEformFieldDetails.customField3Label ? <Descriptions.Item label={`${productEformFieldDetails.customField3Label}`} span={4}>{productEformFieldDetails.customField3}</Descriptions.Item>: ''}
{productEformFieldDetails.customField4Label ? <Descriptions.Item label={`${productEformFieldDetails.customField4Label}`} span={4}>{productEformFieldDetails.customField4}</Descriptions.Item>: ''}
{productEformFieldDetails.customField5Label ? <Descriptions.Item label={`${productEformFieldDetails.customField5Label}`} span={4}>{productEformFieldDetails.customField5}</Descriptions.Item>: ''}
{productEformFieldDetails.customField6Label ? <Descriptions.Item label={`${productEformFieldDetails.customField6Label}`} span={4}>{productEformFieldDetails.customField6}</Descriptions.Item>: ''}
{productEformFieldDetails.customField7Label ? <Descriptions.Item label={`${productEformFieldDetails.customField7Label}`} span={4}>{productEformFieldDetails.customField7}</Descriptions.Item>: ''}
{productEformFieldDetails.customField8Label ? <Descriptions.Item label={`${productEformFieldDetails.customField8Label}`} span={4}>{productEformFieldDetails.customField8}</Descriptions.Item>: ''}
{productEformFieldDetails.customField9Label ? <Descriptions.Item label={`${productEformFieldDetails.customField9Label}`} span={4}>{productEformFieldDetails.customField9}</Descriptions.Item>: ''}
{productEformFieldDetails.customField10Label ? <Descriptions.Item label={`${productEformFieldDetails.customField10Label}`} span={4}>{productEformFieldDetails.customField10}</Descriptions.Item>: ''}
{productEformFieldDetails.customField11Label ? <Descriptions.Item label={`${productEformFieldDetails.customField11Label}`} span={4}>{productEformFieldDetails.customField11}</Descriptions.Item>: ''}
{productEformFieldDetails.customField12Label ? <Descriptions.Item label={`${productEformFieldDetails.customField12Label}`} span={4}>{productEformFieldDetails.customField12}</Descriptions.Item>: ''}
{productEformFieldDetails.customField13Label ? <Descriptions.Item label={`${productEformFieldDetails.customField13Label}`} span={4}>{productEformFieldDetails.customField13}</Descriptions.Item>: ''}
{productEformFieldDetails.customField14Label ? <Descriptions.Item label={`${productEformFieldDetails.customField14Label}`} span={4}>{productEformFieldDetails.customField14}</Descriptions.Item>: ''}
{productEformFieldDetails.customField15Label ? <Descriptions.Item label={`${productEformFieldDetails.customField15Label}`} span={4}>{productEformFieldDetails.customField15}</Descriptions.Item>: ''}
{productEformFieldDetails.customField16Label ? <Descriptions.Item label={`${productEformFieldDetails.customField16Label}`} span={4}>{productEformFieldDetails.customField16}</Descriptions.Item>: ''}
{productEformFieldDetails.customField17Label ? <Descriptions.Item label={`${productEformFieldDetails.customField17Label}`} span={4}>{productEformFieldDetails.customField17}</Descriptions.Item>: ''}
{productEformFieldDetails.customField18Label ? <Descriptions.Item label={`${productEformFieldDetails.customField18Label}`} span={4}>{productEformFieldDetails.customField18}</Descriptions.Item>: ''}
{productEformFieldDetails.customField19Label ? <Descriptions.Item label={`${productEformFieldDetails.customField19Label}`} span={4}>{productEformFieldDetails.customField19}</Descriptions.Item>: ''}
{productEformFieldDetails.customField20Label ? <Descriptions.Item label={`${productEformFieldDetails.customField20Label}`} span={4}>{productEformFieldDetails.customField20}</Descriptions.Item>: ''}
{productEformFieldDetails.customField21Label ? <Descriptions.Item label={`${productEformFieldDetails.customField21Label}`} span={4}>{productEformFieldDetails.customField21}</Descriptions.Item>: ''}
{productEformFieldDetails.customField22Label ? <Descriptions.Item label={`${productEformFieldDetails.customField22Label}`} span={4}>{productEformFieldDetails.customField22}</Descriptions.Item>: ''}
{productEformFieldDetails.customField23Label ? <Descriptions.Item label={`${productEformFieldDetails.customField23Label}`} span={4}>{productEformFieldDetails.customField23}</Descriptions.Item>: ''}
{productEformFieldDetails.customField24Label ? <Descriptions.Item label={`${productEformFieldDetails.customField24Label}`} span={4}>{productEformFieldDetails.customField24}</Descriptions.Item>: ''}
{productEformFieldDetails.customField25Label ? <Descriptions.Item label={`${productEformFieldDetails.customField25Label}`} span={4}>{productEformFieldDetails.customField25}</Descriptions.Item>: ''}
{productEformFieldDetails.customField26Label ? <Descriptions.Item label={`${productEformFieldDetails.customField26Label}`} span={4}>{productEformFieldDetails.customField26}</Descriptions.Item>: ''}
{productEformFieldDetails.customField27Label ? <Descriptions.Item label={`${productEformFieldDetails.customField27Label}`} span={4}>{productEformFieldDetails.customField27}</Descriptions.Item>: ''}
{productEformFieldDetails.customField28Label ? <Descriptions.Item label={`${productEformFieldDetails.customField28Label}`} span={4}>{productEformFieldDetails.customField28}</Descriptions.Item>: ''}
{productEformFieldDetails.customField29Label ? <Descriptions.Item label={`${productEformFieldDetails.customField29Label}`} span={4}>{productEformFieldDetails.customField29}</Descriptions.Item>: ''}
{productEformFieldDetails.customField30Label ? <Descriptions.Item label={`${productEformFieldDetails.customField30Label}`} span={4}>{productEformFieldDetails.customField30}</Descriptions.Item>: ''}
{productEformFieldDetails.customField31Label ? <Descriptions.Item label={`${productEformFieldDetails.customField31Label}`} span={4}>{productEformFieldDetails.customField31}</Descriptions.Item>: ''}
{productEformFieldDetails.customField32Label ? <Descriptions.Item label={`${productEformFieldDetails.customField32Label}`} span={4}>{productEformFieldDetails.customField32}</Descriptions.Item>: ''}
{productEformFieldDetails.customField33Label ? <Descriptions.Item label={`${productEformFieldDetails.customField33Label}`} span={4}>{productEformFieldDetails.customField33}</Descriptions.Item>: ''}
{productEformFieldDetails.customField34Label ? <Descriptions.Item label={`${productEformFieldDetails.customField34Label}`} span={4}>{productEformFieldDetails.customField34}</Descriptions.Item>: ''}
{productEformFieldDetails.customField35Label ? <Descriptions.Item label={`${productEformFieldDetails.customField35Label}`} span={4}>{productEformFieldDetails.customField35}</Descriptions.Item>: ''}
{productEformFieldDetails.customField36Label ? <Descriptions.Item label={`${productEformFieldDetails.customField36Label}`} span={4}>{productEformFieldDetails.customField36}</Descriptions.Item>: ''}
{productEformFieldDetails.customField37Label ? <Descriptions.Item label={`${productEformFieldDetails.customField37Label}`} span={4}>{productEformFieldDetails.customField37}</Descriptions.Item>: ''}
{productEformFieldDetails.customField38Label ? <Descriptions.Item label={`${productEformFieldDetails.customField38Label}`} span={4}>{productEformFieldDetails.customField38}</Descriptions.Item>: ''}
{productEformFieldDetails.customField39Label ? <Descriptions.Item label={`${productEformFieldDetails.customField39Label}`} span={4}>{productEformFieldDetails.customField39}</Descriptions.Item>: ''}
{productEformFieldDetails.customField40Label ? <Descriptions.Item label={`${productEformFieldDetails.customField40Label}`} span={4}>{productEformFieldDetails.customField40}</Descriptions.Item>: ''}
{productEformFieldDetails.customField41Label ? <Descriptions.Item label={`${productEformFieldDetails.customField41Label}`} span={4}>{productEformFieldDetails.customField41}</Descriptions.Item>: ''}
{productEformFieldDetails.customField42Label ? <Descriptions.Item label={`${productEformFieldDetails.customField42Label}`} span={4}>{productEformFieldDetails.customField42}</Descriptions.Item>: ''}
{productEformFieldDetails.customField43Label ? <Descriptions.Item label={`${productEformFieldDetails.customField43Label}`} span={4}>{productEformFieldDetails.customField43}</Descriptions.Item>: ''}
{productEformFieldDetails.customField44Label ? <Descriptions.Item label={`${productEformFieldDetails.customField44Label}`} span={4}>{productEformFieldDetails.customField44}</Descriptions.Item>: ''}
{productEformFieldDetails.customField45Label ? <Descriptions.Item label={`${productEformFieldDetails.customField45Label}`} span={4}>{productEformFieldDetails.customField45}</Descriptions.Item>: ''}
{productEformFieldDetails.customField46Label ? <Descriptions.Item label={`${productEformFieldDetails.customField46Label}`} span={4}>{productEformFieldDetails.customField46}</Descriptions.Item>: ''}
{productEformFieldDetails.customField47Label ? <Descriptions.Item label={`${productEformFieldDetails.customField47Label}`} span={4}>{productEformFieldDetails.customField47}</Descriptions.Item>: ''}
{productEformFieldDetails.customField48Label ? <Descriptions.Item label={`${productEformFieldDetails.customField48Label}`} span={4}>{productEformFieldDetails.customField48}</Descriptions.Item>: ''}
{productEformFieldDetails.customField49Label ? <Descriptions.Item label={`${productEformFieldDetails.customField49Label}`} span={4}>{productEformFieldDetails.customField49}</Descriptions.Item>: ''}
{productEformFieldDetails.customField50Label ? <Descriptions.Item label={`${productEformFieldDetails.customField50Label}`} span={4}>{productEformFieldDetails.customField50}</Descriptions.Item>: ''}
{productEformFieldDetails.customField51Label ? <Descriptions.Item label={`${productEformFieldDetails.customField51Label}`} span={4}>{productEformFieldDetails.customField51}</Descriptions.Item>: ''}
{productEformFieldDetails.customField52Label ? <Descriptions.Item label={`${productEformFieldDetails.customField52Label}`} span={4}>{productEformFieldDetails.customField52}</Descriptions.Item>: ''}
{productEformFieldDetails.customField53Label ? <Descriptions.Item label={`${productEformFieldDetails.customField53Label}`} span={4}>{productEformFieldDetails.customField53}</Descriptions.Item>: ''}
{productEformFieldDetails.customField54Label ? <Descriptions.Item label={`${productEformFieldDetails.customField54Label}`} span={4}>{productEformFieldDetails.customField54}</Descriptions.Item>: ''}
{productEformFieldDetails.customField55Label ? <Descriptions.Item label={`${productEformFieldDetails.customField55Label}`} span={4}>{productEformFieldDetails.customField55}</Descriptions.Item>: ''}
{productEformFieldDetails.customField56Label ? <Descriptions.Item label={`${productEformFieldDetails.customField56Label}`} span={4}>{productEformFieldDetails.customField56}</Descriptions.Item>: ''}
{productEformFieldDetails.customField57Label ? <Descriptions.Item label={`${productEformFieldDetails.customField57Label}`} span={4}>{productEformFieldDetails.customField57}</Descriptions.Item>: ''}
{productEformFieldDetails.customField58Label ? <Descriptions.Item label={`${productEformFieldDetails.customField58Label}`} span={4}>{productEformFieldDetails.customField58}</Descriptions.Item>: ''}
{productEformFieldDetails.customField59Label ? <Descriptions.Item label={`${productEformFieldDetails.customField59Label}`} span={4}>{productEformFieldDetails.customField59}</Descriptions.Item>: ''}
{productEformFieldDetails.customField60Label ? <Descriptions.Item label={`${productEformFieldDetails.customField60Label}`} span={4}>{productEformFieldDetails.customField60}</Descriptions.Item>: ''}
{productEformFieldDetails.customField61Label ? <Descriptions.Item label={`${productEformFieldDetails.customField61Label}`} span={4}>{productEformFieldDetails.customField61}</Descriptions.Item>: ''}
{productEformFieldDetails.customField62Label ? <Descriptions.Item label={`${productEformFieldDetails.customField62Label}`} span={4}>{productEformFieldDetails.customField62}</Descriptions.Item>: ''}
{productEformFieldDetails.customField63Label ? <Descriptions.Item label={`${productEformFieldDetails.customField63Label}`} span={4}>{productEformFieldDetails.customField63}</Descriptions.Item>: ''}
{productEformFieldDetails.customField64Label ? <Descriptions.Item label={`${productEformFieldDetails.customField64Label}`} span={4}>{productEformFieldDetails.customField64}</Descriptions.Item>: ''}
{productEformFieldDetails.customField65Label ? <Descriptions.Item label={`${productEformFieldDetails.customField65Label}`} span={4}>{productEformFieldDetails.customField65}</Descriptions.Item>: ''}
{productEformFieldDetails.customField66Label ? <Descriptions.Item label={`${productEformFieldDetails.customField66Label}`} span={4}>{productEformFieldDetails.customField66}</Descriptions.Item>: ''}
{productEformFieldDetails.customField67Label ? <Descriptions.Item label={`${productEformFieldDetails.customField67Label}`} span={4}>{productEformFieldDetails.customField67}</Descriptions.Item>: ''}
{productEformFieldDetails.customField68Label ? <Descriptions.Item label={`${productEformFieldDetails.customField68Label}`} span={4}>{productEformFieldDetails.customField68}</Descriptions.Item>: ''}
{productEformFieldDetails.customField69Label ? <Descriptions.Item label={`${productEformFieldDetails.customField69Label}`} span={4}>{productEformFieldDetails.customField69}</Descriptions.Item>: ''}
{productEformFieldDetails.customField70Label ? <Descriptions.Item label={`${productEformFieldDetails.customField70Label}`} span={4}>{productEformFieldDetails.customField70}</Descriptions.Item>: ''}
{productEformFieldDetails.customField71Label ? <Descriptions.Item label={`${productEformFieldDetails.customField71Label}`} span={4}>{productEformFieldDetails.customField71}</Descriptions.Item>: ''}
{productEformFieldDetails.customField72Label ? <Descriptions.Item label={`${productEformFieldDetails.customField72Label}`} span={4}>{productEformFieldDetails.customField72}</Descriptions.Item>: ''}
{productEformFieldDetails.customField73Label ? <Descriptions.Item label={`${productEformFieldDetails.customField73Label}`} span={4}>{productEformFieldDetails.customField73}</Descriptions.Item>: ''}
{productEformFieldDetails.customField74Label ? <Descriptions.Item label={`${productEformFieldDetails.customField74Label}`} span={4}>{productEformFieldDetails.customField74}</Descriptions.Item>: ''}
{productEformFieldDetails.customField75Label ? <Descriptions.Item label={`${productEformFieldDetails.customField75Label}`} span={4}>{productEformFieldDetails.customField75}</Descriptions.Item>: ''}
{productEformFieldDetails.customField76Label ? <Descriptions.Item label={`${productEformFieldDetails.customField76Label}`} span={4}>{productEformFieldDetails.customField76}</Descriptions.Item>: ''}
{productEformFieldDetails.customField77Label ? <Descriptions.Item label={`${productEformFieldDetails.customField77Label}`} span={4}>{productEformFieldDetails.customField77}</Descriptions.Item>: ''}
{productEformFieldDetails.customField78Label ? <Descriptions.Item label={`${productEformFieldDetails.customField78Label}`} span={4}>{productEformFieldDetails.customField78}</Descriptions.Item>: ''}
{productEformFieldDetails.customField79Label ? <Descriptions.Item label={`${productEformFieldDetails.customField79Label}`} span={4}>{productEformFieldDetails.customField79}</Descriptions.Item>: ''}
{productEformFieldDetails.customField80Label ? <Descriptions.Item label={`${productEformFieldDetails.customField80Label}`} span={4}>{productEformFieldDetails.customField80}</Descriptions.Item>: ''}
{productEformFieldDetails.customField81Label ? <Descriptions.Item label={`${productEformFieldDetails.customField81Label}`} span={4}>{productEformFieldDetails.customField81}</Descriptions.Item>: ''}
{productEformFieldDetails.customField82Label ? <Descriptions.Item label={`${productEformFieldDetails.customField82Label}`} span={4}>{productEformFieldDetails.customField82}</Descriptions.Item>: ''}
{productEformFieldDetails.customField83Label ? <Descriptions.Item label={`${productEformFieldDetails.customField83Label}`} span={4}>{productEformFieldDetails.customField83}</Descriptions.Item>: ''}
{productEformFieldDetails.customField84Label ? <Descriptions.Item label={`${productEformFieldDetails.customField84Label}`} span={4}>{productEformFieldDetails.customField84}</Descriptions.Item>: ''}
{productEformFieldDetails.customField85Label ? <Descriptions.Item label={`${productEformFieldDetails.customField85Label}`} span={4}>{productEformFieldDetails.customField85}</Descriptions.Item>: ''}
{productEformFieldDetails.customField86Label ? <Descriptions.Item label={`${productEformFieldDetails.customField86Label}`} span={4}>{productEformFieldDetails.customField86}</Descriptions.Item>: ''}
{productEformFieldDetails.customField87Label ? <Descriptions.Item label={`${productEformFieldDetails.customField87Label}`} span={4}>{productEformFieldDetails.customField87}</Descriptions.Item>: ''}
{productEformFieldDetails.customField88Label ? <Descriptions.Item label={`${productEformFieldDetails.customField88Label}`} span={4}>{productEformFieldDetails.customField88}</Descriptions.Item>: ''}
{productEformFieldDetails.customField89Label ? <Descriptions.Item label={`${productEformFieldDetails.customField89Label}`} span={4}>{productEformFieldDetails.customField89}</Descriptions.Item>: ''}
{productEformFieldDetails.customField90Label ? <Descriptions.Item label={`${productEformFieldDetails.customField90Label}`} span={4}>{productEformFieldDetails.customField90}</Descriptions.Item>: ''}
{productEformFieldDetails.customField91Label ? <Descriptions.Item label={`${productEformFieldDetails.customField91Label}`} span={4}>{productEformFieldDetails.customField91}</Descriptions.Item>: ''}
{productEformFieldDetails.customField92Label ? <Descriptions.Item label={`${productEformFieldDetails.customField92Label}`} span={4}>{productEformFieldDetails.customField92}</Descriptions.Item>: ''}
{productEformFieldDetails.customField93Label ? <Descriptions.Item label={`${productEformFieldDetails.customField93Label}`} span={4}>{productEformFieldDetails.customField93}</Descriptions.Item>: ''}
{productEformFieldDetails.customField94Label ? <Descriptions.Item label={`${productEformFieldDetails.customField94Label}`} span={4}>{productEformFieldDetails.customField94}</Descriptions.Item>: ''}
{productEformFieldDetails.customField95Label ? <Descriptions.Item label={`${productEformFieldDetails.customField95Label}`} span={4}>{productEformFieldDetails.customField95}</Descriptions.Item>: ''}
{productEformFieldDetails.customField96Label ? <Descriptions.Item label={`${productEformFieldDetails.customField96Label}`} span={4}>{productEformFieldDetails.customField96}</Descriptions.Item>: ''}
{productEformFieldDetails.customField97Label ? <Descriptions.Item label={`${productEformFieldDetails.customField97Label}`} span={4}>{productEformFieldDetails.customField97}</Descriptions.Item>: ''}
{productEformFieldDetails.customField98Label ? <Descriptions.Item label={`${productEformFieldDetails.customField98Label}`} span={4}>{productEformFieldDetails.customField98}</Descriptions.Item>: ''}
{productEformFieldDetails.customField99Label ? <Descriptions.Item label={`${productEformFieldDetails.customField99Label}`} span={4}>{productEformFieldDetails.customField99}</Descriptions.Item>: ''}
{productEformFieldDetails.customField100Label ? <Descriptions.Item label={`${productEformFieldDetails.customField100Label}`} span={4}>{productEformFieldDetails.customField100}</Descriptions.Item>: ''}
<Descriptions.Item label="Date Created" >{productEformFieldDetails.createdDateTime}</Descriptions.Item>
<Descriptions.Item label="Date Modified" span={2}>{productEformFieldDetails.modifiedDateTime}</Descriptions.Item>
            {/* {productEformFieldDetails.customField1Label ? <Descriptions.Item label={`${productEformFieldDetails.customField1Label}`} span={4}>{productEformFieldDetails.customField1}</Descriptions.Item>: ''}
            {(productEformFieldDetails.customField1Label === null || productEformFieldDetails.customField1Label === '') ? '':<Descriptions.Item label={`${productEformFieldDetails.customField1Label}`} span={4}>{productEformFieldDetails.customField1}</Descriptions.Item>} */}
                {/* <Descriptions.Item label="Field 1 Label " span={4}>Sharulnizam Mohamed Yusof</Descriptions.Item>
                <Descriptions.Item label="Field 2 Label" span={5}>Male</Descriptions.Item>
                <Descriptions.Item label="Field 3 Label" span={4}>36</Descriptions.Item>
                <Descriptions.Item label="Field 4 Label" span={4}>Malaysia</Descriptions.Item>
                <Descriptions.Item label="Field 5 Label" span={4}>Yes</Descriptions.Item>
                <Descriptions.Item label="Field 6 Label" span={4}>sharulnizam.yusof@cimb.com</Descriptions.Item>
                <Descriptions.Item label="Field 7 Label" span={4}>+6012 345 6789</Descriptions.Item>                
                <Descriptions.Item label="Field 8 Label" span={4}>
                    83, Jalan Seri Setia 1
                    <br />
                    Bukit Damansara
                    <br />
                    54790 Kuala Lumpur
                    <br />
                    Malaysia
                    <br />
                </Descriptions.Item>
                <Descriptions.Item label="Field 9 Label" span={6}>Senior Basic Current Account</Descriptions.Item>
                <Descriptions.Item label="Email Status" span={6}>Sent</Descriptions.Item>
                <Descriptions.Item label="Date Created" >2021-01-01 00:30</Descriptions.Item>
                <Descriptions.Item label="Date Modified" span={2}>2021-01-01 00:30</Descriptions.Item> */}
            </Descriptions>
            <br/>
            <Button type="danger" href="/contactus-feedback-enquiry-forms-list">&laquo; Back</Button>
        </div>
       } 
      </>
        </Fragment>
    );
}

export default ContactusFeedbackEnquiryFormFieldsDetails;
