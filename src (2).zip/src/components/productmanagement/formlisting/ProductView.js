import React, { useState, useEffect } from 'react';
import { Breadcrumb, Descriptions, Button, Tabs, Card, Space, Table, Form, Radio, Input, Select, message,DatePicker, TimePicker } from 'antd';
import { useLocation, Link, useHistory } from "react-router-dom";
import ProduceEformService from "../../../services/eform-listing/eform-service";
import TimeUtil from "../../../util/Time";

const ProductEformView = () => {

  const formItemLayout = {
    labelCol: {
      xs: { span: 24 },
      sm: { span: 5 },
    },
    wrapperCol: {
      xs: { span: 24 },
      sm: { span: 10 },
    },
  };

  const tailFormItemLayout = {
    wrapperCol: {
      xs: {
        span: 24,
        offset: 0,
      },
      sm: {
        span: 3,
        offset: 10,
      },
    },
  };

  function onChange(value, dateString) {
    console.log('Selected Time: ', value);
    console.log('Formatted Selected Time: ', dateString);
  }

  function onOk(value) {
    console.log('onOk: ', value);
  }

  const { RangePicker } = DatePicker;
  const { TabPane } = Tabs;
  const { Search } = Input;
  const { TextArea } = Input;

  const { state } = useLocation();
  const [productEform, setProductEform] = useState([]);
  const [labelsData, setLabelsData] = useState([]);
  const [pageNumberLabel, setPageNumberLabel] = useState(0);
  const [paginationLabel, setPaginationLabel] = useState({});

  const [formProduct] = Form.useForm();

  let page = 0;
  let size = 20;

  useEffect(() => {
    let id = state.id;
    loadProductEformById(id);
    loadLabelsByEformId(page, size, '', id);
  }, []);


  const loadProductEformById = (id) => {
    ProduceEformService.getProductEformById(id).then(
      res => {
        if (res != null) {
          setProductEform(res.data);
          formProduct.setFieldsValue({
            productEformId: res.data.productEformId,
            status: res.data.status
          });
        }
      }
    )
  }

  const loadLabelsByEformId = (page, size, sort, eformId) => {
    ProduceEformService.loadLabelsByEformId(page, size, sort, eformId).then(
      res => {
        if (res != null) {
          setPaginationLabel({
            onChange: (page, size) => {
              loadLabelsByEformId(page - 1, size, sort, eformId);
              setPageNumberLabel(page);
            },
            showTotal: (total, range) => `Total: ${total}`,
            total: res.data.totalElements,
            pageSize: size
          });
          setLabelsData(
            res.data.content.map(row => ({
              key: row.id,
              id: row.id,
              backendName: row.backendName,
              labelName: row.labelName,
              display: row.display,
              seq: row.seq,
              createdBy: row.createdBy,
            }))
          )
        }
      }
    )
  }

  const labelCols = [
    { title: 'Backend Name', dataIndex: 'backendName', },
    { title: 'Label Name', dataIndex: 'labelName', },
    { title: 'Visible', dataIndex: 'display', },
    { title: 'Sequence', dataIndex: 'seq', },
    {
      title: 'Action',
      dataIndex: 'name',
      render: (text, record) => (
        <Space size="middle">
          <a href="/productEformUpdateFields">Update</a>
        </Space>
      ),
    },
  ];

  const columns2 = [
    { title: 'User ID', dataIndex: 'name1', },
    { title: 'Name', dataIndex: 'name2', },
    { title: 'Group', dataIndex: 'name3', },
    { title: 'Date', dataIndex: 'name4', },
    { title: 'Update By', dataIndex: 'name5', },
    { title: 'Action', dataIndex: 'name6', },
  ];

  const data2 = [
    {
      key: '1',
      name1: 'mycp123',
      name2: 'Danny',
      name3: 'malaysia-personal-account-savingaccount',
      name4: '01-01-2021',
      name5: 'admin',
      name6: '',
    },
    {
      key: '2',
      name1: 'mycp456',
      name2: 'Mok',
      name3: 'malaysia-personal-account-savingaccount',
      name4: '01-01-2021',
      name5: 'admin',
      name6: '',
    },
    {
      key: '3',
      name1: 'mycp789',
      name2: 'Amri',
      name3: '',
      name4: '01-01-2021',
      name5: 'admin',
      name6: <a>Remove</a>,
    },
  ];

  const history = useHistory();

  const onFinishStatus = (values) => {
    handleSubmit(values.productEformId, values.status);
  };

  const handleSubmit = (id, status) => {
    ProduceEformService.updateStatus(id,status).then(
        (response) => {
            if (response) {
                message.success("Update Eform successfully !", 5);
                history.push('/form-listing');
            }
        }
    ).catch(e => {
        if (e.response.data.message === "duplicated-data") {
            message.error("Error:" + e.response.data.httpStatus + "! Code is existed : " + e.response.data.message, 5);
        } else {
            message.error("Error:" + e.response.data.message + "! ", 5);
        }
    });
}

  const onFinishFailed = (errorInfo) => {
    console.log('Failed:', errorInfo);
  };

  function callback(key) {
    // Catch Key
    //console.log(key);
  }

  return (
    <div>
      <Breadcrumb>
        <Breadcrumb.Item>Home</Breadcrumb.Item>
        <Breadcrumb.Item>Product Management</Breadcrumb.Item>
        <Breadcrumb.Item>View</Breadcrumb.Item>
      </Breadcrumb>

      <p><br /></p>
      <h1>Form Listing : {productEform.name}</h1>
      <p><br /></p>
      <Tabs onChange={callback} type="card">
        <TabPane tab="Form Info" key="1">
          <Card>
            <Descriptions bordered>
              <Descriptions.Item label="Form Name" span={4}>{productEform.name}</Descriptions.Item>
              <Descriptions.Item label="Form Type">{productEform.formType}</Descriptions.Item>
              <Descriptions.Item label="Line Of Business" span={2}>{productEform.lineOfBusiness}</Descriptions.Item>
              <Descriptions.Item label="Product Group">{productEform.productGroup}</Descriptions.Item>
              <Descriptions.Item label="Product Sub Group" span={2}>{productEform.productSubGroup}</Descriptions.Item>
              <Descriptions.Item label="Country">{productEform.country}</Descriptions.Item>
              <Descriptions.Item label="Status" span={2}>{productEform.status}</Descriptions.Item>
              <Descriptions.Item label="Date Created">{productEform.createdDateTime ? TimeUtil.formatDate(productEform.createdDateTime) : 'n/a'} </Descriptions.Item>
              <Descriptions.Item label="Created By" span={2}>{productEform.createdBy ? productEform.createdBy : 'n/a'}</Descriptions.Item>
              <Descriptions.Item label="Date Modified">{productEform.modifiedDateTime ? TimeUtil.formatDate(productEform.modifiedDateTime) : 'n/a'} </Descriptions.Item>
              <Descriptions.Item label="Modified By" span={2}>{productEform.modifiedBy ? productEform.modifiedBy : 'n/a'}</Descriptions.Item>
            </Descriptions><br />
            <Link to={{ pathname: '/form-listing/' }}>
              <Button type="danger">Back</Button><br />
            </Link>
          </Card>
        </TabPane>
        <TabPane tab="Fields" key="2">
          <Card>
            <Table columns={labelCols} dataSource={labelsData} />
            <br />
            <Link to={{ pathname: '/form-listing/' }}>
              <Button type="danger">Back</Button><br />
            </Link>
          </Card>
        </TabPane>
        <TabPane tab="User Access" key="3">
          <Card>
            <div align="right">
              <Button type="danger" href="/productEformAddUser">Add User</Button>
            </div>
            <Table columns={columns2} dataSource={data2} /><br />
            <Link to={{ pathname: '/form-listing/' }}>
              <Button type="danger">Back</Button><br />
            </Link>
          </Card>
        </TabPane>
        <TabPane tab="Email Notification" key="4">
          <Card>
            <Form
              {...formItemLayout}
              layout="horizontal"
              size='medium'
            >
              <Form.Item label="Email Notification">
                <Radio.Group>
                  <Radio value={1}>Disable</Radio>
                  <Radio value={2}>Daily Notification</Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item label="Time" name="productcode">
                <TimePicker onChange={onChange} />
              </Form.Item>
              <Form.Item label="Email Subject" name="productcgode1">
                <Input />
              </Form.Item>
              <Form.Item label="Email Recepient" name="productcodef1">
                <Input />
              </Form.Item>
              <Form.Item {...tailFormItemLayout}>
                <Button type="danger">&laquo; Back</Button>
                <Button type="danger" htmlType="submit">Update</Button>
              </Form.Item>
            </Form>
          </Card>
        </TabPane>
        <TabPane tab="Status" key="5">
          <Card>
            <Form
              {...formItemLayout} layout="horizontal" form={formProduct} onFinish={onFinishStatus} onFinishFailed={onFinishFailed} name="statusForm" size='medium'>
              <Form.Item
                name="productEformId">
                <Input type="hidden" />
              </Form.Item>
              <Form.Item name="status" label="Form Status">
                <Radio.Group>
                  <Radio value={'Active'}>Active</Radio>
                  <Radio value={'Inactive'}>Inactive</Radio>
                </Radio.Group>
              </Form.Item>
              <Form.Item {...tailFormItemLayout}>
                <Link to={{ pathname: '/form-listing/' }}>
                  <Button type="danger">Back</Button><br />
                </Link>
                <Button type="danger" htmlType="submit">Update</Button>
              </Form.Item>
            </Form>
          </Card>
        </TabPane>
      </Tabs>
    </div>
  )

}

export default ProductEformView;