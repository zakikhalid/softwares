import React, { useState, useEffect } from "react";
import { Breadcrumb, Button, Table, Space, Form, Card, DatePicker, Input, Select, message } from 'antd';
import CountryService from "../../../services/applicationadmin/country-service";
import ProductEformService from "../../../services/eform-listing/eform-service";
import { Link, useHistory } from "react-router-dom";

const ProductEform = () => {

    const columns = [
        {
            title: 'Name',
            dataIndex: 'name',
        },
        {
            title: 'Form Type',
            dataIndex: 'formType',
        },
        {
            title: 'Country',
            dataIndex: 'country',
        },
        {
            title: 'Line Of Business',
            dataIndex: 'lineOfBusiness',
        },
        {
            title: 'Product Group',
            dataIndex: 'productGroup',
        },
        {
            title: 'Product Sub-Group',
            dataIndex: 'productSubGroup',
        },
        {
            title: 'Status',
            dataIndex: 'status',
        },
        {
            title: 'Action',
            dataIndex: 'name',
            render: (text, record) => (
                <Space size="middle">
                    <Link to={{ pathname: '/form-view/' + record.id, state: { id: record.id } }}>Update</Link>
                </Space>
            ),
        },
    ];

    let page = 0;
    let size = 20;

    const [countryList, setCountryList] = useState([]);
    const [pagination, setPagination] = useState({});
    const [pageNumber, setPageNumber] = useState(0);
    const [datasource, setDatasource] = useState([]);

    const user = window.JSON.parse(localStorage.getItem("user"));

    useEffect(() => {
        // Prepare for role and country
        // Role Should Country Admin & Manager
        // let role = user.role;
        // let listCountry = user.country;
        getCountries();
        getProductEformsData(page, size, '', '', '', '')
    }, []);

    const getCountries = () => {
        CountryService.getListCountry(null, null, '').then(
            res => {
                if (res != null && res.data.content.length > 0) {
                    setCountryList(res.data.content.map(row => ({
                        key: row.apiId,
                        code: row.code,
                        countryName: row.countryName,
                    })));
                }
            }
        ).catch(e => {
            message.error("Error:" + e.response.data.message + "! ", 5);
        });;
    }

    const getProductEformsData = (page, size, sort, formName, formType, country) => {
        ProductEformService.getListProductEform(page, size, sort, formName, formType, country).then(
            res => {
                if (res != null) {
                    setPagination({
                        onChange: (page, size) => {
                            getProductEformsData(page - 1, size, sort, formName, formType, country);
                            setPageNumber(page);
                        },
                        showTotal: (total, range) => `Total: ${total}`,
                        total: res.data.totalElements,
                        pageSize: size
                    });
                    setDatasource(
                        res.data.content.map(row => ({
                            key: row.productEformId,
                            id: row.productEformId,
                            name: row.name,
                            formType: row.formType,
                            lineOfBusiness: row.lineOfBusiness,
                            country: row.country.toUpperCase(),
                            productGroup: row.productGroup,
                            productSubGroup: row.productSubGroup,
                            status: row.status ? row.status : 'NO FIELDS',
                            createdBy: row.createdBy,
                        }))
                    )
                }
            }
        )
    }

    const onReset = (values) => {
        getProductEformsData(page, size, '', '', '', '')
    }

    const onFinish = (values) => {
        console.log(values);
        if(typeof values.formType === "undefined") {
            values.formType = ""
        }
        if(typeof values.formName === "undefined") {
            values.formName = ""
        }
        if(typeof values.country === "undefined") {
            values.country = ""
        }
        getProductEformsData(page, size, '', values.formType, values.formName, values.country);
    };

    function onChange(pagination, filters, sorter, extra) {
        console.log('params', pagination, filters, sorter, extra);
    }

    

    return (
        <>
            <Breadcrumb>
                <Breadcrumb.Item>Home</Breadcrumb.Item>
                <Breadcrumb.Item>Product Management</Breadcrumb.Item>
            </Breadcrumb>
            <p><br /></p>
            <Card title="Search">
                <Form name="horizontal_login" layout="inline" size="small" onFinish={onFinish} onReset={onReset}>
                    <Form.Item name="formName"><Input placeholder="Form Name" /></Form.Item>
                    <Form.Item name="formType">
                        <Select placeholder="Form Type" style={{ width: 200 }}>
                            <Select.Option value="lucy">LUCY</Select.Option>
                            <Select.Option value="contactus_feedback_enquiry">Contact Us / Feedback</Select.Option>
                            <Select.Option value="campaign_enrollment">Campaigns / Events</Select.Option>
                        </Select>
                    </Form.Item>
                    <Form.Item name="country">
                        <Select placeholder="Country" style={{ width: 150 }}>
                            {
                                countryList.map(
                                    (item) => (
                                        <Select.Option key={item.code} value={item.code}>
                                            {item.countryName}
                                        </Select.Option>
                                    )
                                )
                            }
                        </Select>
                    </Form.Item>
                    <Form.Item>
                        <Button htmlType="submit">Search</Button>
                        <Button htmlType="reset">Reset</Button>
                    </Form.Item>
                </Form>
            </Card>
            <h1>Form Listing</h1>
            <Table columns={columns} dataSource={datasource} onChange={onChange} />


        </>
    );
}

export default ProductEform;