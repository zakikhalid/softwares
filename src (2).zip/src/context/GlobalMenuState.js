import React, { createContext, useReducer } from 'react';
import MenuReducer from './MenuReducer';

const initialMenuState = {
    menus: [
            {menuId:1, parentId:0,menuName:"Report Suite",menuLink:"",menuOrder:1}, 
            {menuId:2, parentId:0,menuName:"Permissions",menuLink:"",menuOrder:2}, 
            {menuId:3, parentId:0,menuName:"Product Management",menuLink:"",menuOrder:3}]
}

export const GlobalMenuContext = createContext(initialMenuState);
export const GlobalMenuProvider = ({ children }) => {
const [state, dispatch] = useReducer(MenuReducer, initialMenuState);

    function removeMenu(id) {
        console.log('Check');
        dispatch({
            type: 'REMOVE_MENU',
            payload: id
        });
    };

    function addMenu(menu) {
        console.log('Check');
        dispatch({
            type: 'ADD_MENU',
            payload: menu
        });
    };

    function editMenu(menu) {
        console.log('Check');
        dispatch({
            type: 'EDIT_MENU',
            payload: menu
        });
    };
    return (<GlobalMenuContext.Provider value={{
        menus: state.menus,
                   addMenu,
                  editMenu,
                 removeMenu
    }}>
        {children}
    </GlobalMenuContext.Provider>);
}