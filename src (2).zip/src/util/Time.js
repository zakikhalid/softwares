const formatDate = (time) => {
    return new Date(time).toLocaleString('en-GB', { hour12: false }).split(" ");
}

export default {
    formatDate
}