module.exports = {
  footerText: 'Copyright CIMB Bank Berhad © 2021',
}
