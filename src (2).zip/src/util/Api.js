const getRealUrl = () => {
  return "http://localhost:8087/";
}

export default {
  getRealUrl
}
