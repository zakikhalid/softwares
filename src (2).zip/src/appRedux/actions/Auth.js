import {
  FETCH_ERROR,
  FETCH_START,
  FETCH_SUCCESS,
  INIT_URL,
  SIGNOUT_USER_SUCCESS,
  USER_DATA,
  USER_MENU,
  USER_TOKEN_SET
} from "../../constants/ActionTypes";
import axios from 'util/Api';
import AuthService from "../../services/auth-service";
import UserService from "../../services/user-service";
//import { useHistory } from "react-router-dom";
//const history = useHistory();

export const setInitUrl = (url) => {
  return {
    type: INIT_URL,
    payload: url
  };
};

export const userSignUp = ({email, password, name}) => {
  console.log(email, password);
  return (dispatch) => {
    // dispatch({type: FETCH_START});
    // axios.post('auth/register', {
    //     email: email,
    //     password: password,
    //     name: name
    //   }
    // ).then(({data}) => {
    //   console.log("data:", data);
    //   if (data.result) {
    //     localStorage.setItem("token", JSON.stringify(data.token.access_token));
    //     axios.defaults.headers.common['authorization'] = "Bearer " + data.token.access_token;
    //     dispatch({type: FETCH_SUCCESS});
    //     dispatch({type: USER_TOKEN_SET, payload: data.token.access_token});
    //     dispatch({type: USER_DATA, payload: data.user});
    //   } else {
    //     console.log("payload: data.error", data.error);
    //     dispatch({type: FETCH_ERROR, payload: "Network Error"});
    //   }
    // }).catch(function (error) {
    //   dispatch({type: FETCH_ERROR, payload: error.message});
    //   console.log("Error****:", error.message);
    // });
  }
};

export const userSignIn_Original = ({email, password}) => {
  return (dispatch) => {
    dispatch({type: FETCH_START});
    axios.post('auth/login', {
        email: email,
        password: password,
      }
    ).then(({data}) => {
      console.log("userSignIn: ", data);
      if (data.result) {
        localStorage.setItem("token", JSON.stringify(data.token.access_token));
        axios.defaults.headers.common['Authorization'] = "Bearer " + data.token.access_token;
        dispatch({type: FETCH_SUCCESS});
        dispatch({type: USER_TOKEN_SET, payload: data.token.access_token});
      } else {
        dispatch({type: FETCH_ERROR, payload: data.error});
      }
    }).catch(function (error) {
      dispatch({type: FETCH_ERROR, payload: error.message});
      console.log("Error****:", error.message);
    });
  }
};
export const userSignIn = ({UserId, Password}) => {
  return (dispatch) => {
    dispatch({type: FETCH_START});
    AuthService.login(UserId, Password)
    .then((loginResponse) => {
      //console.log("userSignIn: ", loginResponse.data);
      if (loginResponse.data) {
        //console.log('loginResponse.data.menu '+loginResponse.data.menu)
        //localStorage.setItem("token", JSON.stringify(data.token.access_token));
        //axios.defaults.headers.common['Authorization'] = "Bearer " + data.token.access_token;
        dispatch({type: FETCH_SUCCESS});
        dispatch({type: USER_TOKEN_SET, payload: loginResponse.data.accessToken});
        dispatch({type: USER_DATA, payload: loginResponse.data.user});
        dispatch({type: USER_MENU, payload: loginResponse.data.menu});
      } else {
        dispatch({type: FETCH_ERROR, payload: loginResponse.data.error});
      }
    }).catch(function (error) {
      console.log(' error '+error)
      dispatch({type: FETCH_ERROR, payload: error.message});
      console.log("Error****:", error.message);
    });
  }
};

export const userMenu = (staffId) => {
  return (dispatch) => {
    dispatch({type: FETCH_START});
    UserService.getUserMenu(staffId)
    .then((menuResponse) => {
      console.log("userMenu: ", menuResponse.data);
      if (menuResponse.data) {
        dispatch({type: FETCH_SUCCESS});
        dispatch({type: USER_MENU, payload: menuResponse.data});
      } else {
        dispatch({type: FETCH_ERROR, payload: menuResponse.data.error});
      }
    }).catch(function (error) {
      dispatch({type: FETCH_ERROR, payload: error.message});
      console.log("Error****:", error.message);
    });
  }
};
export const userSignIn_Working = ({UserId, Password}) => {
  console.log(" UserId "+UserId); 
  return (dispatch) => {
    console.log(" Password "+Password);
    dispatch({type: FETCH_START});
    AuthService.login(UserId, Password).then(
      (loginResponse) => {            
          // UserService.getUserMenu(loginResponse.data.user.staffId).then(
          //   //UserService.getUserMenu(UserId).then(
          //     (menuResponse) => {
          //         //console.log(menuResponse.status);
          //         console.log(menuResponse.data);
          //         //history.push('/');
          //  }, (error) => {
          //       console.log(error); 
          // }  
          // );
          console.log(loginResponse.data);
          dispatch({type: FETCH_SUCCESS});
          dispatch({type: USER_TOKEN_SET, payload: loginResponse.data.access_token});
      },
      (error) => {
        console.log(error);
          //alert(error.response.data);
      }
  );
    // axios.post('auth/login', {
    //     email: email,
    //     password: password,
    //   }
    // ).then(({data}) => {
    //   console.log("userSignIn: ", data);
    //   if (data.result) {
        //localStorage.setItem("token", JSON.stringify(data.token.access_token));
        //localStorage.setItem("token", JSON.stringify(123456));
        //axios.defaults.headers.common['Authorization'] = "Bearer " + data.token.access_token;
        
        //axios.defaults.headers.common['Authorization'] = "Bearer " + JSON.stringify(localStorage.getItem("token"));
        
        //dispatch({type: FETCH_SUCCESS});
        //dispatch({type: USER_TOKEN_SET, payload: data.access_token});
        
        //dispatch({type: USER_TOKEN_SET, payload: JSON.stringify(localStorage.getItem("token"))});
      // } else {
      //   dispatch({type: FETCH_ERROR, payload: data.error});
      // }
    // }).catch(function (error) {
    //   dispatch({type: FETCH_ERROR, payload: error.message});
    //   console.log("Error****:", error.message);
    // });
  }
};

export const getUser = () => {
  return (dispatch) => {
    dispatch({type: FETCH_START});
    // axios.post('auth/me',
    // ).then(({data}) => {
    //   console.log("userSignIn: ", data);
    //   if (data.result) {
    //     dispatch({type: FETCH_SUCCESS});
    //     dispatch({type: USER_DATA, payload: data.user});
    //   } else {
    //     dispatch({type: FETCH_ERROR, payload: data.error});
    //   }
    // }).catch(function (error) {
    //   dispatch({type: FETCH_ERROR, payload: error.message});
    //   console.log("Error****:", error.message);
    // });
  }
};


export const userSignOut = () => {

  return (dispatch) => {
    dispatch({type: FETCH_START});

    // axios.post('auth/logout').then(({data}) => {
    //   console.log("log out",data)
    //   if (data.result) {
        //localStorage.removeItem("token");
        AuthService.logout();
        dispatch({type: FETCH_SUCCESS});
        dispatch({type: SIGNOUT_USER_SUCCESS});
    //   } else {
    //     dispatch({type: FETCH_ERROR, payload: data.error});
    //   }
    // }).catch(function (error) {
    //   dispatch({type: FETCH_ERROR, payload: error.message});
    //   console.log("Error****:", error.message);
    // });
  }
};
