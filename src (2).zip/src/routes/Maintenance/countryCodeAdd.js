import React, { useState } from 'react';
import {
  Form,
  Input,
  Button,
  Radio,
  Select,
  Cascader,
  DatePicker,
  InputNumber,
  TreeSelect,
  Switch,
  Breadcrumb,
  Checkbox,
} from 'antd';


const CountryCodeAdd = () => {

    const formItemLayout = {
        labelCol: {
        xs: { span: 24 },
        sm: { span: 5 },
        },
        wrapperCol: {
        xs: { span: 24 },
        sm: { span: 10 },
        },
    };
    
    const tailFormItemLayout = {
        wrapperCol: {
        xs: {
            span: 24,
            offset: 0,
        },
        sm: {
            span: 3,
            offset: 10,
        },
        },
    };


  return (
    <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
            <Breadcrumb.Item>Country Code</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Country Code - Add New</h1>
        <p><br/></p>

        <Form
            {...formItemLayout}
            layout="horizontal"
            size='large'
        >
            <Form.Item 
                label="Country Name"
                name="countryname"
                rules={[{ required: true, message: 'Please input country name!' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item 
                label="Country Code"
                name="countrycode"
                rules={[{ required: true, message: 'Please input country code!' }]}
            >
                <Input />
            </Form.Item>
                    
            <Form.Item {...tailFormItemLayout}>
                <Button type="danger" htmlType="submit">
                    Add
                </Button>
            </Form.Item>
         </Form>
    </>
  );
};

export default CountryCodeAdd;