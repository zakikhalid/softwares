import React from "react";
import { Breadcrumb, Button, Table } from 'antd';

const columns = [
  {
    title: 'Form Name',
    dataIndex: 'formName',
    // specify the condition of filtering result
    // here is that finding the name started with `value`
    render: (text: string) => <a href="/productEformDetail">{text}</a>,    
    //sorter: (a, b) => a.country.length - b.country.length,
    sortDirections: ['ascen'],
  },
  {
    title: 'Name',
    dataIndex: 'name',
  },
  {
    title: 'Api Type',
    dataIndex: 'apiType',
  },
  {
    title: 'Form Type',
    dataIndex: 'formType',
  },
  {
    title: 'Sub Form Type',
    dataIndex: 'subFormType',
  },
  {
    title: 'Country',
    dataIndex: 'country',
  },
  {
    title: 'Product Type',
    dataIndex: 'productType',
  },
  {
    title: 'Line Of Business',
    dataIndex: 'lineOfBusiness',
  },
  {
    title: 'Status',
    dataIndex: 'status',
  }
];

const productEformDatas = [
  {
    key: '1',
    formName: 'master_lucy_my',
    name: 'Master Lucy Malaysia',
    apiType: 'lucy1view_api', // genralForm_api // applicationAudit_api
    formType: 'lucy1view', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'master_lucy', 
    country: 'my',
    productType: 'marketing',
    lineOfBusiness: 'gws',
    status: 'Active'
  },
  {
    key: '2',
    formName: 'master_lucy_sg',
    name: 'Master Lucy Singapore',
    apiType: 'lucy1view_api', // genralForm_api // applicationAudit_api
    formType: 'lucy1view', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'master_lucy', 
    country: 'sg',
    productType: 'marketing',
    lineOfBusiness: 'gws',
    status: 'Active'
  },
  {
    key: '3',
    formName: 'sme_digital_lucy_my',
    name: 'SME Digital Lucy Malaysia',
    apiType: 'lucy1view_api', // genralForm_api // applicationAudit_api
    formType: 'lucy1view', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'sme_digital_lucy', 
    country: 'sg',
    productType: 'credit',
    lineOfBusiness: 'islamic',
    status: 'Active'
  },
  {
    key: '4',
    formName: 'pll_cashlite_my',
    name: 'PLL Cashlite Malaysia',
    apiType: 'applicationAuditForm_api', // genralForm_api // applicationAudit_api
    formType: 'audit', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'pll_cashlite', 
    country: 'my',
    productType: 'credit',
    lineOfBusiness: 'islamic',
    status: 'Active'
  },
  {
    key: '5',
    formName: 'contact_us_my',
    name: 'Contact Us Malaysia',
    apiType: 'genralForm_api', // genralForm_api // applicationAudit_api
    formType: 'contactus_feedback_enquiry', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'contact_us', 
    country: 'my',
    productType: 'credit',
    lineOfBusiness: 'islamic',
    status: 'Active'
  },
  {
    key: '6',
    formName: 'contact_us_sg',
    name: 'Contact Us Singapore',
    apiType: 'genralForm_api', // genralForm_api // applicationAudit_api
    formType: 'contactus_feedback_enquiry', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'contact_us', 
    country: 'sg',
    productType: 'credit',
    lineOfBusiness: 'islamic',
    status: 'Active'
  },
  {
    key: '7',
    formName: 'contact_us_th',
    name: 'Contact Us Thailand',
    apiType: 'genralForm_api', // genralForm_api // applicationAudit_api
    formType: 'contactus_feedback_enquiry', // lucy1view, lucy_complex, contactus_feedback_enquiry, campaign_enrollment
    subFormType: 'contact_us', 
    country: 'th',
    productType: 'credit',
    lineOfBusiness: 'islamic',
    status: 'Active'
  },
];

  function onChange(pagination, filters, sorter, extra) {
    console.log('params', pagination, filters, sorter, extra);
  }

const countryCode = () => {
    return (
        <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Product E-Form</h1>
        <p align="right"><Button type="danger" href="/productEformAdd">Add New</Button><br/></p>
        
  
        <Table columns={columns} dataSource={productEformDatas} onChange={onChange} />
        <Button type="danger" href="/productEformAdd">Add New</Button>


        </>
    );
}

export default countryCode;