import React from "react";
import { Table, Button } from 'antd';

const columns = [
  {
    title: 'Name',
    dataIndex: 'name',
    filters: [
      {
        text: 'Zaki',
        value: 'Zaki',
      },
      {
        text: 'Sharul',
        value: 'Sharul',
      },
    ],
    // specify the condition of filtering result
    // here is that finding the name started with `value`
    render: (text: string) => <a href="/contactus_my_detail">{text}</a>,
    onFilter: (value, record) => record.name.indexOf(value) === 0,
    sorter: (a, b) => a.name.length - b.name.length,
    sortDirections: ['descend'],
  },
  {
    title: 'Phone',
    dataIndex: 'age',
  },
  {
    title: 'Email',
    dataIndex: 'product',
  },
  {
    title: 'Status',
    dataIndex: 'status',
  },
];

const data = [
  {
    key: '1',
    name: 'Sharulnizam',
    age: '12345',
    product: 'user@gmail.com',
    status: 'Active',
  },
  {
    key: '2',
    name: 'Louis Phan',
    age: 42,
    product: 'GT / BE',
    status: 'Active',
  },
  {
    key: '3',
    name: 'Murali',
    age: 32,
    product: 'GT / BE',
    status: 'Active',
  },
  {
    key: '4',
    name: 'Muhammad Zaki',
    age: 32,
    product: 'GT / BE',
    status: 'Active',
  },
  {
    key: '5',
    name: 'Michael Learns To Rock',
    age: 62,
    product: 'GT / BE',
    status: 'In-Active',
  },
];

function onChange(pagination, filters, sorter, extra) {
  console.log('params', pagination, filters, sorter, extra);
}

const TableWithSearchFilter = () => {
  return (
    <div>
      <Table columns={columns} dataSource={data} onChange={onChange} />
      <Button href="http://www.google.com">Export To Excel</Button>
    </div>
  );
};



export default TableWithSearchFilter;