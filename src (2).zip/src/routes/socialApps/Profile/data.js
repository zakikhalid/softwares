import React from "react";
import {Avatar} from "antd";

const user = JSON.parse(localStorage.getItem('user'));
const userImageList = [
  {
    id: 1,
    image: '',
  },
  {
    id: 2,
    image: '',
  },
  {
    id: 3,
    image: '',

  },
  {
    id: 4,
    image: '',
    name: 'Mila Alba',
    rating: '5.0',
    deals: '27 Deals'
  },
];

export const aboutList = [
  {
    title: 'Works at',
    icon: 'company',
    userList: '',
    //desc: ['CIMB Bank Berhad']
  },
  {
    title: 'Department',
    icon: '',
    userList: '',
    //desc: ['Oct 21, 2020']
  },
  {
    title: 'Country',
    icon: '',
    userList: '',
    //desc: ['Malaysia']
  },
  {
    title: 'Contact No',
    icon: 'phone',
    userList: '',
    //desc: ['+6011 277 98137']
  },
  {
    title: 'Email',
    icon: 'email',
    userList: '',
    //desc: [user.email]
  },
];

export const eventList = [
  {
    id: 1,
    image: '',
    title: 'Sundance Film Festival.',
    address: 'Downsview Park, Toronto, Ontario',
    date: 'Feb 23, 2019',
  },
  {
    id: 2,
    image: '',
    title: 'Underwater Musical Festival.',
    address: 'Street Sacramento, Toronto, Ontario',
    date: 'Feb 24, 2019',
  },
  {
    id: 3,
    image: '',
    title: 'Village Feast Fac',
    address: 'Union Street Eureka',
    date: 'Oct 21, 2020',
  }
];

export const contactList = [
  {
    id: 1,
    title: 'Email',
    icon: 'email',
    desc: [<span className="gx-link" key={1}>{(user.email)}</span>]
  },
  {
    id: 2,
    title: 'Web page',
    icon: 'link',
    desc: [<span className="gx-link" key={2}>www.cimb.com</span>]
  }, {
    id: 3,
    title: 'Phone',
    icon: 'phone',
    desc: ['+603 2635 4278']
  },
];

export const friendList = [
  {
    id: 1,
    image: '',
    name: 'Chelsea Johns',
    status: 'online'

  },
  {
    id: 2,
    image: '',
    name: 'Ken Ramirez',
    status: 'offline'
  },
  {
    id: 3,
    image: '',
    name: 'Chelsea Johns',
    status: 'away'

  },
  {
    id: 4,
    image: '',
    name: 'Ken Ramirez',
    status: 'away'
  },
];
