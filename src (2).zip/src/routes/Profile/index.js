import React from "react";
import {Col, Row, Tabs} from "antd";
import Widget from "components/Widget";
import {aboutList} from '../socialApps/Profile/data';
import AboutItem from "../../components/profile/About/AboutItem";
import Biography from "../../components/profile/Biography/index";
import Contact from "../Profile/contact"
import About1 from "./About";
import ProfileHeader from '../Profile/profileHeader';

const TabPane = Tabs.TabPane;

const About = () => {

    return (
        <>
        
        <Row gutter={16}>
            <Col className="gutter-row" span={16}>
                <About1 />
            </Col>
            <Col className="gutter-row" span={8}>            
                <Contact />
            </Col>
        </Row>
      

      
      </>
    );
}


export default About;
