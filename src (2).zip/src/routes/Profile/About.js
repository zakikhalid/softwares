import React from "react";
import {Col, Row, Tabs} from "antd";
import Widget from "components/Widget";
//import {aboutList} from '../socialApps/Profile/data';
import AboutItem from "./AboutItem";
import Auxiliary from "util/Auxiliary";


const TabPane = Tabs.TabPane;

const About = () => {
  const {title, icon, desc, userList} = " ";
  const aboutList = [
    {
      title: 'Works at',
      icon: 'company',
      userList: '',
      //desc: ['CIMB Bank Berhad']
    },
    {
      title: 'Department',
      icon: '',
      userList: '',
      //desc: ['Oct 21, 2020']
    },
    {
      title: 'Country',
      icon: '',
      userList: '',
      //desc: ['Malaysia']
    },
    {
      title: 'Contact No',
      icon: 'phone',
      userList: '',
      //desc: ['+6011 277 98137']
    },
    {
      title: 'Email',
      icon: 'email',
      userList: '',
      //desc: [user.email]
    },
    {
      title: 'Role',
      icon: 'role',
      userList: ''
    }
  ]

    return (
      <Widget title="About" styleName="gx-card-tabs gx-card-profile">
        <Tabs className='gx-tabs-right' defaultActiveKey="1">
          <TabPane tab="Overview" key="1">
            <div className="gx-mb-2">
              <Row>
                {aboutList.map((about, index) =>
                  <Col key={index} xl={8} lg={12} md={12} sm={12} xs={24}>
                    {/* <AboutItem data={about}/> */}
                    <Auxiliary>
                      <div className="gx-media gx-flex-nowrap gx-mt-3 gx-mt-lg-4 gx-mb-2">
                        <div className="gx-mr-3">
                          <i className={`icon icon-${about.icon} gx-fs-xlxl gx-text-orange`}/>
                        </div>
                        <div className="gx-media-body">
                          <h6 className="gx-mb-1 gx-text-grey">{about.title}</h6>
                          {/* {userList === '' ? null : userList} */}
                          {/* {desc === '' ? null : <p className="gx-mb-0">{desc}</p>} */}
                        </div>
                      </div>
                    </Auxiliary>
                  </Col>
                )}
              </Row>
            </div>
          </TabPane>          
        </Tabs>
      </Widget>
    );
}


export default About;
