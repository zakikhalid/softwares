import React from "react";
import { Breadcrumb, Button } from 'antd';
import TableWithSearchFilter from '../TablePage/TableWithSearchFilter';

function contactus_my() {
    return (
      <div>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>CIMB Malaysia</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>LUCY Personal</h1>
        
        <TableWithSearchFilter />

        
      </div>
    );
}

export default contactus_my;