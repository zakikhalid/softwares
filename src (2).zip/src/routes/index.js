import React from "react";
import {Route, Switch} from "react-router-dom";

import asyncComponent from "util/asyncComponent";

const App = ({match}) => (
  <div className="gx-main-content-wrapper">
    <Switch>
      <Route path={`${match.url}sample`} component={asyncComponent(() => import('../routes/SamplePage'))}/>
      <Route path={`${match.url}table`} component={asyncComponent(() => import('../routes/TablePage'))}/>

      {/* Recharts */}
      {/* <Route path={`${match.url}barchart`} component={asyncComponent(() => import('../routes/Recharts/barcharts'))}/>
      <Route path={`${match.url}linechart`} component={asyncComponent(() => import('../routes/Recharts/linecharts'))}/> */}

      {/* Contact Us */}
      {/* <Route path={`${match.url}contactus_my`} component={asyncComponent(() => import('../routes/ContactUs/contactus_my'))}/>
      <Route path={`${match.url}contactus_my_detail`} component={asyncComponent(() => import('../routes/ContactUs/contactus_my_detail'))}/> */}

      {/* Campaign */}
      {/* <Route path={`${match.url}campaign_my`} component={asyncComponent(() => import('../routes/Campaign/campaign_my'))}/> */}

      {/* LUCY */}
      {/* <Route path={`${match.url}lucyc_my`} component={asyncComponent(() => import('../routes/LUCY/lucyc_my'))}/>
      <Route path={`${match.url}lucyp_my`} component={asyncComponent(() => import('../routes/LUCY/lucyp_my'))}/> */}

      {/* Maintenance */}
      {/* <Route path={`${match.url}countryCode`} component={asyncComponent(() => import('../routes/Maintenance/countryCode'))}/>
      <Route path={`${match.url}countryCodeAdd`} component={asyncComponent(() => import('../routes/Maintenance/countryCodeAdd'))}/>
      <Route path={`${match.url}productEform`} component={asyncComponent(() => import('../routes/Maintenance/productEform'))}/>
      <Route path={`${match.url}productEformAdd`} component={asyncComponent(() => import('../routes/Maintenance/productEformAdd'))}/>
      <Route path={`${match.url}productEformDetail`} component={asyncComponent(() => import('../routes/Maintenance/productEformDetail'))}/> */}

      {/* IT Security */}
      {/* <Route path={`${match.url}userMaintenance`} component={asyncComponent(() => import('../routes/ITSecurity/userMaintenance'))}/>
      <Route path={`${match.url}userMaintenanceAdd`} component={asyncComponent(() => import('../routes/ITSecurity/userMaintenanceAdd'))}/>
      <Route path={`${match.url}menuMaintenance`} component={asyncComponent(() => import('../routes/ITSecurity/menuMaintenance'))}/>
      <Route path={`${match.url}menuMaintenanceAdd`} component={asyncComponent(() => import('../routes/ITSecurity/menuMaintenanceAdd'))}/>      
      <Route path={`${match.url}rolesMaintenance`} component={asyncComponent(() => import('../routes/ITSecurity/rolesMaintenance'))}/>
      <Route path={`${match.url}rolesMaintenanceAdd`} component={asyncComponent(() => import('../routes/ITSecurity/rolesMaintenanceAdd'))}/> */}

      {/* Sample Page */}
      <Route path={`${match.url}form`} component={asyncComponent(() => import('../routes/SamplePage/form'))}/>

      {/* <Route path={`${match.url}profile`} component={asyncComponent(() => import('../routes/Profile/index'))}/> */}
      
      {/* Profile Page */}
      <Route path={`${match.url}profile`} component={asyncComponent(() => import('../components/Profile1/ProfileList'))}/>
      <Route path={`${match.url}profile-update`} component={asyncComponent(() => import('../components/Profile1/ProfileUpdate'))}/>
      
      {/* User Management */} 
      {/* <Route path={`${match.url}menuMaintenance`} component={asyncComponent(() => import('../components/usermanagement/menu/menu-list'))}/> */}
      <Route path={`${match.url}menu-list`} component={asyncComponent(() => import('../components/usermanagement/menu/MenuListTable'))}/>
      <Route path={`${match.url}menu-add`} component={asyncComponent(() => import('../components/usermanagement/menu/AddMenuForm'))}/>
      <Route path={`${match.url}menu-edit/:menuId`} component={asyncComponent(() => import('../components/usermanagement/menu/EditMenuForm'))}/>
      <Route path={`${match.url}menu-details/:menuId`} component={asyncComponent(() => import('../components/usermanagement/menu/MenuDetails'))}/>
      {/* <Route path={`${match.url}menuMaintenanceAdd`} component={asyncComponent(() => import('../components/usermanagement/menu/menu-add'))}/> */}

      {/* Report Suite */}
      {/* Report Suite Lucy*/} 
      {/* <Route path={`${match.url}menuMaintenance`} component={asyncComponent(() => import('../components/usermanagement/menu/menu-list'))}/> */}
      <Route path={`${match.url}lucy-forms-list`} component={asyncComponent(() => import('../components/report-suite/lucy/LucyFormsList'))}/>
      <Route path={`${match.url}lucy-form-fields-details-list/:productEformId`} component={asyncComponent(() => import('../components/report-suite/lucy/LucyFormFieldsDetailsList'))}/>
      <Route path={`${match.url}lucy-form-fields-details/:productEformFieldDetailsId`} component={asyncComponent(() => import('../components/report-suite/lucy/LucyFormFieldsDetails'))}/>
      {/* Report Suite contactus_feedback_enquiry*/} 
      <Route path={`${match.url}contactus-feedback-enquiry-forms-list`} component={asyncComponent(() => import('../components/report-suite/contactus_feedback_enquiry/ContactusFeedbackEnquiryFormsList'))}/>
      <Route path={`${match.url}contactus-feedback-enquiry-form-fields-details-list/:productEformId`} component={asyncComponent(() => import('../components/report-suite/contactus_feedback_enquiry/ContactusFeedbackEnquiryFormFieldsDetailsList'))}/>
      <Route path={`${match.url}contactus-feedback-enquiry-form-fields-details/:productEformFieldDetailsId`} component={asyncComponent(() => import('../components/report-suite/contactus_feedback_enquiry/ContactusFeedbackEnquiryFormFieldsDetails'))}/>
      {/* Report Suite campaign_enrollment*/} 
      <Route path={`${match.url}campaign-enrollment-forms-list`} component={asyncComponent(() => import('../components/report-suite/campaign_enrollment/CampaignEnrollmentFormsList'))}/>
      <Route path={`${match.url}campaign-enrollment-form-fields-details-list/:productEformId`} component={asyncComponent(() => import('../components/report-suite/campaign_enrollment/CampaignEnrollmentFormFieldsDetailsList'))}/>
      <Route path={`${match.url}campaign-enrollment-form-fields-details/:productEformFieldDetailsId`} component={asyncComponent(() => import('../components/report-suite/campaign_enrollment/CampaignEnrollmentFormFieldsDetails'))}/>

      {/* Product Management */}
      <Route path={`${match.url}form-listing`} component={asyncComponent(() => import('../components/productmanagement/formlisting/ProductEform'))}/>
      <Route path={`${match.url}form-view`} component={asyncComponent(() => import('../components/productmanagement/formlisting/ProductView'))}/>

      {/* Admin Administrator - Country */}
      <Route path={`${match.url}country-list`} component={asyncComponent(() => import('../components/applicationadmin/country/CountryCodeList'))}/>
      <Route path={`${match.url}country-add`} component={asyncComponent(() => import('../components/applicationadmin/country/CountryAdd'))}/>
      <Route path={`${match.url}country-view`} component={asyncComponent(() => import('../components/applicationadmin/country/CountryView'))}/>
      <Route path={`${match.url}country-update`} component={asyncComponent(() => import('../components/applicationadmin/country/CountryUpdate'))}/>
      {/* Admin Administrator - Api Auth */}
      <Route path={`${match.url}apiauth-list`} component={asyncComponent(() => import('../components/applicationadmin/apiauth/ApiAuthList'))}/>
      <Route path={`${match.url}apiauth-view`} component={asyncComponent(() => import('../components/applicationadmin/apiauth/ApiAuthView'))}/>
      <Route path={`${match.url}apiauth-add`} component={asyncComponent(() => import('../components/applicationadmin/apiauth/ApiAuthAdd'))}/>
      <Route path={`${match.url}apiauth-update`} component={asyncComponent(() => import('../components/applicationadmin/apiauth/ApiAuthUpdate'))}/>
      {/* Admin Administrator - Api Whitelist */}
      <Route path={`${match.url}apiwhitelist-list`} component={asyncComponent(() => import('../components/applicationadmin/apiwhitelist/ApiWhiteListTable'))}/>
      <Route path={`${match.url}apiwhitelist-view`} component={asyncComponent(() => import('../components/applicationadmin/apiwhitelist/ApiWhiteListView'))}/>
      <Route path={`${match.url}apiwhitelist-add`} component={asyncComponent(() => import('../components/applicationadmin/apiwhitelist/ApiWhiteListAdd'))}/>
      <Route path={`${match.url}apiwhitelist-update`} component={asyncComponent(() => import('../components/applicationadmin/apiwhitelist/ApiWhiteListUpdate'))}/>

      <Route path={`${match.url}activitylog-list`} component={asyncComponent(() => import('../components/report-suite/activity_log/ActivityLogList'))}/>
      
      <Route path={`${match.url}user-group-list`} component={asyncComponent(() => import('../components/permission/user_group/UserGroupListTable'))}/>
      <Route path={`${match.url}user-group-update`} component={asyncComponent(() => import('../components/permission/user_group/UpdateUserGroup'))}/>
    </Switch>
  </div>
);

export default App;
