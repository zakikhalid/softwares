import React, { useReducer, useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { inputLoginField, inputLoginPasswordField } from "./Inputs";
import {Button, Checkbox, Form, Input} from "antd";
import {useDispatch, useSelector} from "react-redux";
import { Link, useHistory } from "react-router-dom";
import "../styles/eform/eform-general.less";
import { userSignIn, userMenu } from "../appRedux/actions/Auth";
import IntlMessages from "util/IntlMessages";
import InfoView from "components/InfoView";

const SignIn = (props) => {
  const { handleSubmit, control, errors, reset } = useForm();
  
  const onSubmit = (data) => {
    //console.log(data);
      console.log("finish",data)
      const lanId = data.UserId;
      const password = data.Password;
      console.log("lanId is "+lanId);
      console.log("password is "+password);
      dispatch(userSignIn(data));
}
  const dispatch = useDispatch();
  const token = useSelector(({auth}) => auth.token);
  //const {token, initURL, authUser} = useSelector(({auth}) => auth);
  // const onFinishFailed = errorInfo => {
  //   console.log('Failed:', errorInfo);
  // };

  // const onFinish = values => {
  //   console.log("finish",values)
  //   dispatch(userSignIn(values));
  // };

  useEffect(() => {
    if (token !== null) {
      props.history.push('/');
    }
  }, [token, props.history]);
  return (
    <div className="gx-app-login-wrap">
      <div className="gx-app-login-container">
        <div className="gx-app-login-main-content">
          <div className="gx-app-logo-content">
            <div className="gx-app-logo-content-bg eform-gen-bg-red">
              {/* <img src="" alt='Neature'/> */}
            </div>
            <div className="gx-app-logo-wid">
              <h1><IntlMessages id="app.userAuth.signIn"/></h1>
              <p><IntlMessages id="app.userAuth.bySigning"/></p>
              <p><IntlMessages id="app.userAuth.getAccount"/></p>
            </div>
            <div className="gx-app-logo">
              <img alt="example" src={require("assets/images/cimb-bank-logo.png")}/>
            </div>
          </div>
          {/* <div className="gx-app-login-content"> */}

            <form onSubmit={handleSubmit(onSubmit)} className="gx-signin-form gx-form-row0">
            <div className='input-login-group'></div>
            <div className='input-login-group'></div>
            <div className='input-login-group'></div>
            <div className='input-login-group'></div>
                <div className='input-login-group'>
                    {/* <label className='label'>User ID</label> */}
                    <Controller as={inputLoginField("LAN ID")} name='UserId' control={control} defaultValue='' rules={{required:true}}/>
                    {errors.UserId && (<span className='eform-error'>UserId is required</span>)}                
                </div>
                <div className='input-login-group'>
                    {/* <label className='label'>Password</label> */}
                    <Controller as={inputLoginPasswordField("Password")} name='Password' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.Password && (<span className='eform-error'>Password is required</span>)}
                </div>

                &nbsp;&nbsp;&nbsp;&nbsp;<Button type='danger'  htmlType='submit'>Sign In</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button type='danger' htmlType='button' onClick={() => {
                    reset({
                        UserId: "",
                        Password: ""
                    });
                }}>Reset</Button>
            </form>

          {/* </div> */}
          <InfoView/>
        </div>
      </div>
    </div>
  );
};

export default SignIn;
