import React from 'react';
import { useForm, Controller } from "react-hook-form";
import { useHistory } from "react-router-dom";
import { inputField, inputPasswordField, SelectField, SwitchField } from "./Inputs";
import { Button } from "antd";
import AuthService from "../../services/login/auth-service";
import UserService from "../../services/login/user-service";
import Profile from './Profile';
import UserMenu from '../UserMenu';

function LoginForm() {
    const { handleSubmit, control, errors, reset } = useForm();
    const history = useHistory();
    const onSubmit = (data) => {
        AuthService.login(data.UserId, data.Password).then(
            (loginResponse) => {            
                UserService.getUserMenu(data.UserId).then(
                    (menuResponse) => {
                        //console.log(menuResponse.status);
                        console.log(menuResponse.data);
                        history.push('/user_menu');
                 }, (error) => {
                      console.log(error); 
                }  
                );
                console.log(loginResponse.data);
            },
            (error) => {

                alert(error.response.data);
            }
        );
    }
    return (
        <div>
            <form onSubmit={handleSubmit(onSubmit)} className='login-form'>
                <div className='input-group'>
                    <label className='label'>User ID</label>
                    <Controller as={inputField("UserId")} name='UserId' control={control} defaultValue='' rules={{required:true}}/>
                    {errors.UserId && (<span className='error'>UserId is required</span>)}                
                </div>
                <div className='input-group'>
                    <label className='label'>Password</label>
                    <Controller as={inputPasswordField("Password")} name='Password' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.Password && (<span className='error'>Password is required</span>)}
                </div>
                <Button type='primary' htmlType='submit'>Login</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button type='primary' htmlType='button' onClick={() => {
                    reset({
                        UserId: "",
                        Password: ""
                    });
                }}>Reset</Button>
            </form>
            
        </div>
    )
}

export default LoginForm
