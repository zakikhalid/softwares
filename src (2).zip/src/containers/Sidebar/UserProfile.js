import React, { Fragment, useState, useEffect } from "react";
import {useDispatch} from "react-redux";
import {Avatar, Popover} from "antd";
import {userSignOut} from "../../appRedux/actions/Auth";
import AuthService from "../../services/auth-service";
const UserProfile = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const dispatch = useDispatch();
  const [user, setUser] = useState({ userId: '', lanId: '', userFirstName: '', userLastName: '', apiRole: '', country: '',createdBy: '',
createdDateTime: '', departmentUnit: '', domain: '',lanId: '', modifiedBy: '', modifiedDateTime: '',
staffId: '', userAvatar: '', userEmail: '',userFirstName: '', userId: '',
userLastName: '', userMobileNumber: '', userStatus: ''});
  const userMenuOptions = (
    <ul className="gx-user-popover">
      {/* <li>My Account</li>
      <li>Connections</li> */}
      <li><a href="/profile">My Profile</a></li>
      <li onClick={() => dispatch(userSignOut())}>Logout
      </li>
    </ul>
  );
  useEffect(() => {
    setIsLoading(true)
    //setTimeout(() => {
    //setIsLoading(true)
    const currentUser = AuthService.currentUser();
    //const user = JSON.parse(localStorage.getItem('user'));
    setUser(currentUser)
  
  //}, 1500);
  setIsLoading(false)
  }, []);
  
  //const userFirstName = user.userFirstName;
  //console("userFirstName "+userFirstName);
  return (
    <Fragment>
    <>
    
  {
   isLoading ? <div>Loading... </div> : 
   isError ? <div>Error Occured... </div> :
      <div>
    <div className="gx-flex-row gx-align-items-center gx-mb-4 gx-avatar-row">
      <Popover placement="bottomRight" content={userMenuOptions} trigger="click">
        <Avatar src={require("../../assets/images/avatar/domnic-harris.png")}
                className="gx-size-40 gx-pointer gx-mr-3" alt=""/>
        <span className="gx-avatar-name">{(user.userFirstName).slice(0,1).toUpperCase()+(user.userFirstName).slice(1,user.userFirstName.length)}<i
          className="icon icon-chevron-down gx-fs-xxs gx-ml-2"/></span>
      </Popover>
    </div>
    </div>
    } 
    </>
      </Fragment> 
  );
};

export default UserProfile;
