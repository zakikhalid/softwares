-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: localhost    Database: testDB
-- ------------------------------------------------------
-- Server version	5.5.5-10.4.11-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contactus_feedback_enquiry`
--

DROP TABLE IF EXISTS `contactus_feedback_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contactus_feedback_enquiry` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `custom_field1` longtext DEFAULT NULL,
  `custom_field10` longtext DEFAULT NULL,
  `custom_field100` longtext DEFAULT NULL,
  `custom_field11` longtext DEFAULT NULL,
  `custom_field12` longtext DEFAULT NULL,
  `custom_field13` longtext DEFAULT NULL,
  `custom_field14` longtext DEFAULT NULL,
  `custom_field15` longtext DEFAULT NULL,
  `custom_field16` longtext DEFAULT NULL,
  `custom_field17` longtext DEFAULT NULL,
  `custom_field18` longtext DEFAULT NULL,
  `custom_field19` longtext DEFAULT NULL,
  `custom_field2` longtext DEFAULT NULL,
  `custom_field20` longtext DEFAULT NULL,
  `custom_field21` longtext DEFAULT NULL,
  `custom_field22` longtext DEFAULT NULL,
  `custom_field23` longtext DEFAULT NULL,
  `custom_field24` longtext DEFAULT NULL,
  `custom_field25` longtext DEFAULT NULL,
  `custom_field26` longtext DEFAULT NULL,
  `custom_field27` longtext DEFAULT NULL,
  `custom_field28` longtext DEFAULT NULL,
  `custom_field29` longtext DEFAULT NULL,
  `custom_field3` longtext DEFAULT NULL,
  `custom_field30` longtext DEFAULT NULL,
  `custom_field31` longtext DEFAULT NULL,
  `custom_field32` longtext DEFAULT NULL,
  `custom_field33` longtext DEFAULT NULL,
  `custom_field34` longtext DEFAULT NULL,
  `custom_field35` longtext DEFAULT NULL,
  `custom_field36` longtext DEFAULT NULL,
  `custom_field37` longtext DEFAULT NULL,
  `custom_field38` longtext DEFAULT NULL,
  `custom_field39` longtext DEFAULT NULL,
  `custom_field4` longtext DEFAULT NULL,
  `custom_field40` longtext DEFAULT NULL,
  `custom_field41` longtext DEFAULT NULL,
  `custom_field42` longtext DEFAULT NULL,
  `custom_field43` longtext DEFAULT NULL,
  `custom_field44` longtext DEFAULT NULL,
  `custom_field45` longtext DEFAULT NULL,
  `custom_field46` longtext DEFAULT NULL,
  `custom_field47` longtext DEFAULT NULL,
  `custom_field48` longtext DEFAULT NULL,
  `custom_field49` longtext DEFAULT NULL,
  `custom_field5` longtext DEFAULT NULL,
  `custom_field50` longtext DEFAULT NULL,
  `custom_field51` longtext DEFAULT NULL,
  `custom_field52` longtext DEFAULT NULL,
  `custom_field53` longtext DEFAULT NULL,
  `custom_field54` longtext DEFAULT NULL,
  `custom_field55` longtext DEFAULT NULL,
  `custom_field56` longtext DEFAULT NULL,
  `custom_field57` longtext DEFAULT NULL,
  `custom_field58` longtext DEFAULT NULL,
  `custom_field59` longtext DEFAULT NULL,
  `custom_field6` longtext DEFAULT NULL,
  `custom_field60` longtext DEFAULT NULL,
  `custom_field61` longtext DEFAULT NULL,
  `custom_field62` longtext DEFAULT NULL,
  `custom_field63` longtext DEFAULT NULL,
  `custom_field64` longtext DEFAULT NULL,
  `custom_field65` longtext DEFAULT NULL,
  `custom_field66` longtext DEFAULT NULL,
  `custom_field67` longtext DEFAULT NULL,
  `custom_field68` longtext DEFAULT NULL,
  `custom_field69` longtext DEFAULT NULL,
  `custom_field7` longtext DEFAULT NULL,
  `custom_field70` longtext DEFAULT NULL,
  `custom_field71` longtext DEFAULT NULL,
  `custom_field72` longtext DEFAULT NULL,
  `custom_field73` longtext DEFAULT NULL,
  `custom_field74` longtext DEFAULT NULL,
  `custom_field75` longtext DEFAULT NULL,
  `custom_field76` longtext DEFAULT NULL,
  `custom_field77` longtext DEFAULT NULL,
  `custom_field78` longtext DEFAULT NULL,
  `custom_field79` longtext DEFAULT NULL,
  `custom_field8` longtext DEFAULT NULL,
  `custom_field80` longtext DEFAULT NULL,
  `custom_field81` longtext DEFAULT NULL,
  `custom_field82` longtext DEFAULT NULL,
  `custom_field83` longtext DEFAULT NULL,
  `custom_field84` longtext DEFAULT NULL,
  `custom_field85` longtext DEFAULT NULL,
  `custom_field86` longtext DEFAULT NULL,
  `custom_field87` longtext DEFAULT NULL,
  `custom_field88` longtext DEFAULT NULL,
  `custom_field89` longtext DEFAULT NULL,
  `custom_field9` longtext DEFAULT NULL,
  `custom_field90` longtext DEFAULT NULL,
  `custom_field91` longtext DEFAULT NULL,
  `custom_field92` longtext DEFAULT NULL,
  `custom_field93` longtext DEFAULT NULL,
  `custom_field94` longtext DEFAULT NULL,
  `custom_field95` longtext DEFAULT NULL,
  `custom_field96` longtext DEFAULT NULL,
  `custom_field97` longtext DEFAULT NULL,
  `custom_field98` longtext DEFAULT NULL,
  `custom_field99` longtext DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `product_eform_id` bigint(20) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactus_feedback_enquiry`
--

LOCK TABLES `contactus_feedback_enquiry` WRITE;
/*!40000 ALTER TABLE `contactus_feedback_enquiry` DISABLE KEYS */;
INSERT INTO `contactus_feedback_enquiry` VALUES (2,'api1','2021-03-10 16:22:50',NULL,'2021-03-10 16:22:50','my','Female',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aqil@a.com','contact_us_malaysia_f01_dc01_my','Aqil','01112983321',1,'Active'),(3,'api1','2021-03-10 16:22:50',NULL,'2021-03-10 16:22:50','my','Male',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aqil@a.com','contact_us_malaysia_f01_dc01_my','Murali','01112983322',1,'Active'),(4,'api1','2021-03-10 16:22:50',NULL,'2021-03-10 16:22:50','my','Male',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sharul@a.com','contact_us_malaysia_f01_dc01_my','Sharul','011129833224',1,'Active');
/*!40000 ALTER TABLE `contactus_feedback_enquiry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_eform`
--

DROP TABLE IF EXISTS `product_eform`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_eform` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `api_type` varchar(255) DEFAULT NULL,
  `application_id` varchar(255) DEFAULT NULL,
  `audit_type` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `form_type` varchar(255) DEFAULT NULL,
  `line_of_business` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `path` varchar(255) DEFAULT NULL,
  `product_group` varchar(255) DEFAULT NULL,
  `product_group_code` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `sub_product_group` varchar(255) DEFAULT NULL,
  `sub_product_group_code` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_eform`
--

LOCK TABLES `product_eform` WRITE;
/*!40000 ALTER TABLE `product_eform` DISABLE KEYS */;
INSERT INTO `product_eform` VALUES (1,'api1','2021-03-10 16:22:50',NULL,NULL,'generalForm_api','CWEB-APIGW',NULL,'my','contact_us_malaysia_f01_dc01_my','contactus_feedback_enquiry','Group Islamic','Contact Us Malaysia','bcd.html','Financing','F01','Active','Credit Card','DC01'),(2,'api1','2021-03-10 16:24:48',NULL,NULL,'generalForm_api','CWEB-APIGW',NULL,'sg','contact_us_singapore_f01_dc02_sg','contactus_feedback_enquiry','Group Islamic','Contact Us Singapore','bcd.html','Financing','F01','Active','Platinum Card','DC02');
/*!40000 ALTER TABLE `product_eform` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_eform_settings_label`
--

DROP TABLE IF EXISTS `product_eform_settings_label`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_eform_settings_label` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `backend_name` varchar(255) DEFAULT NULL,
  `display` bit(1) DEFAULT NULL,
  `field_name` varchar(255) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `label_name` varchar(255) DEFAULT NULL,
  `product_eform_id` bigint(20) DEFAULT NULL,
  `seq` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_eform_settings_label`
--

LOCK TABLES `product_eform_settings_label` WRITE;
/*!40000 ALTER TABLE `product_eform_settings_label` DISABLE KEYS */;
INSERT INTO `product_eform_settings_label` VALUES (1,'api1','2021-03-10 16:22:50',NULL,NULL,'gender','','customField1','contact_us_malaysia_f01_dc01_my','Gender',1,1),(2,'api1','2021-03-10 16:22:50',NULL,NULL,'age','','customField2','contact_us_malaysia_f01_dc01_my','Age',1,2),(3,'api1','2021-03-10 16:22:50',NULL,NULL,'address2','','customField3','contact_us_malaysia_f01_dc01_my','Address 2',1,3),(4,'api1','2021-03-10 16:22:50',NULL,NULL,'address1','','customField4','contact_us_malaysia_f01_dc01_my','Address 1',1,4),(5,'api1','2021-03-10 16:22:50',NULL,NULL,'address3','','customField5','contact_us_malaysia_f01_dc01_my','Address 3',1,5),(6,'api1','2021-03-10 16:24:48',NULL,NULL,'gender','','customField1','contact_us_singapore_f01_dc02_sg','Gender',2,1),(7,'api1','2021-03-10 16:24:48',NULL,NULL,'age','','customField2','contact_us_singapore_f01_dc02_sg','Age',2,2),(8,'api1','2021-03-10 16:24:48',NULL,NULL,'address2','','customField3','contact_us_singapore_f01_dc02_sg','Address 2',2,3),(9,'api1','2021-03-10 16:24:48',NULL,NULL,'address1','','customField4','contact_us_singapore_f01_dc02_sg','Address 1',2,4),(10,'api1','2021-03-10 16:24:48',NULL,NULL,'address3','','customField5','contact_us_singapore_f01_dc02_sg','Address 3',2,5);
/*!40000 ALTER TABLE `product_eform_settings_label` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-10 16:46:28
