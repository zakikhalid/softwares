-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: cweb_db_test
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contactus_feedback_enquiry`
--

DROP TABLE IF EXISTS `contactus_feedback_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactus_feedback_enquiry` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date` datetime DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `custom_field1` longtext,
  `custom_field10` longtext,
  `custom_field100` longtext,
  `custom_field11` longtext,
  `custom_field12` longtext,
  `custom_field13` longtext,
  `custom_field14` longtext,
  `custom_field15` longtext,
  `custom_field16` longtext,
  `custom_field17` longtext,
  `custom_field18` longtext,
  `custom_field19` longtext,
  `custom_field2` longtext,
  `custom_field20` longtext,
  `custom_field21` longtext,
  `custom_field22` longtext,
  `custom_field23` longtext,
  `custom_field24` longtext,
  `custom_field25` longtext,
  `custom_field26` longtext,
  `custom_field27` longtext,
  `custom_field28` longtext,
  `custom_field29` longtext,
  `custom_field3` longtext,
  `custom_field30` longtext,
  `custom_field31` longtext,
  `custom_field32` longtext,
  `custom_field33` longtext,
  `custom_field34` longtext,
  `custom_field35` longtext,
  `custom_field36` longtext,
  `custom_field37` longtext,
  `custom_field38` longtext,
  `custom_field39` longtext,
  `custom_field4` longtext,
  `custom_field40` longtext,
  `custom_field41` longtext,
  `custom_field42` longtext,
  `custom_field43` longtext,
  `custom_field44` longtext,
  `custom_field45` longtext,
  `custom_field46` longtext,
  `custom_field47` longtext,
  `custom_field48` longtext,
  `custom_field49` longtext,
  `custom_field5` longtext,
  `custom_field50` longtext,
  `custom_field51` longtext,
  `custom_field52` longtext,
  `custom_field53` longtext,
  `custom_field54` longtext,
  `custom_field55` longtext,
  `custom_field56` longtext,
  `custom_field57` longtext,
  `custom_field58` longtext,
  `custom_field59` longtext,
  `custom_field6` longtext,
  `custom_field60` longtext,
  `custom_field61` longtext,
  `custom_field62` longtext,
  `custom_field63` longtext,
  `custom_field64` longtext,
  `custom_field65` longtext,
  `custom_field66` longtext,
  `custom_field67` longtext,
  `custom_field68` longtext,
  `custom_field69` longtext,
  `custom_field7` longtext,
  `custom_field70` longtext,
  `custom_field71` longtext,
  `custom_field72` longtext,
  `custom_field73` longtext,
  `custom_field74` longtext,
  `custom_field75` longtext,
  `custom_field76` longtext,
  `custom_field77` longtext,
  `custom_field78` longtext,
  `custom_field79` longtext,
  `custom_field8` longtext,
  `custom_field80` longtext,
  `custom_field81` longtext,
  `custom_field82` longtext,
  `custom_field83` longtext,
  `custom_field84` longtext,
  `custom_field85` longtext,
  `custom_field86` longtext,
  `custom_field87` longtext,
  `custom_field88` longtext,
  `custom_field89` longtext,
  `custom_field9` longtext,
  `custom_field90` longtext,
  `custom_field91` longtext,
  `custom_field92` longtext,
  `custom_field93` longtext,
  `custom_field94` longtext,
  `custom_field95` longtext,
  `custom_field96` longtext,
  `custom_field97` longtext,
  `custom_field98` longtext,
  `custom_field99` longtext,
  `email` varchar(255) DEFAULT NULL,
  `form_name` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `product_eform_id` bigint DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactus_feedback_enquiry`
--

LOCK TABLES `contactus_feedback_enquiry` WRITE;
/*!40000 ALTER TABLE `contactus_feedback_enquiry` DISABLE KEYS */;
INSERT INTO `contactus_feedback_enquiry` VALUES (2,'api1','2021-03-10 16:22:50',NULL,'2021-03-10 16:22:50','my','Female',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'53',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aqil@a.com','contact_us_malaysia_f01_dc01_my','Aqil','01112983321',1,'Active'),(3,'api1','2021-03-10 16:22:50',NULL,'2021-03-10 16:22:50','my','Male',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'15',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 1',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 2',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 3',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'aqil@a.com','contact_us_malaysia_f01_dc01_my','Murali','01112983322',1,'Active'),(4,'api1','2021-03-10 16:22:50',NULL,'2021-03-10 16:22:50','my','Male',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 33',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'Address 44',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'sharul@a.com','contact_us_malaysia_f01_dc01_my','Sharul','011129833224',1,'Active');
/*!40000 ALTER TABLE `contactus_feedback_enquiry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-16 15:37:34
