-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: cweb_db_test
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu` (
  `menu_id` bigint NOT NULL AUTO_INCREMENT,
  `parent_id` bigint DEFAULT NULL,
  `menu_name` varchar(255) DEFAULT NULL,
  `menu_link` varchar(255) DEFAULT NULL,
  `menu_order` bigint DEFAULT NULL,
  `created_by` varchar(255) DEFAULT NULL,
  `created_date_time` datetime DEFAULT NULL,
  `modified_by` varchar(255) DEFAULT NULL,
  `modified_date_time` datetime DEFAULT NULL,
  PRIMARY KEY (`menu_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `menu`
--

LOCK TABLES `menu` WRITE;
/*!40000 ALTER TABLE `menu` DISABLE KEYS */;
INSERT INTO `menu` VALUES (1,0,'Report Suite',NULL,1,'Muralikrishna',NULL,NULL,NULL),(2,1,'Malaysia',NULL,1,'Muralikrishna',NULL,NULL,NULL),(3,2,'LUCY (MY)','/lucy-forms-list-table',1,'Muralikrishna',NULL,NULL,NULL),(4,2,'Contact Us (MY)','/contactus-forms-list-table',2,'Muralikrishna',NULL,NULL,NULL),(5,2,'Compaign (MY)','/campaign-forms-list-table',3,'Muralikrishna',NULL,NULL,NULL),(6,2,'Audit Trail (MY)','/audit-trail-list-table',4,'Muralikrishna',NULL,NULL,NULL),(7,1,'Singapore',NULL,2,'Muralikrishna',NULL,NULL,NULL),(8,7,'LUCY (SG)',NULL,1,'Muralikrishna',NULL,NULL,NULL),(9,7,'Contact Us (SG)',NULL,2,'Muralikrishna',NULL,NULL,NULL),(10,7,'Compaign (SG)',NULL,3,'Muralikrishna',NULL,NULL,NULL),(11,7,'Audit Trail (SG)',NULL,4,'Muralikrishna',NULL,NULL,NULL),(12,0,'Permissions',NULL,2,'Muralikrishna',NULL,NULL,NULL),(13,12,'User Group','/user-group-list',1,'Muralikrishna',NULL,NULL,NULL),(14,12,'User Listing',NULL,2,'Muralikrishna',NULL,NULL,NULL),(15,0,'Product Management',NULL,3,'Muralikrishna',NULL,NULL,NULL),(16,15,'Form Listing',NULL,1,'Muralikrishna',NULL,NULL,NULL),(17,0,'User Management',NULL,4,'Muralikrishna',NULL,NULL,NULL),(18,17,'Add Users',NULL,1,'Muralikrishna',NULL,NULL,NULL),(19,17,'Assign User Screen Access',NULL,2,'Muralikrishna',NULL,NULL,NULL),(20,17,'Assign Menu Item','/menu-list',3,'Muralikrishna',NULL,NULL,NULL),(21,0,'IT Security Report',NULL,5,'Muralikrishna',NULL,NULL,NULL),(22,21,'Audit Log Report',NULL,1,'Muralikrishna',NULL,NULL,NULL),(23,21,'Violation Report',NULL,2,'Muralikrishna',NULL,NULL,NULL),(24,21,'User Access Matrix Report',NULL,3,'Muralikrishna',NULL,NULL,NULL),(25,21,'Dormancy Report',NULL,4,'Muralikrishna',NULL,NULL,NULL),(26,0,'Application Admin',NULL,6,'Muralikrishna',NULL,NULL,NULL),(27,26,'Country Code',NULL,1,'Muralikrishna',NULL,NULL,NULL),(28,26,'Forms Configuration',NULL,2,'Muralikrishna',NULL,NULL,NULL),(29,26,'API Access Auth',NULL,3,'Muralikrishna',NULL,NULL,NULL),(30,26,'API IP Whitelist',NULL,4,'Muralikrishna',NULL,NULL,NULL),(33,7,'Test Menu Updated','test-menu-updated',6,'mycaps02',NULL,NULL,NULL),(36,6,'Zaki Murali Test','../zakitest/murali/raymond',8,'mycaps02','2021-03-08 04:54:21','mycaps02','2021-03-08 04:58:36'),(37,25,'Test ERROR','/test',3,'mycaps02','2021-03-09 14:22:03',NULL,NULL);
/*!40000 ALTER TABLE `menu` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-03-16 15:37:36
