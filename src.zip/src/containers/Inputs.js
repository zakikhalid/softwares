import React from 'react';
import { Input, Select, Switch, InputNumber } from "antd";
const { Option } = Select;

export const inputField = (placeholder) => {
    return <Input placeholder={placeholder} style={{ width: 500}}/>;
};
export const inputPasswordField = (placeholder) => {
    return <Input.Password placeholder={placeholder} style={{ width: 500}}/>;
};
export const inputLoginField = (placeholder) => {
    return <Input placeholder={placeholder} style={{ width: 300}}/>;
};
export const inputLoginPasswordField = (placeholder) => {
    return <Input.Password placeholder={placeholder} style={{ width: 300}}/>;
};
export const inputNumberField = (placeholder) => {
    return <InputNumber placeholder={placeholder} style={{ width: 80}}/>;
};
export const SelectField = (defaultValue, values) => {
    return (<Select defaultValue={defaultValue} style={{ width: 500 }}>
        {values.map((value, index) => {
            return (
                <Option value={value} key={index}>
                    {value}
                </Option>
            );
        })}
    </Select>
    );
};
export const SelectMenuField = (defaultValue, values) => {
    return (<Select defaultValue={defaultValue} style={{ width: 500 }}>
        {values.map((value, index) => {
            return (
                <Option value={value.menuId} key={index}>
                    {value.menuName}
                </Option>
            );
        })}
    </Select>
    );
};
export const SwitchField = () => {
    return <Switch defaultChecked style={{maxWidth: 50}} />;
};
