import React from "react";
import {useSelector} from "react-redux";
import {Menu} from "antd";
import {Link} from "react-router-dom";

import CustomScrollbars from "util/CustomScrollbars";
import SidebarLogo from "./SidebarLogo";
import UserProfile from "./UserProfile";
import AppsNavigation from "./AppsNavigation";
import {
  NAV_STYLE_NO_HEADER_EXPANDED_SIDEBAR,
  NAV_STYLE_NO_HEADER_MINI_SIDEBAR,
  THEME_TYPE_LITE
} from "../../constants/ThemeSetting";
import IntlMessages from "../../util/IntlMessages";
import AuthService from "../../services/auth-service";
const SidebarContent = () => {

  let {navStyle, themeType} = useSelector(({settings}) => settings);
  let {pathname} = useSelector(({common}) => common);

  const getNoHeaderClass = (navStyle) => {
    if (navStyle === NAV_STYLE_NO_HEADER_MINI_SIDEBAR || navStyle === NAV_STYLE_NO_HEADER_EXPANDED_SIDEBAR) {
      return "gx-no-header-notifications";
    }
    return "";
  };
  const SubMenu = Menu.SubMenu;
  const MenuItemGroup = Menu.ItemGroup;

  const selectedKeys = pathname.substr(1);
  const defaultOpenKeys = selectedKeys.split('/')[1];
  //const userMenu = JSON.parse(localStorage.getItem('menu'));
  // const test = {
  //   name : AuthService.currentUserMenu()
  // }

const userMenu = JSON.parse(localStorage.getItem('menu'));
const parentMenuList = userMenu.parentMenuList;
const childMenuList = userMenu.childMenuList;
const subChildList = userMenu.subChildMenuList;
const isSubChildAvailable = (childmenuId) =>{
  return  subChildList.some(subchildMenu => subchildMenu.parentId === childmenuId);
}
  return (<>

      <SidebarLogo/>
      <div className="gx-sidebar-content">
        <div className={`gx-sidebar-notifications ${getNoHeaderClass(navStyle)}`}>
          <UserProfile/>
          <AppsNavigation/>
        </div>
        <CustomScrollbars className="gx-layout-sider-scrollbar">
          <Menu
            defaultOpenKeys={[defaultOpenKeys]}
            selectedKeys={[selectedKeys]}
            theme={themeType === THEME_TYPE_LITE ? 'lite' : 'dark'}
            mode="inline">

            <Menu.Item key="sample">
              <Link to="/sample"><i className="icon icon-widgets"/>
                <span><IntlMessages id="sidebar.samplePage"/></span>
              </Link>
            </Menu.Item>
              {
                      parentMenuList.map((parentmenu, p) => {                       
                        if (parentmenu.parentId === 0){
                          return ( <SubMenu key={p} title={<span><span>{parentmenu.menuName}</span></span>}>
                            {
                              childMenuList.map((childmenu,c) => {                                
                                if (childmenu.parentId === parentmenu.menuId){
                                      if (isSubChildAvailable(childmenu.menuId)){
                                          return ( <SubMenu key={c} title={<span><span>{childmenu.menuName}</span></span>}>
                                                {
                                                  subChildList.map((subchildMenu) => {
                                                      if (subchildMenu.parentId === childmenu.menuId){
                                                      return (<Menu.Item key={subchildMenu.menuId}>
                                                              {/* <Link to={`${subchildMenu.menuLink}`}><span>{subchildMenu.menuName}</span></Link> */}
                                                              <Link to="/menuMaintenance"><span>{subchildMenu.menuName}</span></Link>
                                                             </Menu.Item>
                                                             )
                                                      }
                                                  })
                                                }
                                          </SubMenu> )
                                      }else{
                                        return  (<Menu.Item key={childmenu.menuId}>
                                        <Link to="/menuMaintenance"><span>{childmenu.menuName}</span></Link>
                                                 {/* <Link to={`${childmenu.menuLink}`}><span>{childmenu.menuName}</span></Link> */}
                                                 </Menu.Item>
                                                )
                                      } 
                                }
                              })
                            }
                          </SubMenu> )
                        }
                      })
             } 
          </Menu>
        </CustomScrollbars>
      </div>
    </>
  );
};

SidebarContent.propTypes = {};

export default SidebarContent;

