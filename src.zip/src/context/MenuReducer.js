export default (state, action) => {
    switch (action.type) {
        case 'REMOVE_MENU':
            return {
                ...state,
                menus: state.menus.filter(menu => menu.menuId !== action.payload)
            };
        case 'ADD_MENU':
            return {
                ...state,
                menus: [...state.menus, action.payload]
            };
        case 'EDIT_MENU':
            const updatedMenu = action.payload;

            const updatedMenus = state.menus.map(menu => {
                if (menu.menuId === updatedMenu.menuId) {
                    return updatedMenu;
                }
                return menu;
            });

            return {
                ...state,
                menus: updatedMenus
            };
        default: return state;
    }
};