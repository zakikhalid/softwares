import axios from "axios";
import authHeader from "./auth-header";

const API_URL = "http://localhost:8087/api/portal/";

const getPublicContent = () => {
    return axios.get(API_URL + "all");
};

const getUserBoard = () => {
    return axios.get(API_URL + "user", { headers: authHeader() });
};

const getModeratorBoard = () => {
    return axios.get(API_URL + "mod", { headers: authHeader() });
};

const getAdminBoard = () => {
    return axios.get(API_URL + "admin", { headers: authHeader() });
};

const getUserMenu = (staffId) => {

    return axios.get(API_URL + "menu" + '/' + staffId, { headers: authHeader() }).then((response) => {
        if (response.status === 200) {
            localStorage.setItem("menu", JSON.stringify(response.data));//response.data.user
        }
        //console.log(response.data)
        return response;
    });
};

export default {
    getPublicContent,
    getUserBoard,
    getModeratorBoard,
    getAdminBoard,
    getUserMenu,
};
