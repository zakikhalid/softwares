import axios from "axios";
//import { useHistory } from "react-router-dom";

//const API_URL = "http://localhost:8011/payment/16";
//const API_URL = "http://localhost:8011/api/auth/";
//const API_URL = "http://localhost:8081/api/v1/hello-world/hello";
//const API_URL = "http://localhost:8011/users/";
//const API_URL = "http://localhost:8011/users/signin?username=mycaps02&password=cimb123$";
const API_URL = "http://localhost:8011/users/";
const register = (username, email, password) => {
    return axios.post(API_URL + "signup", {
        username,
        email,
        password,
    });
};
const loginPost_old = (userId, password) => {
    console.log('login userId   '+userId)
    return axios
        .post(API_URL + "signin", {
            userId,
            password
        })
        .then((response) => {
            if (response.data.accessToken) {
                localStorage.setItem("user", JSON.stringify(response.data));
                localStorage.setItem("token", JSON.stringify(response.data.accessToken));
            }
            //return response.data;
            return response;
        });
};
const login = (username, password) => {
    console.log('login username   '+username)
    const credentials = {
        username: username,
        password: password
    };

    return axios.
    post("http://localhost:8087/api/portal/signin", credentials)
        .then((response) => {
            console.log(" Response is "+response.data)
            if (response.data.accessToken) {
                localStorage.setItem("user", JSON.stringify(response.data.user));
                localStorage.setItem("token", JSON.stringify(response.data.accessToken));
            }
            //return response.data;
            return response;
        });
};

const logout = () => {
    //const history = useHistory();
    localStorage.removeItem("user");
    localStorage.removeItem("token");
    localStorage.removeItem("menu");
   // history.push('/');
};
const currentUser = () => {
    const user = JSON.parse(localStorage.getItem("user"));
    return user;
};
const currentUserMenu = () => {
    return JSON.parse(localStorage.getItem("menu"));
};
const currentUserToken = () => {
    return JSON.parse(localStorage.getItem("token"));
};

export default {
    register,
    login,
    logout,
    currentUser,
    currentUserMenu,
    currentUserToken
};
