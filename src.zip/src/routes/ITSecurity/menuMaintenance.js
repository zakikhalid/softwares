import React, { useState } from 'react';
import { Table, Switch, Space, Breadcrumb, Button } from 'antd';
import ContainerHeader from '../../components/ContainerHeader/index';

const columns = [
  {
    title: 'Title',
    dataIndex: 'title',
    key: 'title',
    render: (text: string) => <a href="/menuMaintenanceEdit">{text}</a>,
  },
  {
    title: 'Link',
    dataIndex: 'link',
    key: 'link',
  },
  {
    title: 'Order',
    dataIndex: 'order',
    key: 'order',
    width: '10%',
  },
  {
    title: 'Status',
    dataIndex: 'status',
    width: '10%',
    key: 'status',
  },
];

const data = [    
  {
    key: 1,
    title: 'Dashboard',
    link: '/dashboard',
    order: 1,
    status: 'Active',
  },
  {
    key: 2,
    title: 'IT Security',
    link: '',
    order: 2,
    status: 'Active',
    children: [
      {
        key: 21,
        title: 'Roles Maintenance',
        link: '/rolesMaintenance',
        order: 1,
        status: 'Active',
      },
      {
        key: 12,
        title: 'Report',
        link: '',
        order: 3,
        status: 'Active',
        children: [
          {
            key: 121,
            title: 'Audit Report',
            link: '/auditReport',
            order: 1,
            status: 'Active',
          },
          {
            key: 122,
            title: 'Dormancy Report',
            link: '/dormancyReport',
            order: 2,
            status: 'In-Active',
          },
        ],
      },
      {
        key: 13,
        title: 'Audit Report',
        link: '/dormancyReport',
        order: 12,
        status: 'Active',        
      },
    ],
  },
  {
    key: 143,
    title: 'Profile',
    link: '/profile',
    order: 32,
    status: 'Active',
  },
  {
    key: 222,
    title: 'CIMB MY',
    link: '/dashboard',
    order: 3,
    status: 'Active',
    children: [
      {
        key: 21,
        title: 'LUCY Personal',
        link: '/lucypersonal_my',
        order: 1,
        status: 'Active',
      },
    ]
  },
];

// rowSelection objects indicates the need for row selection
const rowSelection = {
  onChange: (selectedRowKeys, selectedRows) => {
    console.log(`selectedRowKeys: ${selectedRowKeys}`, 'selectedRows: ', selectedRows);
  },
  onSelect: (record, selected, selectedRows) => {
    console.log(record, selected, selectedRows);
  },
  onSelectAll: (selected, selectedRows, changeRows) => {
    console.log(selected, selectedRows, changeRows);
  },
};

function TreeData() {
  const [checkStrictly, setCheckStrictly] = React.useState(false);
  return (
    <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>IT Security</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menuMaintenance">Menu Maintenance</a></Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance</h1>
        <ContainerHeader />
        <p align="right"><Button type="danger" href="/menuMaintenanceAdd">Add New</Button><br/></p>
        
      <Table
        columns={columns}
        
        dataSource={data}
      />
      <Button type="danger" href="/menuMaintenanceAdd">Add New</Button>
    </>
  );
}

export default TreeData;