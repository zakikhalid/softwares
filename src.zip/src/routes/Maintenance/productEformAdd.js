import React, { useState } from 'react';
import {
  Form,
  Input,
  Button,
  Radio,
  Select,
  Cascader,
  DatePicker,
  InputNumber,
  TreeSelect,
  Switch,
  Breadcrumb,
  Checkbox,
} from 'antd';


const ProductEformAdd = () => {

    const formItemLayout = {
        labelCol: {
        xs: { span: 24 },
        sm: { span: 5 },
        },
        wrapperCol: {
        xs: { span: 24 },
        sm: { span: 10 },
        },
    };
    
    const tailFormItemLayout = {
        wrapperCol: {
        xs: {
            span: 24,
            offset: 0,
        },
        sm: {
            span: 3,
            offset: 10,
        },
        },
    };
    
    const apiTypeVals = [
      {
        key: 'lucy1view_api',
        value: 'LUCY 1View Api'
      },
      {
        key: 'genralForm_api',
        value: 'General Form Api'
      },
      {
        key: 'applicationAuditForm_api',
        value: 'Application Audit Form Api'
      }
    ];

    const subFormTypeVals = {
        lucy1view_api: [
          {
            key: 'master_lucy',
            value: 'Master Lucy'
          },
          {
            key: 'lucy',
            value: 'Lucy'
          },
          {
            key: 'sme_digital_lucy',
            value: 'SME Digital Lucy'
          },
          {
            key: 'normal_lucy_v2',
            value: 'Normal Lucy V2'
          }
        ],
        genralForm_api: [
          {
            key: 'lucy_personal',
            value: 'Lucy Personal'
          },
          {
            key: 'lucy_business',
            value: 'Lucy Business'
          },
          {
            key: 'lucy_prefered',
            value: 'Lucy Prefered'
          },
          {
            key: 'web_enrollment',
            value: 'Web Enrollment'
          },
          {
            key: 'contact_us',
            value: 'Contact Us'
          },
        ],
        applicationAuditForm_api: [
          {
            key: 'obca',
            value: 'OBCA'
          },
          {
            key: 'pll_cashlite',
            value: 'PLL CashLite'
          },
          {
            key: 'application_status_checker',
            value: 'Application Status Checker'
          },
          {
            key: 'upload_document',
            value: 'Upload Document'
          },
          {
            key: 'casa_deposit_main',
            value: 'CASA/ Deposit (Main Application)'
          },
          {
            key: 'casa_deposit_resume',
            value: 'CASA/ Deposit (Resume Application)'
          },
        ]
    };

    let initApiType = apiTypeVals[0].key;

    const [subFormTypes, setSubFormTypes] = React.useState(subFormTypeVals[apiTypeVals[0].key]);
    const [selectSubFormTypes, setSelectSubFormTypes] = React.useState(subFormTypeVals[apiTypeVals[0].key][0]);
    let initVal;

    const handleApiTypeChange = value => {
      setSubFormTypes(subFormTypeVals[value]);
      setSelectSubFormTypes(subFormTypeVals[value].key);
      initVal = subFormTypeVals[value][0].key;
      console.log(selectSubFormTypes);
    };
  
    const handleSelectApiTypeChange = value => {
      setSelectSubFormTypes(value);
    };
  

  return (
    <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>Maintenance</Breadcrumb.Item>
            <Breadcrumb.Item>Add Product Eform</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Product Eform - Add New</h1>
        <p><br/></p>

        <Form
            {...formItemLayout}
            initialValues={{ remember: true}}
            layout="horizontal"
            size='large'
        >
            <Form.Item 
                label="Name"
                name="name"
                rules={[{ required: true, message: 'Please input name!' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item label="Form Type" name="formType">
                <Select defaultValue="none">
                    <Select.Option value="audit">audit</Select.Option>
                    <Select.Option value="lucy1view">LUCY 1View Api Form</Select.Option>
                    <Select.Option value="lucy_complex">LUCY Complex Form</Select.Option>
                    <Select.Option value="contactus_feedback_enquiry">Contact Us / Feedback / Enquiry Form</Select.Option>
                    <Select.Option value="campaign_enrollment">Campaign / Enrollment Form</Select.Option>
                </Select>
            </Form.Item>
            <Form.Item label="Api Type" name="apiType">
                <Select defaultValue={initApiType} onChange={handleApiTypeChange} >
                    {apiTypeVals.map(apiTypeItem => (
                      <Select.Option key={apiTypeItem.key}>{apiTypeItem.value}</Select.Option>
                    ))}
                </Select>
            </Form.Item>
            <Form.Item label="Sub Form Type" name="subFormType">
                <Select value={selectSubFormTypes} onChange={handleSelectApiTypeChange} >
                    {subFormTypes.map(subFormItem => (
                      <Select.Option key={subFormItem.key}>{subFormItem.value}</Select.Option>
                    ))}
                </Select>
            </Form.Item>
            <Form.Item label="Country" name="country">
                <Select defaultValue="my">
                    <Select.Option value="ch">Cambodia</Select.Option>
                    <Select.Option value="my">Malaysia</Select.Option>
                    <Select.Option value="ph">Philippine</Select.Option>
                    <Select.Option value="sg">Singapore</Select.Option>
                    <Select.Option value="th">Thailand</Select.Option>                    
                    <Select.Option value="vn">Vietname</Select.Option>
                </Select>
            </Form.Item>
            <Form.Item label="Status"> 
                <Radio.Group value={1} >
                    <Radio value={1}>Active</Radio>
                    <Radio value={2}>Inactive</Radio>
                </Radio.Group>
            </Form.Item>        
            <Form.Item {...tailFormItemLayout}>
                <Button type="danger" htmlType="submit">
                    Add
                </Button>
            </Form.Item>
         </Form>
    </>
  );
};

export default ProductEformAdd;