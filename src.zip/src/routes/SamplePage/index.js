import React from "react";

import IntlMessages from "util/IntlMessages";
import Widget from "../../components/Widget/index";
import {Button} from "antd";
import AuthService from "../../services/auth-service";
const SamplePage = () => {
  
const currentUser = AuthService.currentUser();
console.log(" currentUser is "+currentUser);
  return (
    <div>
      <h2 className="title gx-mb-4">{(currentUser.userFirstName).slice(0,1).toUpperCase()+(currentUser.userFirstName).slice(1,currentUser.userFirstName.length)} - Page</h2>

      <div className="gx-d-flex justify-content-center">
      <h4>This is {(currentUser.userFirstName).slice(0,1).toUpperCase()+(currentUser.userFirstName).slice(1,currentUser.userFirstName.length)}'s page</h4>
      </div>
      

      <div className="ant-card ant-card-bordered">
	<div className="ant-card-head">
		<div className="ant-card-head-wrapper">
			<div className="ant-card-head-title">{(currentUser.userFirstName).slice(0,1).toUpperCase()+(currentUser.userFirstName).slice(1,currentUser.userFirstName.length)} Table</div>
		</div>
	</div>
	<div className="ant-card-body">
		<div className="ant-table-wrapper gx-table-responsive">
			<div className="ant-spin-nested-loading">
				<div className="ant-spin-container">
					<div className="ant-table">
						<div className="ant-table-container">
							<div className="ant-table-content">
								<table width="100%">
									<colgroup></colgroup>
									<thead className="ant-table-thead">
										<tr><th className="ant-table-cell">Name</th><th className="ant-table-cell">Age</th><th className="ant-table-cell">Address</th><th className="ant-table-cell">Action</th></tr>
									</thead>
									<tbody className="ant-table-tbody">
										<tr data-row-key="1" className="ant-table-row ant-table-row-level-0"><td className="ant-table-cell"><span className="gx-link">John Brown</span></td><td className="ant-table-cell">32</td><td className="ant-table-cell">New York No. 1 Lake Park</td><td className="ant-table-cell"><span><span className="gx-link">Action 一 John Brown</span><div className="ant-divider ant-divider-vertical" role="separator"></div><span className="gx-link">Delete</span><div className="ant-divider ant-divider-vertical" role="separator"></div><span className="gx-link ant-dropdown-link">More actions <span role="img" type="down" className="anticon"></span></span></span></td></tr>
										<tr data-row-key="2" className="ant-table-row ant-table-row-level-0"><td className="ant-table-cell"><span className="gx-link">Jim Green</span></td><td className="ant-table-cell">42</td><td className="ant-table-cell">London No. 1 Lake Park</td><td className="ant-table-cell"><span><span className="gx-link">Action 一 Jim Green</span><div className="ant-divider ant-divider-vertical" role="separator"></div><span className="gx-link">Delete</span><div className="ant-divider ant-divider-vertical" role="separator"></div><span className="gx-link ant-dropdown-link">More actions <span role="img" type="down" className="anticon"></span></span></span></td></tr>
										<tr data-row-key="3" className="ant-table-row ant-table-row-level-0"><td className="ant-table-cell"><span className="gx-link">Joe Black</span></td><td className="ant-table-cell">32</td><td className="ant-table-cell">Sidney No. 1 Lake Park</td><td className="ant-table-cell"><span><span className="gx-link">Action 一 Joe Black</span><div className="ant-divider ant-divider-vertical" role="separator"></div><span className="gx-link">Delete</span><div className="ant-divider ant-divider-vertical" role="separator"></div><span className="gx-link ant-dropdown-link">More actions <span role="img" type="down" className="anticon"></span></span></span></td></tr>
									</tbody>
								</table>
							</div>
						</div>
					</div>
					<ul className="ant-pagination ant-table-pagination ant-table-pagination-right" unselectable="unselectable">
						<li title="Previous Page" className="ant-pagination-prev ant-pagination-disabled" aria-disabled="true"><a className="ant-pagination-item-link" disabled=""><span role="img" aria-label="left" className="anticon anticon-left"><svg viewBox="64 64 896 896" focusable="false" className="" data-icon="left" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M724 218.3V141c0-6.7-7.7-10.4-12.9-6.3L260.3 486.8a31.86 31.86 0 000 50.3l450.8 352.1c5.3 4.1 12.9.4 12.9-6.3v-77.3c0-4.9-2.3-9.6-6.1-12.6l-360-281 360-281.1c3.8-3 6.1-7.7 6.1-12.6z"></path></svg></span></a></li>
						<li title="1" className="ant-pagination-item ant-pagination-item-1 ant-pagination-item-active" tabIndex="0"><a>1</a></li>
						<li title="Next Page" className="ant-pagination-next ant-pagination-disabled" aria-disabled="true"><a className="ant-pagination-item-link" disabled=""><span role="img" aria-label="right" className="anticon anticon-right"><svg viewBox="64 64 896 896" focusable="false" className="" data-icon="right" width="1em" height="1em" fill="currentColor" aria-hidden="true"><path d="M765.7 486.8L314.9 134.7A7.97 7.97 0 00302 141v77.3c0 4.9 2.3 9.6 6.1 12.6l360 281.1-360 281.1c-3.9 3-6.1 7.7-6.1 12.6V883c0 6.7 7.7 10.4 12.9 6.3l450.8-352.1a31.96 31.96 0 000-50.4z"></path></svg></span></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>

<div className="ant-row">
      <div className="ant-card gx-card-widget gx-card-full gx-py-4 gx-px-2 gx-bg-orange ant-card-bordered">
        <div className="ant-card-body">
          <div className="gx-flex-row gx-justify-content-center gx-mb-3 gx-mb-sm-4">
            <span className="gx-size-80 gx-border gx-border-geekblue gx-text-geekblue gx-flex-row gx-justify-content-center gx-align-items-center gx-rounded-circle">
              <i className="icon icon-orders gx-fs-xlxl"></i>
            </span>
          </div>
          <div className="gx-text-center">
            <h2 className="gx-fs-xxxl gx-font-weight-medium gx-text-geekblue">2,380</h2>
            <p className="gx-mb-0 gx-mb-sm-3 gx-text-geekblue">Orders this year</p>
          </div>
        </div>
      </div>

      <Widget styleName="gx-bg-dark-primary">
        <div className="gx-flex-row gx-justify-content-center gx-mb-3 gx-mb-md-4">
          <i className={`icon icon-refer gx-fs-xlxl gx-text-white`}/>
        </div>
        <div className="gx-text-center">
          <h2 className="h3 gx-mb-3 gx-text-white">Reffer and Get Reward</h2>
          <p className="gx-text-white gx-mb-3">Reffer us to your friends and
            earn bonus when they join.</p>
          <Button size="large" className="gx-btn-secondary gx-mt-md-5 gx-mb-1">Invite Friends</Button>
        </div>
      </Widget>
      </div>

      
    </div>
  );
};

export default SamplePage;
