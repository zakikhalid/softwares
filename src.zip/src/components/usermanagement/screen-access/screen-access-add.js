import React, { useState } from 'react';
import {
  Form,
  Input,
  Button,
  Radio,
  Select,
  Cascader,
  DatePicker,
  InputNumber,
  TreeSelect,
  Switch,
  Breadcrumb,
  Checkbox,
} from 'antd';


const FormSizeDemo = () => {

    const formItemLayout = {
        labelCol: {
        xs: { span: 24 },
        sm: { span: 5 },
        },
        wrapperCol: {
        xs: { span: 24 },
        sm: { span: 10 },
        },
    };
    
    const tailFormItemLayout = {
        wrapperCol: {
        xs: {
            span: 24,
            offset: 0,
        },
        sm: {
            span: 5,
            offset: 10,
        },
        },
    };

    const options = [
        { label: 'CIMB Malaysia', value: 'cimbmy' },
        { label: 'CIMB Singapore', value: 'cimbsg' },
        { label: 'IT Security', value: 'itsec' },
    ];

    const prefixSelector = (
        <Form.Item name="prefix" noStyle>
          <Select style={{ width: 70 }}>
            <Select.Option value="+60">+60</Select.Option>
            <Select.Option value="+61">+61</Select.Option>
            <Select.Option value="+62">+62</Select.Option>
            <Select.Option value="+65">+65</Select.Option>
          </Select>
        </Form.Item>
      );

  return (
    <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>IT Security</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/userMaintenance">User Maintenance</a></Breadcrumb.Item>
            <Breadcrumb.Item>Add New</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>User Maintenance - Add New</h1>
        <p><br/></p>

        <Form
            {...formItemLayout}
            layout="horizontal"
            initialValues={{
                size: 'large',
                dept: ['GT', 'BE'],
                prefix: '+60',
                country: 'my',
            }}
            size='large'
        >
            <Form.Item 
                label="LAN ID"
                name="lanid"
                rules={[{ required: true, message: 'Please input user LAN ID!' }]}
            >
                <Input />
            </Form.Item>
            <Form.Item label="Staff ID"><Input id="staffid" /></Form.Item>
            <Form.Item label="First Name"><Input id="firstname" /></Form.Item>
            <Form.Item label="Last Name / Surname"><Input id="lastname" /></Form.Item>  
            <Form.Item label="Email"><Input id="email" /></Form.Item>    
            <Form.Item label="Mobile Naumber">
                <Input addonBefore={prefixSelector} style={{ width: '100%' }} />
            </Form.Item>      
            <Form.Item label="Department / Unit" name="dept">
            <Cascader
                options={[
                {
                    value: 'GT',
                    label: 'Group Technology',
                    children: [
                    {
                        value: 'BE',
                        label: 'Business Enabler',
                    },
                    ],
                },
                ]}
            />
            </Form.Item>
            <Form.Item label="Country" name="country">
                <Select>
                    <Select.Option value="ch">Cambodia</Select.Option>
                    <Select.Option value="my">Malaysia</Select.Option>
                    <Select.Option value="ph">Philippine</Select.Option>
                    <Select.Option value="sg">Singapore</Select.Option>
                    <Select.Option value="th">Thailand</Select.Option>                    
                    <Select.Option value="vn">Vietname</Select.Option>
                </Select>
            </Form.Item>
            <Form.Item label="Roles">                
                <Checkbox.Group options={options} />
            </Form.Item>
            <Form.Item label="Status"> 
                <Radio.Group>
                    <Radio value={1}>Active</Radio>
                    <Radio value={2}>Inactive</Radio>
                </Radio.Group>
            </Form.Item>
            <Form.Item {...tailFormItemLayout}>
                <Button type="primary" htmlType="submit">
                Register
                </Button>
            </Form.Item>
         </Form>
    </>
  );
};

export default FormSizeDemo;