import React, { Fragment, useState, useEffect } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputField, inputPasswordField, SelectField, SwitchField, inputNumberField, SelectMenuField } from "../../../containers/Inputs";
import {Button,InputNumber,Breadcrumb} from "antd";
import {useParams} from "react-router-dom";
import MenuService  from "../../.././services/usermanagement/menu-service";

const EditMenuForm = () => {
const params = useParams();

const defaultValues = {
    parentId: 1,
    menuName:"",
    menuLink:"",
    menuOrder: 1
}
const [isLoading, setIsLoading] = useState(false);
const [isError, setIsError] = useState(false);
const [menuList, setMenuList] = useState([{menuId:'', menuName:""}]);
const { handleSubmit, control, errors, reset, setValue } = useForm({defaultValues});
const [selectedMenu, setSeletedMenu] = useState({menuId:'', parentId:'', menuName:'', menuLink:'',menuOrder:''});
    useEffect(() => {
        //const menuId = params.menuId;
        console.log(" menuId is "+params.menuId)
        setIsLoading(true)
        MenuService.getMenuList().then(
            (response) => {            
                console.log(response.data)
                setMenuList(response.data)
                getMenuData(params.menuId)
                //setIsLoading(false)
            },(error) => {
                console.log(error)
                setIsError(false)
                setIsLoading(false)
                //alert(error.response.data);
            });
        
    }, [reset]);
    const getMenuData = (menuId) => {
        setIsLoading(true)
        MenuService.getMenuByMenuId(menuId).then(
            (response) => {            
                console.log(response.data)
                setSeletedMenu(response.data);
                //reset(response.data);
                reset({
                    parentId: response.data.parentId,
                    menuName: response.data.menuName,
                    menuLink: response.data.menuLink,
                    menuOrder: response.data.menuOrder,
                });
                setIsLoading(false);
            },(error) => {
              console.log(error);
              setIsError(false)
              setIsLoading(false)
                //alert(error.response.data);
            });
    }

    const onSubmit = (data) => {
        console.log("EditMenuForm ",data);
        MenuService.updatemenu(params.menuId,data).then(
            (response) => {            
                console.log(response.data)
            },(error) => {
              console.log(error)
            });
        setTimeout(() => reset(getMenuData(params.menuId)), 1000);
    }

    return (
         <Fragment>
            <>
            {/* <div>Hello{selectedMenu.menuName}</div> */}
        {
         isLoading ? <div>Loading... </div> : 
         isError ? <div>Error Occured... </div> :
        <div>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>User Management</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menuMaintenance">Menu Maintenance</a></Breadcrumb.Item>
            <Breadcrumb.Item>Edit Menu</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance - Edit Menu</h1>
        <p><br/></p> 
             <form onSubmit={handleSubmit(onSubmit)}>
            
                <div className='input-group'>
                    <label className='label'>Parent Menu </label>
                    <Controller as={SelectMenuField(menuList[0].menuName,menuList)} name='parentId' control={control} rules={{required:true}}/>
                    {errors.parentId && (<span className='error'>Parent Menu is required</span>)}                
                </div>
                <div className='input-group'>
                    <label className='label'>Menu Title   </label>
                    <Controller as={inputField("Menu Name")} name='menuName' control={control}  rules={{ required: true }} />
                    {errors.menuName && (<span className='error'>Menu Title is required</span>)}
                </div>
                <div className='input-group'>
                    <label className='label'>Menu Link  </label>
                    <Controller as={inputField("Menu Link")} name='menuLink' control={control} rules={{ required: true }} />
                    {errors.menuLink && (<span className='error'>Menu Link is required</span>)}
                </div>
               <div className='input-group'>
                    <label className='label'>Order Number  </label>
                    <Controller as={inputNumberField("Menu Order")} name='menuOrder' control={control} rules={{ required: true }} />
                    {errors.menuOrder && (<span className='error'>Menu Order is required</span>)}
                </div>

                <Button type='danger'  htmlType='submit'>Update Menu</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button type='danger'  htmlType='button' onClick={() => {
                    reset(getMenuData(params.menuId));
                }}>Reset</Button>                

            </form>
            </div>  
    } 
    </>
      </Fragment>
    );
};

export default EditMenuForm
