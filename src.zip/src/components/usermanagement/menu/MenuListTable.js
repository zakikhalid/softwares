import React, { useState, useEffect  } from 'react';
import { Table, Switch, Space, Breadcrumb, Button, Popconfirm, Divider } from 'antd';
import { EditOutlined, DeleteOutlined } from '@ant-design/icons';
//import ContainerHeader from 'ContainerHeader/index';
import ContainerHeader from '../../ContainerHeader/index';
import { Link } from 'react-router-dom';
import MenuService  from "../../.././services/usermanagement/menu-service";

const MenuListTable = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);
  const [menuList, setMenuList] = useState([]);
  const [pagination, setPagination] = useState({});
    useEffect(() => {
      setIsLoading(true)
    MenuService.getMenuList().then(
      (response) => {            
          console.log(response.data)
          setMenuList(response.data);
          setIsLoading(false)
      },(error) => {
        console.log(error)
        setIsError(false)
        setIsLoading(false)
          //alert(error.response.data);
      });
    }, []);

  const deleteConfirm = async (record,message) =>{
        console.log("MenuId "+record.menuId+" message "+message);
        setIsLoading(true)  
        MenuService.deleteMenuByMenuId(record.menuId).then(
          (response) => {            
              console.log(response.data)
          },(error) => {
            console.log(error)
          });

        MenuService.getMenuList().then(
            (response) => {            
                console.log(response.data)
                setMenuList(response.data);
                setIsLoading(false)
            },(error) => {
              console.log(error)
              setIsError(false)
              setIsLoading(false)
                //alert(error.response.data);
            });
  }
  const columns = [
    {
      title: "Title",
      dataIndex: "menuName",
        key: 'menuName',
         sorter: (a, b) => (a.menuName > b.menuName ? 1 : -1),
        filters: [
        { text: "Report Suite", value: "Report Suite" },
        { text: "Permissions", value: "Permissions" }
      ],
      render: (text: string) => <a href="/menuMaintenanceEdit">{text}</a>
    },
    {
      title: "Link",
      dataIndex: "menuLink",
      sorter: (a, b) => (a.menuLink > b.menuLink ? 1 : -1),
      key: 'menuLink',
      //render: (name) => `${name.first} ${name.last}`,
      width: "20%"
    },
    {
      title: "Order",
      dataIndex: "menuOrder",
            key: 'menuOrder',
      sorter: (a, b) => (a.menuOrder > b.menuOrder ? 1 : -1),
      width: "20%"
    },    
    {
      title: "Action",
      //dataIndex: "menuId",
      width: "20%",
      render: (text, record) => (
            <div>
            <Link to={`/menu-edit/${record.menuId}`}>           
             <EditOutlined />
               </Link>
              <Divider type="vertical" />
              <Popconfirm
                title="are you sure?"
                 onConfirm={() => deleteConfirm(record, 'success')}
                okText="Ok"
                cancelText="Cancel"
                placement="topRight">
                <a href="#"><DeleteOutlined />
                </a>
              </Popconfirm>
              
            </div>
          ),
    }
  ];
 /** const handleTableChange: HandleTableChange = (
    pagination,
    filters,
    sorter
  ) => {
    setPagination(pagination);
     customFetch({
      results: pagination.pageSize,
      page: pagination.current,
      sortField: sorter.field,
      sortOrder: sorter.order,
      ...filters
    });
  };*/


  return (
    <>
       {
         isLoading ? <div>Loading... </div> : 
         isError ? <div>Error Occured... </div> :
        <div><Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>User Management</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menuMaintenance">Menu Maintenance</a></Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance</h1>
        <ContainerHeader />
        <p align="right"><Button type="danger" href="/menu-add">Add Menu</Button><br/></p>
        
      <Table
        columns={columns}
        dataSource={menuList}
        loading={isLoading}
        //onChange={handleTableChange}
        pagination={pagination}
        rowKey="menuId"
      /></div>

      
       }    
    </>
  );
}

export default MenuListTable;