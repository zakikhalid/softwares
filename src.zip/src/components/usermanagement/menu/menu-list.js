import React, { useState, useEffect  } from 'react';
import { Table, Switch, Space, Breadcrumb, Button } from 'antd';
//import ContainerHeader from 'ContainerHeader/index';
import ContainerHeader from '../../ContainerHeader/index';





function TreeData() {
  const [isLoading, setIsLoading] = useState(false);
  const [userList, setUserList] = useState([{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'},{key:1,email:'test@gmail.com',name:{first:'krishna',last:'Ta'},gender:'male'}]);
  const [pagination, setPagination] = useState({});

  /****const customFetch = async (params = {}) => {
    console.log("params:", params);
    setIsLoading(true);
      const response = await reqwest({
      url: "https://randomuser.me/api",
      method: "get",
      data: {
        results: 10
      },
      type: "json"
    });
    console.log("response.results", "test");
    setUserList("");
    setIsLoading(false);
  };

  useEffect(() => {
    customFetch({});
  }, []);***/

  const columns = [
    {
      title: "Email",
      dataIndex: "email"
    },
    {
      title: "Name",
      dataIndex: "name",
      sorter: (a, b) => (a.name.first > b.name.first ? 1 : -1),
      render: (name) => `${name.first} ${name.last}`,
      width: "20%"
    },
    {
      title: "Gender",
      dataIndex: "gender",
      filters: [
        { text: "Male", value: "male" },
        { text: "Female", value: "female" }
      ],
      width: "20%"
    }
  ];
    const handleTableChange: HandleTableChange = (
    pagination,
    filters,
    sorter
  ) => {
    setPagination(pagination);
 /****    customFetch({
      results: pagination.pageSize,
      page: pagination.current,
      sortField: sorter.field,
      sortOrder: sorter.order,
      ...filters
    });*/
  };


  return (
    <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>IT Security</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menuMaintenance">Menu Maintenance</a></Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance</h1>
        <ContainerHeader />
        <p align="right"><Button type="danger" href="/menuMaintenanceAdd">Add New</Button><br/></p>
        
      <Table
        columns={columns}
        dataSource={userList}
        loading={isLoading}
        onChange={handleTableChange}
        pagination={pagination}
        rowKey="email"
      />

      <Button type="danger" href="/menuMaintenanceAdd">Add New</Button>
    </>
  );
}

export default TreeData;