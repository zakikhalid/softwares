import React, { Fragment, useState, useEffect } from 'react';
import { useForm, Controller } from "react-hook-form";
import { inputField, inputPasswordField, SelectField, SwitchField, inputNumberField, SelectMenuField } from "../../../containers/Inputs";
import {Button,InputNumber,Breadcrumb} from "antd";
import {useParams} from "react-router-dom";
const EditMenuForm = () => {
const { editMenuId } = useParams();
const { handleSubmit, control, errors, reset } = useForm();
const menus = [{menuId:1, parentId:0,menuName:"Report Suite",menuLink:"",menuOrder:1}, 
    {menuId:2, parentId:0,menuName:"Permissions",menuLink:"",menuOrder:2}, 
    {menuId:3, parentId:0,menuName:"Product Management",menuLink:"",menuOrder:3}];
//const [ menu, setMenu ] = useState(props.currentMenu)
//console.log(" menu is "+props);
  useEffect(() => {
        const menuId = { editMenuId };
        console.log(" menuId is "+menuId)
        // eslint-disable-next-line
    }, []);

  // You can tell React to skip applying an effect if certain values haven’t changed between re-renders. [ props ]
    const onSubmit = (data) => {
        console.log("EditMenuForm ",data);
        setTimeout(() => reset({
            parentId:1,
			menuName:'',
			menuLink:'',
			menuOrder: 1,
		}), 1000);
    }
  const handleInputChange = event => {
    const { name, value } = event.target

    //setMenu({ ...menu, [name]: value })
  }
    return (
         <Fragment>
            <>
        <Breadcrumb>
            <Breadcrumb.Item>Home</Breadcrumb.Item>
            <Breadcrumb.Item>User Management</Breadcrumb.Item>
            <Breadcrumb.Item><a href="/menuMaintenance">Menu Maintenance</a></Breadcrumb.Item>
            <Breadcrumb.Item>Edit Menu</Breadcrumb.Item>
        </Breadcrumb>
        <p><br/></p>
        <h1>Menu Maintenance - Edit Menu</h1>
        <p><br/></p> 
            <form onSubmit={handleSubmit(onSubmit)}>
            
                <div className='input-group'>
                    <label className='label'>Parent Menu </label>
                    <Controller as={SelectMenuField(menus[0].menuName,menus)} name='parentId' control={control} defaultValue={''} rules={{required:true}}/>
                    {errors.parentId && (<span className='error'>Parent Menu is required</span>)}                
                </div>
                <div className='input-group'>
                    <label className='label'>Menu Title   </label>
                    <Controller as={inputField("Menu Name")} name='menuName' control={control} defaultValue={''} rules={{ required: true }} />
                    {errors.menuName && (<span className='error'>Menu Title is required</span>)}
                </div>
                <div className='input-group'>
                    <label className='label'>Menu Link  </label>
                    <Controller as={inputField("Menu Link")} name='menuLink' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.menuLink && (<span className='error'>Menu Link is required</span>)}
                </div>
               <div className='input-group'>
                    <label className='label'>Order Number  </label>
                    <Controller as={inputNumberField("Menu Order")} name='menuOrder' control={control} defaultValue='' rules={{ required: true }} />
                    {errors.menuOrder && (<span className='error'>Menu Order is required</span>)}
                </div>

                <Button type='danger'  htmlType='submit'>Add Menu</Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <Button type='danger'  htmlType='button' onClick={() => {
                    reset({
                        parentId:1,
			            menuName:'',
			            menuLink:'',
			            menuOrder: 1,
                    });
                }}>Reset</Button>                

            </form>
    </>
      </Fragment>
    )
}

export default EditMenuForm
