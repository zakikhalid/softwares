package com.bcb.eform.portal.auth.payload;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
public class MessageJwtResponse {
	private String message;

}
