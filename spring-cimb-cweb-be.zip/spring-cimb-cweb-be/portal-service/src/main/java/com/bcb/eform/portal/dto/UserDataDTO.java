package com.bcb.eform.portal.dto;

import java.time.LocalDateTime;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;



@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class UserDataDTO {
	
	private long userId;	
	private String lanId;
	private String userFirstName;
	private String userLastName;
	private String userEmail;
	private String userMobileNumber;
	private String departmentUnit;
	private String staffId;
	private String country;
	private String domain;
	private String apiRole;
	private String userStatus;
	private byte[] userAvatar; 
	private String createdBy;
	private LocalDateTime createdDateTime;
	private String modifiedBy;
	private LocalDateTime modifiedDateTime;
	private UserMenuDataDTO menu;


}
