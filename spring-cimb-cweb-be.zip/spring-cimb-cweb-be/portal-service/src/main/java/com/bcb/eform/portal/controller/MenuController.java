/**
 * 
 */
package com.bcb.eform.portal.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bcb.eform.portal.dto.MenuDTO;
import com.bcb.eform.portal.dto.MessageResponseDTO;
import com.bcb.eform.portal.model.Menu;
import com.bcb.eform.portal.service.MenuService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Order;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@RestController
@RequestMapping("/menu")
@PreAuthorize("hasRole('ADMIN')")
public class MenuController {

	
	  @Autowired
	  private MenuService menuService;

	  private Sort.Direction getSortDirection(String direction) {
	    if (direction.equals("asc")) {
	      return Sort.Direction.ASC;
	    } else if (direction.equals("desc")) {
	      return Sort.Direction.DESC;
	    }

	    return Sort.Direction.ASC;
	  }

	  @GetMapping("/sorted")
	  public ResponseEntity<List<Menu>> getAllMenus(@RequestParam(defaultValue = "id,desc") String[] sort) {

	    try {
	      List<Order> orders = new ArrayList<Order>();

	      if (sort[0].contains(",")) {
	        // will sort more than 2 fields
	        // sortOrder="field, direction"
	        for (String sortOrder : sort) {
	          String[] _sort = sortOrder.split(",");
	          orders.add(new Order(getSortDirection(_sort[1]), _sort[0]));
	        }
	      } else {
	        // sort=[field, direction]
	        orders.add(new Order(getSortDirection(sort[1]), sort[0]));
	      }

	      List<Menu> menus = menuService.findAll(Sort.by(orders));

	      if (menus.isEmpty()) {
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	      }

	      return new ResponseEntity<>(menus, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }

	  @GetMapping("/menuName")
	  public ResponseEntity<Map<String, Object>> getAllMenusByMenuNamePage(
	      @RequestParam(required = false) String menuName,
	      @RequestParam(defaultValue = "0") int page,
	      @RequestParam(defaultValue = "3") int size,
	      @RequestParam(defaultValue = "id,desc") String[] sort) {

	    try {
	      List<Order> orders = new ArrayList<Order>();

	      if (sort[0].contains(",")) {
	        // will sort more than 2 fields
	        // sortOrder="field, direction"
	        for (String sortOrder : sort) {
	          String[] _sort = sortOrder.split(",");
	          orders.add(new Order(getSortDirection(_sort[1]), _sort[0]));
	        }
	      } else {
	        // sort=[field, direction]
	        orders.add(new Order(getSortDirection(sort[1]), sort[0]));
	      }

	      List<Menu> menusList = new ArrayList<Menu>();
	      Pageable pagingSort = PageRequest.of(page, size, Sort.by(orders));

	      Page<Menu> pageTuts;
	      if (menuName == null)
	        pageTuts = menuService.findAll(pagingSort);
	      else
	        pageTuts = menuService.findByMenuName(menuName, pagingSort);

	      menusList = pageTuts.getContent();

	      Map<String, Object> response = new HashMap<>();
	      response.put("menus", menusList);
	      response.put("currentPage", pageTuts.getNumber());
	      response.put("totalItems", pageTuts.getTotalElements());
	      response.put("totalPages", pageTuts.getTotalPages());

	      return new ResponseEntity<>(response, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }

	  @GetMapping("/menuLink")
	  public ResponseEntity<Map<String, Object>> findByMenuLink(
		  @RequestParam(required = false) String menuLink,
	      @RequestParam(defaultValue = "0") int page,
	      @RequestParam(defaultValue = "3") int size) {
	    
	    try {
	      List<Menu> menusList = new ArrayList<Menu>();
	      Pageable paging = PageRequest.of(page, size);

	      Page<Menu> pageTuts = menuService.findByMenuLink(menuLink, paging);
	      menusList = pageTuts.getContent();

	      Map<String, Object> response = new HashMap<>();
	      response.put("menus", menusList);
	      response.put("currentPage", pageTuts.getNumber());
	      response.put("totalItems", pageTuts.getTotalElements());
	      response.put("totalPages", pageTuts.getTotalPages());

	      return new ResponseEntity<>(response, HttpStatus.OK);
	    } catch (Exception e) {
	      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	    }
	  }

	  @GetMapping("/")
	  public List<MenuDTO> getAllMenus() {
		  List<Menu> menusList = menuService.getAllMenus();
		  List<MenuDTO> menuDTOList = getMenuDTOList(menusList);
		return menuDTOList;
	  }

	  public List<MenuDTO> getMenuDTOList(List<Menu> menusList) {
		  List<MenuDTO> menuDTOList = new ArrayList<MenuDTO>();
		  for(Menu menu:menusList) {
			  menuDTOList.add(getMenuDTO(menu, false, false, false, ""));
		  }
		return menuDTOList;
	}

	@GetMapping("/menuId/{menuId}")
	  public ResponseEntity<MenuDTO> getMenuByMenuId(@PathVariable long menuId) {
	      Optional<Menu> menuData = menuService.findByMenuId(menuId);
		  MenuDTO menuDTO = new MenuDTO(); 
		  try {
		      if (menuData.isPresent()) {
			    menuDTO = getMenuDTO(menuData.get(), false, false, false, "Menu Record Found!");
				nullifyUnusedMenuDataObjects(menuData);
			    return ResponseEntity.ok(menuDTO);
		      } else {
		    	menuDTO = getMenuDTO(menuData.get(), false, false, false, "Menu Record Not Found!");
				nullifyUnusedMenuDataObjects(menuData);
		    	return ResponseEntity.ok(menuDTO);
		      }
		  } catch (Exception exception) {
			  menuDTO = getMenuDTO(menuData.get(), true, false, false, "Retrieve Menu Id Exception!"+exception.getMessage());
			  nullifyUnusedMenuDataObjects(menuData);
			  return ResponseEntity.ok(menuDTO);
		  }

	  }

	  @PostMapping("/createMenu")
	  public ResponseEntity<MenuDTO> createMenu(@RequestBody Menu menu) {
		  MenuDTO menuDTO = new MenuDTO(); 
	    try {
	      menu.setCreatedBy("mycaps02");
	      menu.setCreatedDateTime(LocalDateTime.now());
	      Menu _menu = menuService.save(menu);
	      menuDTO = getMenuDTO(_menu, false, false, false, "Menu Created Successfully!");
	      return ResponseEntity.ok(menuDTO);
	    } catch (Exception exception) {	    
		  menuDTO = getMenuDTO(menu, true, false, false, "Menu Creation Exception!"+exception.getMessage());
		  return ResponseEntity.ok(menuDTO);	    
	    }
	  }

	  @PutMapping("/menuId/{menuId}")
	  public ResponseEntity<MenuDTO> updateMenu(@PathVariable long menuId, @RequestBody Menu menu) {
	    Optional<Menu> menuData = menuService.findByMenuId(menuId);
		  MenuDTO menuDTO = new MenuDTO(); 
		  try {
			    if (menuData.isPresent()) {
			    	Menu _menu = menuData.get();
			    	_menu.setParentId(menu.getParentId());
			    	_menu.setMenuName(menu.getMenuName());
			    	_menu.setMenuLink(menu.getMenuLink());	    	
			    	_menu.setMenuOrder(menu.getMenuOrder());
			    	_menu.setModifiedBy("mycaps02");
			    	_menu.setModifiedDateTime(LocalDateTime.now());;
				      Menu updatedMenu = menuService.save(_menu);
				      menuDTO = getMenuDTO(updatedMenu, false, false, false, "Menu Updated Successfully!");
				      nullifyUnusedMenuDataObjects(menuData);
				      return ResponseEntity.ok(menuDTO);			      
			    } else {
			    	  menuDTO = getMenuDTO(menu, false, false, false, "Menu Record Not Found!");
			    	  nullifyUnusedMenuDataObjects(menuData);
			    	  return ResponseEntity.ok(menuDTO);
			    }
		  } catch (Exception exception) {
			  menuDTO = getMenuDTO(menu, true, false, false, "Menu Updation Exception!"+exception.getMessage());
			  nullifyUnusedMenuDataObjects(menuData);
			  return ResponseEntity.ok(menuDTO);
		  }
	  }

	  @DeleteMapping("/{menuId}")
	  public ResponseEntity<MenuDTO> deleteMenu(@PathVariable long menuId) {
		  MenuDTO menuDTO = new MenuDTO();
		  Optional<Menu> menuData = menuService.findByMenuId(menuId);
	    try {
	      menuService.deleteMenuById(menuId);
		  menuDTO = getMenuDTO(menuData.get(), false, false, false, "Menu Deleted Successfully!");
	      nullifyUnusedMenuDataObjects(menuData);
		  return ResponseEntity.ok(menuDTO);
	    } catch (Exception exception) {
		  menuDTO = getMenuDTO(menuData.get(), true, false, false, "Menu Deletion Exception!"+exception.getMessage());
	      nullifyUnusedMenuDataObjects(menuData);
		  return ResponseEntity.ok(menuDTO);
	    }
	  }

	  @DeleteMapping("/deleteAllMenus")
	  public ResponseEntity<MessageResponseDTO> deleteAllMenus() {
	    try {
	      menuService.deleteAll();
		  return ResponseEntity.ok(MessageResponseDTO.builder().message("Menus Deleted Successfully!").build());
	    } catch (Exception exception) {
		  return ResponseEntity.ok(MessageResponseDTO.builder().message("Menus Deletion Exception!"+exception.getMessage()).build());
	      
	    }

	  }
	  
	  public MenuDTO getMenuDTO(Menu menu, boolean isError, boolean isUpdated, boolean isDeleted, String message) {
		  MenuDTO menuDTO = MenuDTO.builder().menuId(menu.getMenuId()).parentId(menu.getParentId())
                                             .menuName(menu.getMenuName()).menuLink(menu.getMenuLink())
                                             .menuOrder(menu.getMenuOrder()).createdBy(menu.getCreatedBy())
                                             .createdDateTime(menu.getCreatedDateTime()).modifiedBy(menu.getModifiedBy())
                                             .modifiedDateTime(menu.getModifiedDateTime()).isError(isError)
		    		                         .isUpdated(isUpdated).isDeleted(isDeleted).message(message).build();
		  return menuDTO;
	  }
	   public void nullifyUnusedMenuDataObjects(Optional<Menu> menuData) {
		   menuData =null;
			
		}
	   public void nullifyUnusedMenuObjects(Menu menu) {
		   menu =null;
			
		}

}
