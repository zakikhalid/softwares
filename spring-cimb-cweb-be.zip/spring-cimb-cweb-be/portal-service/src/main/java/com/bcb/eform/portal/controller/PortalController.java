package com.bcb.eform.portal.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bcb.eform.portal.service.UserService;
import com.bcb.eform.portal.auth.payload.UserResponse;
import com.bcb.eform.portal.auth.payload.UserSignInRequest;
import com.bcb.eform.portal.dto.MenuConstruction;
import com.bcb.eform.portal.dto.MenuDataDTO;
import com.bcb.eform.portal.dto.UserMenuDataDTO;
import com.bcb.eform.portal.model.Menu;
import com.bcb.eform.portal.model.Movie;
import com.bcb.eform.portal.service.MenuService;
import com.bcb.eform.portal.service.PortalService;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.TreeSet;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/portal")
public class PortalController {

    @Autowired
    PortalService portalService;
    @Autowired
    private UserService userService;
    
	@Autowired
	private MenuService menuService;
	
	@Autowired
	private MenuConstruction menuConstruction;

    @GetMapping("")
    public ResponseEntity<List<Movie>> getAllMovies(){
        return ResponseEntity.ok(portalService.getAllMoviers());
    }

    @GetMapping("/year/{year}")
    public ResponseEntity<List<Movie>> getMovieByYear(@PathVariable String year){
        return ResponseEntity.ok(portalService.getMovieByYear(year));
    }

    @GetMapping("/danger")
    public ResponseEntity<List<Movie>> unstableMoviesEndpoint(){
        return ResponseEntity.ok(portalService.dangerMethod());
    }
    @PostMapping("/signin")
    public ResponseEntity<UserResponse> login(@RequestBody UserSignInRequest userSignInRequest){

    	  UserResponse userResponse = userService.signin(userSignInRequest.getUsername(), userSignInRequest.getPassword());
        return ResponseEntity.ok(userResponse);
    }
    @GetMapping("/menuString/{staffId}")
    @PreAuthorize("hasRole('ADMIN')")
    public String getUserMenuString(@PathVariable String staffId){
		System.out.println(" getUserMenusList Start staffId "+staffId);
		List<Menu> menuList = new ArrayList<Menu>();
		String userMenu = "";
		try {
		menuList = menuService.getAllMenusByStaffId(staffId);
		menuList = menuList.stream().collect(Collectors.toCollection(()->new TreeSet<>(Comparator.comparing(Menu::getMenuId)))).stream().collect(Collectors.toList());
		System.out.println(" getUserMenusList End menuList size "+menuList.size());
		List<MenuDataDTO> menuDataDTOList = new ArrayList<MenuDataDTO>();
		for(Menu menu: menuList) {
			menuDataDTOList.add(MenuDataDTO.builder().menuId(menu.getMenuId()).parentId(menu.getParentId()).menuName(menu.getMenuName()).menuLink(menu.getMenuLink()).menuOrder(menu.getMenuOrder()).build());			
		}
		userMenu = menuConstruction.getUserMenu(menuDataDTOList);
		}catch(Exception exception) {
			menuList = null;
			System.out.println(" getUserMenu Exception "+exception.getMessage());
		}
		menuList = null;
		return userMenu;
    }
    @GetMapping("/menu/{staffId}")
    public UserMenuDataDTO getUserMenu(@PathVariable String staffId){
		System.out.println(" getUserMenusList Start staffId "+staffId);
		List<Menu> menuList = new ArrayList<Menu>();
		UserMenuDataDTO userMenuDataDTO = new UserMenuDataDTO();
		try {
		menuList = menuService.getAllMenusByStaffId(staffId);
		menuList = menuList.stream().collect(Collectors.toCollection(()->new TreeSet<>(Comparator.comparing(Menu::getMenuId)))).stream().collect(Collectors.toList());
		System.out.println(" getUserMenusList End menuList size "+menuList.size());
		List<MenuDataDTO> menuDataDTOList = new ArrayList<MenuDataDTO>();
		for(Menu menu: menuList) {
			menuDataDTOList.add(MenuDataDTO.builder().menuId(menu.getMenuId()).parentId(menu.getParentId()).menuName(menu.getMenuName()).menuLink(menu.getMenuLink()).menuOrder(menu.getMenuOrder()).build());			
		}
		userMenuDataDTO = menuConstruction.getUserMenuDataDTO(menuDataDTOList);
		}catch(Exception exception) {
			menuList = null;
			System.out.println(" getUserMenu Exception "+exception.getMessage());
		}
		menuList = null;
		return userMenuDataDTO;
    }
}
