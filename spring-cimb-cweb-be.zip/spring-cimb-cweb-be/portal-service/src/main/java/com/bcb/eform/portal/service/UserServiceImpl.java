/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.Optional;

import javax.transaction.Transactional;

import com.bcb.eform.portal.model.User;

/**
 * @author Muralikrishna Tammisetty
 *
 */
public interface UserServiceImpl {
	
    public boolean existsByUserFirstName(String userFirstName);

    public User findByUserFirstName(String userFirstName);

    @Transactional
    public void deleteByUserFirstName(String userFirstName);
  
//	public Optional<User> findByUserName(String username);
	
	public Optional<User> findByUserEmail(String userEmail);

	public Boolean existsByUserEmail(String userEmail);

}
