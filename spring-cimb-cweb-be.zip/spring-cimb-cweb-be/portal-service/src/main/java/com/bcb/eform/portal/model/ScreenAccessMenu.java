/**
 * 
 */
package com.bcb.eform.portal.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Entity
@Table(name = "screen_access_menu")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ScreenAccessMenu {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private long Id;
	
	@Column(name = "screen_access_id")
	private long screenAccessId;
	
	@Column(name = "menu_id")
	private long menuId;
	
	@NotBlank
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date_time")
	private LocalDateTime createdDateTime;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_date_time")
	private LocalDateTime modifiedDateTime;
	
}
