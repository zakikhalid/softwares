package com.bcb.eform.portal.auth.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import org.springframework.security.crypto.password.PasswordEncoder;


import com.bcb.eform.portal.model.User;
import com.bcb.eform.portal.repository.UserRepository;

/**
 * @author Muralikrishna Tammisetty
 *
 */

@Service
public class MyUserDetails implements UserDetailsService {

  @Autowired
  private UserRepository userRepository;
  
//  @Autowired
//  private RoleAuthority roleAuthority;
  
  @Autowired
  private PasswordEncoder passwordEncoder;

  @Override
  public UserDetails loadUserByUsername(String userFirstName) throws UsernameNotFoundException {
    final User user = userRepository.findByUserFirstName(userFirstName);

    if (user == null) {
      throw new UsernameNotFoundException("User '" + userFirstName + "' not found");
    }
    //String role_authorities= roleAuthority.retrieveUserRoles().get((user.getRole()).toString());
/***    if(user.getRole() == 0) {
    	role_authorities = "ROLE_ADMIN";
    }else if(user.getRole() == 1) {      
    	role_authorities = "ROLE_CLIENT";
    }else {
    	role_authorities = "ROLE_CLIENT";
    }****/
    return org.springframework.security.core.userdetails.User//
        .withUsername(userFirstName)//passwordEncoder.encode(registerUser.getPassword())
        .password(passwordEncoder.encode("cweb123$"))
        //.password(user.getPassword())//
        //.authorities(role_authorities)//
        .authorities("ROLE_ADMIN")//
        .accountExpired(false)//
        .accountLocked(false)//
        .credentialsExpired(false)//
        .disabled(false)//
        .build(); 
  }

}
