/**
 * 
 */
package com.bcb.eform.portal.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bcb.eform.portal.model.ScreenAccessMenu;


/**
 * @author Muralikrishna Tammisetty
 *
 */
@Repository
public interface ScreenAccessMenuRepository extends JpaRepository<ScreenAccessMenu, Long> {

	public Optional<ScreenAccessMenu> findByMenuId(long menuId);
	public Optional<ScreenAccessMenu> findByScreenAccessId(long screenAccessId);

}
