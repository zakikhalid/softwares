/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bcb.eform.portal.model.Menu;
import com.bcb.eform.portal.repository.MenuRepository;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Service
public class MenuService implements MenuServiceImpl{
	
	@Autowired
	private MenuRepository menuRepository;

	@Override
	public List<Menu> getAllMenus() {		
		return menuRepository.findAll();
	}

	@Override
	public void saveMenu(Menu menu) {
		this.menuRepository.save(menu);		
	}

	@Override
	public Menu findByMenuWithMenuId(long menuId) {
		Optional<Menu> optional = menuRepository.findByMenuId(menuId);
		Menu menu = null;
		if (optional.isPresent()) {
			menu = optional.get();
		} else {
			throw new RuntimeException(" Menu not found for menuId :: " + menuId);
		}

		return menu;
	}

	@Override
	public void deleteMenuById(long menuId) {
		this.menuRepository.deleteById(menuId);
		
	}

	@Override
	public Optional<Menu> findByMenuName(String menuName) {
		return menuRepository.findByMenuName(menuName);
	}

	@Override
	public Optional<Menu> findByMenuId(long menuId) {
		return menuRepository.findByMenuId(menuId);
	}

	@Override
	public List<Menu> getAllMenusByStaffId(String staffId) {		
		return menuRepository.getAllMenusByStaffId(staffId);
	}

	@Override
	public Page<Menu> findByMenuName(String menuName, Pageable pageable) {
		return menuRepository.findByMenuName(menuName, pageable);
	}

	@Override
	public Page<Menu> findByMenuLink(String menuLink, Pageable pageable) {
		return menuRepository.findByMenuLink(menuLink, pageable);
	}

	@Override
	public List<Menu> findByMenuName(String menuName, Sort sort) {
		return menuRepository.findByMenuName(menuName, sort);
	}

	public List<Menu> findAll(Sort by) {
		return menuRepository.findAll(by);
	}

	public Page<Menu> findAll(Pageable pagingSort) {
		return menuRepository.findAll(pagingSort);
	}

	public Optional<Menu> findById(long id) {
		return menuRepository.findById(id);
	}

	public Menu save(Menu _menu) {
		return menuRepository.save(_menu);
	}

	public void deleteById(long id) {
		menuRepository.deleteById(id);
	}

	public void deleteAll() {
		menuRepository.deleteAll();
	}

}
