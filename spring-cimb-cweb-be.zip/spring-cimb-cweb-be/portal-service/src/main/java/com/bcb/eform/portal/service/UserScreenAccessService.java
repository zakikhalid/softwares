/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcb.eform.portal.model.UserScreenAccess;
import com.bcb.eform.portal.repository.UserScreenAccessRepository;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Service
public class UserScreenAccessService implements UserScreenAccessServiceImpl {

	@Autowired
	private UserScreenAccessRepository userScreenAccessRepository;

	@Override
	public List<UserScreenAccess> getAllUserScreenAccess() {
		return userScreenAccessRepository.findAll();
	}

	@Override
	public void saveUserScreenAccess(UserScreenAccess userScreenAccess) {
		this.userScreenAccessRepository.save(userScreenAccess);

	}

	@Override
	public UserScreenAccess getUserScreenAccessId(long userScreenAccessId) {
		Optional<UserScreenAccess> optional = userScreenAccessRepository.findById(userScreenAccessId);
		UserScreenAccess userScreenAccess = null;
		if (optional.isPresent()) {
			userScreenAccess = optional.get();
		} else {
			throw new RuntimeException(" UserScreenAccess not found for userScreenAccessId :: " + userScreenAccessId);
		}

		return userScreenAccess;
	}

	@Override
	public void deleteUserScreenAccessById(long userScreenAccessId) {
		this.userScreenAccessRepository.deleteById(userScreenAccessId);

	}

	@Override
	public Optional<UserScreenAccess> findByUserId(String userId) {
		return userScreenAccessRepository.findByUserId(userId);
	}

	@Override
	public Optional<UserScreenAccess> findByScreenAccessId(long screenAccessId) {
		return userScreenAccessRepository.findByScreenAccessId(screenAccessId);
	}

}
