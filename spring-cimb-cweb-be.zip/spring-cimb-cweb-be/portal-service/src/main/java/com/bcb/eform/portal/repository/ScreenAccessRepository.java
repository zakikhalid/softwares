package com.bcb.eform.portal.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bcb.eform.portal.model.ScreenAccess;


/**
 * @author Muralikrishna Tammisetty
 *
 */
@Repository
public interface ScreenAccessRepository extends JpaRepository<ScreenAccess, Long> {
	public Optional<ScreenAccess> findByScreenAccessName(String screenAccessName);
	public Optional<ScreenAccess> findByScreenAccessId(long screenAccessId);
	
	public Page<ScreenAccess> findByScreenAccessName(String screenAccessName, Pageable pageable);

	public Page<ScreenAccess> findByScreenAccessDescription(String screenAccessDescription, Pageable pageable);
	  
	public List<ScreenAccess> findByScreenAccessName(String screenAccessName, Sort sort);
}
