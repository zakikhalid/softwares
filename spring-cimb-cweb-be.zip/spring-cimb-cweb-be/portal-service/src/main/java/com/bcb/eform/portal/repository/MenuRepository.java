/**
 * 
 */
package com.bcb.eform.portal.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.bcb.eform.portal.model.Menu;



/**
 * @author Muralikrishna Tammisetty
 *
 */
@Repository
public interface MenuRepository extends JpaRepository<Menu, Long> {
	public Optional<Menu> findByMenuName(String menuName);
	public Optional<Menu> findByMenuId(long menuId);
	//public Menu findByMenuId(long menuId);
	

    //@Query("select m from Menu m,RoleApps ra,APPS a where m.appsId = ra.appsId and ra.appsId = a.appsId and ra.roleId in (select roleId from UserRoles where userId in (select userId from User where userId like %?1))")
   // public List<Menu> getAllMenusByUserId(String userId);
	@Query("select m from Menu m,ScreenAccessMenu sam where m.menuId = sam.menuId and sam.screenAccessId in ( select screenAccessId from UserScreenAccess where userId in ( select userId from User where staffId like %?1))")
	public List<Menu> getAllMenusByStaffId(String staffId);
	
	public Page<Menu> findByMenuName(String menuName, Pageable pageable);

	public Page<Menu> findByMenuLink(String menuLink, Pageable pageable);
	  
	public List<Menu> findByMenuName(String menuName, Sort sort);
	  

}
