/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import com.bcb.eform.portal.model.ScreenAccessMenu;

/**
 * @author Muralikrishna Tammisetty
 *
 */
public interface ScreenAccessMenuServiceImpl {
	
	public List<ScreenAccessMenu> getAllScreenAccessMenu();
	public void saveScreenAccessMenu(ScreenAccessMenu screenAccessMenu);
	public ScreenAccessMenu getScreenAccessMenuId(long screenAccessMenuId);
	public void deleteScreenAccessMenuById(long screenAccessMenuId);
	
	public Optional<ScreenAccessMenu> findByMenuId(long menuId);
	public Optional<ScreenAccessMenu> findByScreenAccessId(long screenAccesId);

}
