/**
 * 
 */
package com.bcb.eform.portal.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class MenuDataDTO {

	private long menuId;//menuId
	private long parentId;//ParentId
	private String menuName;
	private String menuLink;
	private long menuOrder;
	
}
