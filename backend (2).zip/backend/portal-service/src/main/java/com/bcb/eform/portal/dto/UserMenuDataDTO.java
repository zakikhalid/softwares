/**
 * 
 */
package com.bcb.eform.portal.dto;

import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class UserMenuDataDTO{
	
	private List<MenuDataDTO> parentMenuList;
	private List<MenuDataDTO> childMenuList;
	private List<MenuDataDTO> subChildMenuList;
}
