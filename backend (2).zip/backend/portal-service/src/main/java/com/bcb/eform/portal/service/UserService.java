package com.bcb.eform.portal.service;


import java.util.List;
import java.util.Optional;

import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
//import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.AuthenticationException;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.bcb.eform.portal.exception.CustomException;
//import com.bcb.eform.auth.jwt.payload.MessageJwtResponse;
import com.bcb.eform.portal.auth.payload.RoleAuthority;
import com.bcb.eform.portal.auth.payload.UserResponse;
import com.bcb.eform.portal.auth.ldap.LdapAuth;
import com.bcb.eform.portal.auth.ldap.LdapUser;
import com.bcb.eform.portal.model.User;
import com.bcb.eform.portal.repository.UserRepository;
import com.bcb.eform.portal.auth.security.JwtTokenProvider;
import com.bcb.eform.portal.dto.UserDataDTO;

@Service
public class UserService implements UserServiceImpl{

  @Autowired
  private UserRepository userRepository;
  
  @Value("${cweb.ldap.server-ip-address}")
  private String ldapServerIPAdress;
  
  @Value("${cweb.ldap.server-port}")
  private String ldapServerPort;
  
  @Value("${cweb.ldap.server-domainname}")
  private String ldapServerUserDomainName;
  
  @Value("${cweb.ldap.server-searchbase-user-context}")
  private String ldapServerSerachBaseUserContext;
  
  @Value("${cweb.ldap.server-authentication}")
  private String ldapServerAuthentication;
  

  //@Autowired
  //private PasswordEncoder passwordEncoder;

  @Autowired
  private JwtTokenProvider jwtTokenProvider;

  @Autowired
  private AuthenticationManager authenticationManager;
  
  @Autowired
  private RoleAuthority roleAuthority;
  
  @Autowired
  private LdapAuth ldapAuth;

  public UserResponse signin(String username, String password) {
	  System.out.println(" User SignIn Start username "+username);
	  String token ="";
	  //User signInUser = new User();
	  UserResponse signInUserResponse = new UserResponse();
	  UserDataDTO userData = new UserDataDTO();

		boolean isLoginUserAuthenticated = false;
		  LdapUser ldapUser = null;
	      String employeeId = "";
	      String country="";
    try {
    	//isLoginUserAuthenticated = isLoginUserAuthenticated(username, password);
//      if(isLoginUserAuthenticated) {
//
//    	  ldapUser = retrieveLdapServerLoginUser(username, password, "sAMAccountName="+username, "employeeID");
//    	  employeeId = ldapUser.getUserId();
//    	  if ((employeeId == null) || (employeeId.trim().isEmpty())) {
//    		  ldapUser = retrieveLdapServerLoginUser(username, password, "sAMAccountName="+username, "co");
//    		  country = ldapUser.getCountryCode();
//    		  if ((country == null) || (country.trim().isEmpty())) {
//        		  ldapUser = retrieveLdapServerLoginUser(username, password, "sAMAccountName="+username, "postalCode");
//    		  }
//    	  }
//      }
      //System.out.println("LDAP User FullName is "+ldapUser.getFullName());
      authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, "cweb123$"));//Spring securirty check via provider through userdetailservice with loadbyusername() --> Principal Object

      User signInUser = search(username);
		token = jwtTokenProvider.createToken(username, roleAuthority.retrieveUserRolesList(signInUser));
		userData = UserDataDTO.builder().userId(signInUser.getUserId()).lanId(signInUser.getLanId()).userFirstName(signInUser.getUserFirstName()).userLastName(signInUser.getUserLastName())
	              .userEmail(signInUser.getUserEmail()).userMobileNumber(signInUser.getUserMobileNumber()).departmentUnit(signInUser.getDepartmentUnit()).staffId(signInUser.getStaffId())
	              .country(signInUser.getCountry()).domain(signInUser.getDomain()).apiRole(signInUser.getApiRole()).userStatus(signInUser.getUserStatus())
	              .userAvatar(signInUser.getUserAvatar()).build();
		
		signInUserResponse = UserResponse.builder().user(userData).accessToken(token).tokenType("Bearer").isError(false).message("User SignIn successfully!").build();
      //return signInUserJwtResponse;
    } catch (AuthenticationException e) {
      //throw new CustomException("Invalid username/password supplied", HttpStatus.UNPROCESSABLE_ENTITY);
    	nullifyUnusedObjects(token,userData,ldapUser,employeeId,country);
    	signInUserResponse = UserResponse.builder().isError(true).message("Invalid username/password supplied!").build();
    } catch (Exception exception) {
    	nullifyUnusedObjects(token,userData,ldapUser,employeeId,country);
    	signInUserResponse = UserResponse.builder().isError(true).message(ldapAuth.GetErrorDesription(exception.getMessage())).build();
    }
    nullifyUnusedObjects(token,userData,ldapUser,employeeId,country);

	  System.out.println(" User SignIn End signInUserResponse "+signInUserResponse);
	return signInUserResponse;
  }


public UserResponse signup(User registerUser) {
	  String token ="";
	  UserResponse userResponse = new UserResponse();
	  UserDataDTO userData = new UserDataDTO();
    if (!userRepository.existsByUserFirstName(registerUser.getUserFirstName())) {
    	//registerUser.setPassword(passwordEncoder.encode(registerUser.getPassword()));
      userRepository.save(registerUser);
	  token = jwtTokenProvider.createToken(registerUser.getUserFirstName(), roleAuthority.retrieveUserRolesList(registerUser));
      //return jwtTokenProvider.createToken(user.getUsername(), userRoles(user));
		userData = UserDataDTO.builder().userId(registerUser.getUserId()).lanId(registerUser.getLanId()).userFirstName(registerUser.getUserFirstName()).userLastName(registerUser.getUserLastName())
	              .userEmail(registerUser.getUserEmail()).userMobileNumber(registerUser.getUserMobileNumber()).departmentUnit(registerUser.getDepartmentUnit()).staffId(registerUser.getStaffId())
	              .country(registerUser.getCountry()).domain(registerUser.getDomain()).apiRole(registerUser.getApiRole()).userStatus(registerUser.getUserStatus())
	              .userAvatar(registerUser.getUserAvatar()).build();
	  userResponse = UserResponse.builder().user(userData).accessToken(token).tokenType("Bearer").isError(false).message("User registered successfully!!").build();
	  return userResponse;
    } else {
      //throw new CustomException("Username is already in use", HttpStatus.UNPROCESSABLE_ENTITY);
    	userResponse = UserResponse.builder().isError(true).message("Username is already in use").build();
    }
	return userResponse;
  }

  public void delete(String userFirstName) {
    userRepository.deleteByUserFirstName(userFirstName);
  }

  public User search(String userFirstName) {
    User user = userRepository.findByUserFirstName(userFirstName);
    if (user == null) {
      throw new CustomException("The user doesn't exist", HttpStatus.NOT_FOUND);
    }
    return user;
  }

  public User whoami(HttpServletRequest req) {
    return userRepository.findByUserFirstName(jwtTokenProvider.getUsername(jwtTokenProvider.resolveToken(req)));
  }

  public String refresh(String username) {
	  User user = search(username);
    return jwtTokenProvider.createToken(username, roleAuthority.retrieveUserRolesList(user));
  }
  
  public boolean isLoginUserAuthenticated(String loginUserId, String loginUserPassword) {
	  boolean isLoginUserAuthenticated = ldapAuth.isLoginUserAuthenticated(ldapServerIPAdress, ldapServerPort, loginUserId, loginUserPassword, ldapServerUserDomainName);
	return isLoginUserAuthenticated;
	  
  }
  public LdapUser retrieveLdapServerLoginUser(String loginUserId, String loginUserPassword, String ldapServerSerachFilter, String ldapServersearchAttribute) {
	  LdapUser ldapUser = null;
	  DirContext ldapServerSearchDirectoryContextConnection = retrieveDirectoryContextConnection(loginUserId, loginUserPassword);
	try {
        if (ldapServerSearchDirectoryContextConnection != null) {
			ldapUser = ldapAuth.retrieveLdapServerLoginUser(ldapServerSearchDirectoryContextConnection, ldapServerSerachBaseUserContext, ldapServerSerachFilter, ldapServersearchAttribute);
			ldapServerSearchDirectoryContextConnection.close();
        }
	} catch (NamingException name) {
		//e.printStackTrace();
		System.out.println(" retrieveLdapServerLoginUser Exception "+name.getMessage());
	}catch (Exception name) {
		//e.printStackTrace();
		System.out.println(" retrieveLdapServerLoginUser Exception "+name.getMessage());
	}
	return ldapUser;	  
  }
  public DirContext retrieveDirectoryContextConnection(String loginUserId, String loginUserPassword) {
		DirContext directoryContextConnection = ldapAuth.newConnection(ldapServerIPAdress, ldapServerPort, loginUserId, loginUserPassword, ldapServerAuthentication, ldapServerUserDomainName);
		return directoryContextConnection;
	}

   @Override
   public boolean existsByUserFirstName(String userFirstName) {
	   
		return userRepository.existsByUserFirstName(userFirstName);
	}
	
   @Override
   public User findByUserFirstName(String userFirstName) {
	   
	    User user = userRepository.findByUserFirstName(userFirstName);
		return user;
	}
	
   @Override
   public void deleteByUserFirstName(String userFirstName) {
	   
	    userRepository.deleteByUserFirstName(userFirstName);
	}
	

	
   @Override
   public Optional<User> findByUserEmail(String userEmail) {
		
		return userRepository.findByUserEmail(userEmail);
	}
	
   @Override
   public Boolean existsByUserEmail(String userEmail) {

		return userRepository.existsByUserEmail(userEmail);
    }

   public void nullifyUnusedObjects(String token, UserDataDTO userData, LdapUser ldapUser, String employeeId,
			String country) {
		 token =null;
		 userData = null;
	     ldapUser = null;
		 employeeId = null;
		 country= null;
		
	}


	public void deleteAll() {
		userRepository.deleteAll();
		
	}
	public void deleteById(long id) {
		userRepository.deleteById(id);
	}
	public User save(User _user) {
		return userRepository.save(_user);
	}
	public Optional<User> findById(long id) {
		return userRepository.findById(id);
	}
	public Page<User> findByUserLastName(String userLastName, Pageable paging) {
		return userRepository.findByUserLastName(userLastName, paging);
	}
	public Page<User> findByUserFirstName(String userFirstName, Pageable pagingSort) {
		return userRepository.findByUserLastName(userFirstName, pagingSort);
	}
	public List<User> findAll(Sort by) {
		return userRepository.findAll(by);
	}
	public Page<User> findAll(Pageable pagingSort) {
		return userRepository.findAll(pagingSort);
	}
	

}
