package com.bcb.eform.portal.auth.payload;

import com.bcb.eform.portal.dto.UserDataDTO;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Muralikrishna Tammisetty
 *
 */

@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class UserResponse {
	
	private UserDataDTO user;
	private String accessToken;
	private String tokenType;
	private boolean isError;
	private String message;

}

