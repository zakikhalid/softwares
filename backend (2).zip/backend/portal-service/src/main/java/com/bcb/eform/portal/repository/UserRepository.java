package com.bcb.eform.portal.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;

import com.bcb.eform.portal.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

    public boolean existsByUserFirstName(String userFirstName);

    public User findByUserFirstName(String userFirstName);

    @Transactional
    public void deleteByUserFirstName(String userFirstName);
  
//	public Optional<User> findByUserName(String username);
	
	public Optional<User> findByUserEmail(String userEmail);

	public Boolean existsByUserEmail(String userEmail);
	
	public Page<User> findByUserFirstName(String userFirstName, Pageable pageable);

	public Page<User> findByUserLastName(String userLastName, Pageable pageable);
	  
	public List<User> findByUserFirstName(String userFirstName, Sort sort);

}
