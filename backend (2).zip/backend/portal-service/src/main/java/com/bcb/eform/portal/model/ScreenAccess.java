package com.bcb.eform.portal.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.time.*;


/**
 * @author Muralikrishna Tammisetty
 *
 */
@Entity
@Table(name = "screen_access")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Builder
public class ScreenAccess {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "screen_access_id")
	private long screenAccessId;
	
	@NotBlank
	@Column(name = "screen_access_name")
	private String screenAccessName;
	
	@Column(name = "screen_access_description")
	private String screenAccessDescription;
	
	@NotBlank
	@Column(name = "created_by")
	private String createdBy;
	
	@Column(name = "created_date_time")
	private LocalDateTime createdDateTime;
	
	@Column(name = "modified_by")
	private String modifiedBy;
	
	@Column(name = "modified_date_time")
	private LocalDateTime modifiedDateTime;

}
