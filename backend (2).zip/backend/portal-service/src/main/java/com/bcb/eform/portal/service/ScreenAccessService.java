/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.bcb.eform.portal.model.ScreenAccess;
import com.bcb.eform.portal.repository.ScreenAccessRepository;

/**
 * @author Muralikrishna Tammisetty
 *
 */
@Service
public class ScreenAccessService implements ScreenAccessServiceImpl{

	@Autowired
	private ScreenAccessRepository screenAccessRepository;
	
	@Override
	public List<ScreenAccess> getAllScreenAccess() {
		return screenAccessRepository.findAll();
	}

	@Override
	public void saveScreenAccess(ScreenAccess screenAccess) {
		this.screenAccessRepository.save(screenAccess);
	}

	@Override
	public ScreenAccess getScreenAccessId(long id) {
		Optional<ScreenAccess> optional = screenAccessRepository.findById(id);
		ScreenAccess screenAccess = null;
		if (optional.isPresent()) {
			screenAccess = optional.get();
		} else {
			throw new RuntimeException(" ScreenAccess not found for id :: " + id);
		}

		return screenAccess;
	}

	@Override
	public void deleteScreenAccessById(long screenAccessId) {
		this.screenAccessRepository.deleteById(screenAccessId);
	}


	@Override
	public Optional<ScreenAccess> findByScreenAccessName(String screenAccessName) {
		return screenAccessRepository.findByScreenAccessName(screenAccessName);
	}

	@Override
	public Optional<ScreenAccess> findByScreenAccessId(long screenAccessId) {
		return screenAccessRepository.findByScreenAccessId(screenAccessId);
	}

	@Override
	public Page<ScreenAccess> findByScreenAccessName(String screenAccessName, Pageable pageable) {
		return screenAccessRepository.findByScreenAccessName(screenAccessName, pageable);
	}

	@Override
	public Page<ScreenAccess> findByScreenAccessDescription(String screenAccessDescription, Pageable pageable) {
		return screenAccessRepository.findByScreenAccessDescription(screenAccessDescription, pageable);
	}

	@Override
	public List<ScreenAccess> findByScreenAccessName(String screenAccessName, Sort sort) {
		return screenAccessRepository.findByScreenAccessName(screenAccessName, sort);
	}

	public void deleteAll() {
		screenAccessRepository.deleteAll();	
	}

	public void deleteById(long id) {
		screenAccessRepository.deleteById(id);		
	}

	public ScreenAccess save(ScreenAccess _screenAccess) {
		return screenAccessRepository.save(_screenAccess);
	}

	public Optional<ScreenAccess> findById(long id) {
		return screenAccessRepository.findById(id);
	}

	public Page<ScreenAccess> findAll(Pageable pagingSort) {
		return screenAccessRepository.findAll(pagingSort);
	}

	public List<ScreenAccess> findAll(Sort by) {
		return screenAccessRepository.findAll(by);
	}


}
