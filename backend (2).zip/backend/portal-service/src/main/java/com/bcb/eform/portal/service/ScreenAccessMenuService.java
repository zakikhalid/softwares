/**
 * 
 */
package com.bcb.eform.portal.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bcb.eform.portal.model.ScreenAccessMenu;
import com.bcb.eform.portal.repository.ScreenAccessMenuRepository;


/**
 * @author Muralikrishna Tammisetty
 *
 */
@Service
public class ScreenAccessMenuService implements ScreenAccessMenuServiceImpl{
	
	@Autowired
	private ScreenAccessMenuRepository screenAccessMenuRepository;

    @Override
	public List<ScreenAccessMenu> getAllScreenAccessMenu() {
		return screenAccessMenuRepository.findAll();
	}

	@Override
	public void saveScreenAccessMenu(ScreenAccessMenu screenAccessMenu) {
		this.screenAccessMenuRepository.save(screenAccessMenu);		
	}

	@Override
	public ScreenAccessMenu getScreenAccessMenuId(long screenAccessMenuId) {
		Optional<ScreenAccessMenu> optional = screenAccessMenuRepository.findById(screenAccessMenuId);
		ScreenAccessMenu screenAccessMenu = null;
		if (optional.isPresent()) {
			screenAccessMenu = optional.get();
		} else {
			throw new RuntimeException(" ScreenAccessMenu not found for screenAccessMenuId :: " + screenAccessMenuId);
		}

		return screenAccessMenu;
	}

	@Override
	public void deleteScreenAccessMenuById(long screenAccessMenuId) {
		this.screenAccessMenuRepository.deleteById(screenAccessMenuId);		
	}

	@Override
	public Optional<ScreenAccessMenu> findByMenuId(long menuId) {
		return screenAccessMenuRepository.findByMenuId(menuId);
	}

	@Override
	public Optional<ScreenAccessMenu> findByScreenAccessId(long screenAccessId) {
		return screenAccessMenuRepository.findByScreenAccessId(screenAccessId);
	}

}
